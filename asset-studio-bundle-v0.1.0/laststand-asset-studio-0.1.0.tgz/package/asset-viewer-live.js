// asset-viewer-live.js — Live mode client for Last Stand Asset Studio
// Served by asset-server.mjs at /api/client.js
// Assets loaded via /assets/:name URLs (no base64 embedding).
// Generation panel per card → POST /api/queue → SSE refresh.

import * as THREE from 'three';
import { GLTFLoader }      from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls }   from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { MeshoptDecoder }  from 'three/addons/libs/meshopt_decoder.module.js';

// ── GLTFLoader factory ────────────────────────────────────────────────────────
// All GLBs in this repo may be meshopt-compressed (EXT_meshopt_compression added
// by gltf-transform's optimization pipeline). The studio loaded GLBs fine before
// optimization, then started silently failing on the compressed ones. Use this
// helper everywhere instead of bare `new GLTFLoader()` so the decoder is always
// registered — without it the loader rejects with "setMeshoptDecoder must be
// called before loading compressed files" and the card never renders.
function makeGLTFLoader() {
  const ldr = new GLTFLoader();
  ldr.setMeshoptDecoder(MeshoptDecoder);
  return ldr;
}

// ── Init data from server ─────────────────────────────────────────────────────
const DATA   = JSON.parse(document.getElementById('init-data').textContent);
const CONFIG = DATA.config || { title: 'Asset', subtitle: 'Studio', procRigs: [], vfx: [] };

// ── Three.js helpers ──────────────────────────────────────────────────────────
function makeLights(scene) {
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const sun = new THREE.DirectionalLight(0xfff5e0, 1.6); sun.position.set(3,5,4); scene.add(sun);
  const fill = new THREE.DirectionalLight(0x6080ff, 0.4); fill.position.set(-2,2,-3); scene.add(fill);
}
function makeRenderer(canvas) {
  // ⚠ Reserved for the fullscreen modal only — gallery cards use the shared
  // renderer below. See SHARED_RENDERER comment block.
  const r = new THREE.WebGLRenderer({ canvas, antialias: true });
  r.setSize(canvas.clientWidth || 240, canvas.clientHeight || 200, false);
  r.setPixelRatio(Math.min(devicePixelRatio, 2));
  r.outputColorSpace = THREE.SRGBColorSpace;
  return r;
}

// ── SHARED_RENDERER ──────────────────────────────────────────────────────────
// ONE WebGLRenderer for the entire studio gallery. Eliminates per-page WebGL
// context limits (Chrome ~16, Safari ~8, Firefox ~16) which used to manifest as
// cards turning blank during fast scroll (older contexts evicted by the browser).
// Pattern from Three.js manual: one full-window canvas pinned via position:fixed,
// transparent (alpha:true), pointer-events:none. Each card is just a positioned
// <div> placeholder; the master rAF loop iterates registered cards, sets a
// viewport+scissor matching each placeholder's bounding rect, and renders the
// card's scene there.
//
// Pointer events (OrbitControls drag/zoom) work because OrbitControls binds
// directly to each card's placeholder div, NOT to the shared canvas.
//
// Cross-browser compatibility:
//   - Chrome / Edge (Chromium) ≥ 87: full support
//   - Firefox ≥ 78: full support (alpha+antialias may slightly desaturate, OK)
//   - Safari ≥ 14 (macOS / iOS): full support — explicit top/right/bottom/left
//     instead of `inset` shorthand for older WebKit; integer viewport coords to
//     avoid Metal-layer subpixel artifacts
//   - WebGL2 unavailable: Three.js auto-falls-back to WebGL1
//   - Hardware acceleration disabled: SwiftShader/llvmpipe — slow but works
//
// Trade-off: scenes + cameras + textures all stay in memory permanently. With
// 30-50 cards and few GLB models (the rest are tiny procedural geometry) this
// is well under 200 MB heap, fine for a desktop dev tool.
//
// The fullscreen modal (`openFsGLB` / `openFsImage`) still uses its own
// renderer — it's only one extra context, alive for the duration the modal is
// open.

const _glCanvas = document.createElement('canvas');
// Explicit top/right/bottom/left rather than `inset` shorthand (Safari 14.0
// and earlier don't support `inset`). All values 0 → cover viewport.
_glCanvas.style.cssText = [
  'position:fixed',
  'top:0','right:0','bottom:0','left:0',
  'width:100%','height:100%',
  'pointer-events:none',
  'z-index:2',
].join(';') + ';';
document.body.appendChild(_glCanvas);

// Try WebGL2 first (Three.js default), fall back gracefully if creation fails.
// `failIfMajorPerformanceCaveat:false` lets the browser use software rendering
// rather than throwing, so headless / unaccelerated machines still see SOMETHING.
let sharedRenderer = null;
try {
  sharedRenderer = new THREE.WebGLRenderer({
    canvas: _glCanvas,
    antialias: true,
    alpha: true,
    premultipliedAlpha: true,
    preserveDrawingBuffer: false,
    powerPreference: 'high-performance',
    failIfMajorPerformanceCaveat: false,
    stencil: false,            // we don't use stencil; saves memory on iOS
    depth: true,
  });
} catch (err) {
  console.error('[shared-renderer] WebGL unavailable in this browser:', err);
  // Fallback: a centered banner so the user understands why nothing renders.
  const warn = document.createElement('div');
  warn.style.cssText = 'position:fixed;top:12px;left:12px;right:12px;background:#3a1a1a;border:1px solid #c9433f;color:#ffe;padding:10px 14px;border-radius:6px;font-family:system-ui,sans-serif;font-size:13px;z-index:9999;';
  warn.textContent = 'Asset Studio requires WebGL. Please enable hardware acceleration in your browser settings, or use Chrome/Edge/Firefox/Safari with WebGL support.';
  document.body.appendChild(warn);
}

if (sharedRenderer) {
  sharedRenderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  sharedRenderer.outputColorSpace = THREE.SRGBColorSpace;
  sharedRenderer.setScissorTest(true);
  sharedRenderer.autoClear = false;
}

function _resizeShared() {
  if (!sharedRenderer) return;
  const w = Math.max(1, window.innerWidth | 0);
  const h = Math.max(1, window.innerHeight | 0);
  sharedRenderer.setSize(w, h, false);
}
_resizeShared();
window.addEventListener('resize', _resizeShared);
// Some mobile browsers (iOS Safari) don't fire `resize` on URL-bar collapse;
// `orientationchange` covers that case.
window.addEventListener('orientationchange', () => setTimeout(_resizeShared, 50));

const _cards = new Set();
function registerCard(card) {
  // card = { placeholder, scene, camera, controls?, update?, bgColor? }
  _cards.add(card);
  return card;
}
function unregisterCard(card) { _cards.delete(card); }

// `Element.prototype.isConnected` is available in all evergreen browsers but
// not in IE / very old Safari. Polyfill via document.contains for safety.
function _isAttached(el) {
  if (!el) return false;
  if ('isConnected' in el) return el.isConnected;
  return document.contains(el);
}

let _lastT = (typeof performance !== 'undefined' && performance.now)
  ? performance.now() : Date.now();
function _now() { return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now(); }

function _renderAll(now) {
  requestAnimationFrame(_renderAll);
  if (!sharedRenderer) return;

  // Master clock — rAF passes high-resolution timestamps in modern browsers,
  // fall back to performance.now() / Date.now() if undefined (very old WebKit).
  const t = (typeof now === 'number') ? now : _now();
  const dt = Math.min((t - _lastT) / 1000, 0.1);
  _lastT = t;

  // Reset full canvas to fully transparent each frame.
  sharedRenderer.setScissorTest(false);
  const px = sharedRenderer.getPixelRatio();
  const fullW = (sharedRenderer.domElement.width / px) | 0;
  const fullH = (sharedRenderer.domElement.height / px) | 0;
  sharedRenderer.setViewport(0, 0, fullW, fullH);
  sharedRenderer.setClearColor(0x000000, 0);
  sharedRenderer.clear(true, true, false);
  sharedRenderer.setScissorTest(true);

  const winH = window.innerHeight, winW = window.innerWidth;

  for (const card of _cards) {
    const el = card.placeholder;
    if (!_isAttached(el)) continue;
    const rect = el.getBoundingClientRect();
    // Skip any card that's fully off-screen — saves render cost and avoids
    // negative scissor coords (which some drivers — older Intel HD on
    // Windows/Firefox — handle inconsistently).
    if (rect.bottom <= 0 || rect.top >= winH || rect.right <= 0 || rect.left >= winW) continue;
    if (rect.width <= 0 || rect.height <= 0) continue;
    if (!card.scene || !card.camera) continue;

    // Keep camera aspect in sync with the live placeholder size
    const aspect = rect.width / rect.height;
    if (card.camera.isPerspectiveCamera && Math.abs(card.camera.aspect - aspect) > 0.001) {
      card.camera.aspect = aspect;
      card.camera.updateProjectionMatrix();
    }

    try { card.update && card.update(dt); } catch (e) { console.warn('card update failed', e); }
    try { card.controls && card.controls.update(); } catch {}

    // VIEWPORT = full card rect (camera→pixel mapping must use the placeholder's
    // true size to avoid distortion when the card is partially scrolled off).
    // SCISSOR  = visible intersection of card with canvas, clamped — only those
    // pixels are actually written. Round to integers; Safari's Metal backend
    // shows 1px gaps with fractional coords, and some Intel HD drivers on
    // Firefox/Windows misbehave with non-integer scissor.
    const cardLeft   = Math.round(rect.left);
    const cardBottom = Math.round(winH - rect.bottom);
    const cardW      = Math.round(rect.width);
    const cardH      = Math.round(rect.height);

    const visLeft    = Math.max(0, cardLeft);
    const visBottom  = Math.max(0, cardBottom);
    const visRight   = Math.min(fullW, cardLeft + cardW);
    const visTop     = Math.min(fullH, cardBottom + cardH);
    const visW       = visRight - visLeft;
    const visH       = visTop  - visBottom;
    if (visW <= 0 || visH <= 0) continue;

    sharedRenderer.setViewport(cardLeft, cardBottom, cardW, cardH);
    sharedRenderer.setScissor(visLeft, visBottom, visW, visH);

    if (card.bgColor !== undefined) {
      sharedRenderer.setClearColor(card.bgColor, 1);
      sharedRenderer.clear(true, true, false);
    }
    try { sharedRenderer.render(card.scene, card.camera); }
    catch (e) { console.warn('card render failed', e); }
  }
}
requestAnimationFrame(_renderAll);

// Self-heal: if the SINGLE shared context is lost (GPU driver crash, sleep/
// resume on Windows, tab-backgrounded too long on iOS Safari, etc.), reload
// the page once so the renderer is reconstructed from scratch. Guard against
// reload-loops by storing a sessionStorage timestamp.
_glCanvas.addEventListener('webglcontextlost', e => {
  e.preventDefault();
  console.warn('[shared-renderer] WebGL context lost');
  try {
    const last = +sessionStorage.getItem('_glReloadAt') || 0;
    if (Date.now() - last < 30000) {
      console.error('[shared-renderer] context lost twice within 30s — refusing to reload-loop');
      return;
    }
    sessionStorage.setItem('_glReloadAt', String(Date.now()));
  } catch {}
  setTimeout(() => location.reload(), 50);
});
// Some browsers (Firefox, recent Chrome) restore the context automatically
// without a reload. Hook into that too.
_glCanvas.addEventListener('webglcontextrestored', () => {
  console.info('[shared-renderer] WebGL context restored — reloading to rebuild scenes');
  setTimeout(() => location.reload(), 50);
});
function makeBaseScene() {
  const s = new THREE.Scene(); s.background = new THREE.Color(0x0d1520);
  makeLights(s); s.add(new THREE.GridHelper(6, 10, 0x1a2a3a, 0x1a2a3a)); return s;
}
function analyzeScene(scene, animations) {
  let tris = 0, meshes = 0, hasSkin = false;
  scene.traverse(o => {
    if (!o.isMesh) return; meshes++;
    const g = o.geometry;
    tris += g.index ? g.index.count/3 : g.attributes.position.count/3;
    if (o.isSkinnedMesh) hasSkin = true;
  });
  return { tris: Math.round(tris), meshes, hasSkin, anims: animations?.length || 0 };
}

// ── GLB Card (loads via URL) ──────────────────────────────────────────────────
const glbRenderers = new Map(); // name → { renderer, scene, camera, controls }

async function makeGLBCard(container, asset) {
  // Shared-renderer pattern: each card is a <div> placeholder that the master
  // loop renders to via viewport+scissor. No per-card WebGL context.
  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.style.cssText = 'width:100%;height:200px;display:block;cursor:grab;background:#0d1520;position:relative;';
  container.replaceChild(placeholder, spinnerEl);

  // ctx is kept around so external code (SSE refresh, history, fullscreen
  // modal) can still reference the loaded scene + active animation.
  const ctx = { renderer:null, scene:null, camera:null, controls:null, canvas: placeholder, container, mixer: null, actions: null, activeAnim: -1, asset };
  glbRenderers.set(asset.name, ctx);

  // Drag-drop ANY GLB file onto this card to replace the on-disk asset
  attachDragReplaceTarget(container, asset.name);

  ctx.scene    = makeBaseScene();
  ctx.camera   = new THREE.PerspectiveCamera(42, 1.2, 0.01, 200);
  ctx.controls = new OrbitControls(ctx.camera, placeholder);
  ctx.controls.enableDamping = true; ctx.controls.autoRotate = true;
  ctx.controls.autoRotateSpeed = 1.8; ctx.controls.dampingFactor = 0.08;

  // Async-load the GLB; once it lands, scene contains the model and the master
  // loop will start rendering it. Until then the card shows just the empty grid.
  loadGLBIntoScene(asset.name, ctx.scene, ctx.camera, ctx.controls, container);

  registerCard({
    placeholder,
    scene:    ctx.scene,
    camera:   ctx.camera,
    controls: ctx.controls,
    bgColor:  0x0d1520,
    update:   (dt) => { ctx.mixer?.update(dt); },
  });
}

async function loadGLBIntoScene(name, scene, camera, controls, container) {
  // Race-safe load token: if a newer call comes in while we're awaiting the
  // GLTF fetch, the older call sees ctx.loadToken !== myToken and bails out
  // BEFORE mutating the scene/DOM. Without this, the SSE asset-updated path
  // (drag-drop replace, fs.watch on disk change) can fire mid-load and leave
  // duplicate anim-bars + ghost models in the scene.
  const ctx = glbRenderers.get(name);
  const myToken = ((ctx && ctx.loadToken) || 0) + 1;
  if (ctx) ctx.loadToken = myToken;

  const loader = makeGLTFLoader();
  let gltf;
  try {
    gltf = await new Promise((res, rej) =>
      loader.load(`/assets/${name}?t=${Date.now()}`, res, null, rej)
    );
  } catch (e) {
    console.error('GLB load failed:', name, e);
    return;
  }

  // Stale-load guard: a newer call has started since we awaited; bail out so
  // we don't clobber its result.
  if (ctx && ctx.loadToken !== myToken) return;

  // ── All scene/DOM mutation happens AFTER the await, AFTER the stale check ──
  // This is the critical fix: previously the cleanup ran before await, so two
  // concurrent calls both saw "no bar to remove" and each inserted a new one.

  // Remove old models (keep lights + grid)
  const toRemove = [];
  scene.traverse(o => { if (o.isGroup || (o.isMesh && !o.isHelper)) toRemove.push(o); });
  toRemove.forEach(o => { if (o.parent) o.parent.remove(o); });

  // Reset mixer state — old AnimationMixer + actions are GC'd as we drop refs
  if (ctx) { ctx.mixer = null; ctx.actions = null; ctx.activeAnim = -1; }
  // Remove ALL old anim bars (defensive: querySelectorAll, not the singular
  // form, in case a previous race left more than one).
  container.querySelectorAll('.anim-bar').forEach(b => b.remove());

  const box1   = new THREE.Box3().setFromObject(gltf.scene);
  const center = box1.getCenter(new THREE.Vector3());
  const size   = box1.getSize(new THREE.Vector3());
  const scale  = 2 / Math.max(size.x, size.y, size.z);
  gltf.scene.scale.setScalar(scale);
  gltf.scene.position.copy(center).negate().multiplyScalar(scale);
  const box2 = new THREE.Box3().setFromObject(gltf.scene);
  gltf.scene.position.y -= box2.min.y;
  scene.add(gltf.scene);

  const box3    = new THREE.Box3().setFromObject(gltf.scene);
  const center3 = box3.getCenter(new THREE.Vector3());
  const sz3     = box3.getSize(new THREE.Vector3());
  const dist    = (Math.max(sz3.x,sz3.y,sz3.z)/2 / Math.tan(camera.fov*Math.PI/360)) * 1.7;
  camera.position.set(center3.x+dist*.6, center3.y+sz3.y*.3+dist*.4, center3.z+dist);
  controls.target.copy(center3); controls.update();

  const { tris, meshes, hasSkin, anims } = analyzeScene(gltf.scene, gltf.animations);
  const statsEl = container.querySelector('.stats');
  if (statsEl) statsEl.innerHTML =
    `<span>📐 ${tris.toLocaleString()} tri</span>` +
    `<span>🧱 ${meshes} mesh</span>` +
    `<span class="${anims>0?'has-anim':'no-anim'}">${anims>0 ? '✦ '+anims+' anim' : '✗ no anim'}</span>` +
    (hasSkin ? '<span class="has-rig">🦴 rigged</span>' : '');

  // ── Animation setup (only when GLB ships with embedded clips) ─────────
  if (gltf.animations && gltf.animations.length > 0 && ctx) {
    const mixer = new THREE.AnimationMixer(gltf.scene);
    const actions = gltf.animations.map(clip => mixer.clipAction(clip));
    actions[0].reset().play();
    ctx.mixer = mixer;
    ctx.actions = actions;
    ctx.activeAnim = 0;

    // Build chip bar
    const animBar = document.createElement('div');
    animBar.className = 'anim-bar';
    animBar.innerHTML =
      `<span class="anim-label">Animation</span>` +
      gltf.animations.map((c, i) => {
        const label = (c.name || `clip ${i}`).slice(0, 16);
        return `<button class="anim-chip${i===0?' active':''}" data-i="${i}" title="${(c.name||'').replace(/"/g,'&quot;')} (${c.duration.toFixed(1)}s)">${label}</button>`;
      }).join('') +
      `<button class="anim-chip auto" data-pause title="Pause all animations">⏸ pause</button>`;
    const infoEl = container.querySelector('.info');
    container.insertBefore(animBar, infoEl);

    animBar.addEventListener('click', e => {
      const btn = e.target.closest('.anim-chip');
      if (!btn) return;
      animBar.querySelectorAll('.anim-chip').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      if (btn.dataset.pause !== undefined) {
        actions.forEach(a => a.stop());
        ctx.activeAnim = -1;
      } else {
        const idx = parseInt(btn.dataset.i, 10);
        actions.forEach(a => a.stop());
        actions[idx].reset().play();
        ctx.activeAnim = idx;
      }
    });
  }
}

// ── Pose Calibrator Card ─────────────────────────────────────────────────────
// Loads a rigged character GLB + a prop GLB, attaches the prop to a chosen
// bone, and exposes per-axis position/rotation/scale tuning sliders + an
// animation chip-bar. Used to calibrate things like "rifle in mom's hand"
// without running the game. Triggered when slot.kind === 'pose-calibrator'.
//
// Slot config schema:
//   { id, label, category, kind:'pose-calibrator',
//     characterAsset: 'mom_stylized_rigged.glb',  // rigged character GLB
//     propAsset:      'rifle.glb',           // prop GLB to attach
//     defaultBone:    'mixamorigRightHand',  // bone to start attached to
//     defaultPose:    { position:[0,0,0], rotation:[0,0,-1.5708], scale:0.9 } }
async function makePoseCalibratorCard(container, slot) {
  const opts = slot || {};
  const characterAsset = opts.characterAsset || 'mom_stylized_rigged.glb';
  const propAsset      = opts.propAsset      || 'rifle.glb';
  const defaultBone    = opts.defaultBone    || 'mixamorigRightHand';
  const defaultPose    = opts.defaultPose    || { position: [0,0,0], rotation: [0,0,-Math.PI/2], scale: 0.9 };

  container.classList.add('pose-calibrator');
  console.log('[pose] makePoseCalibratorCard start', slot);
  // Stash slot data on the container so the fullscreen handler can access it.
  container.__poseSlot = { characterAsset, propAsset, defaultBone, defaultPose, label: slot.label };

  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.className = 'gl-placeholder';
  placeholder.style.cssText = 'width:100%;display:block;cursor:grab;background:#0d1520;position:relative;';
  const loadingMsg = document.createElement('div');
  loadingMsg.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#ff9a3a;font:11px/1.4 system-ui;text-align:center;pointer-events:none;padding:8px;';
  loadingMsg.innerHTML = `🎯 Loading preview…<br><span style="font-size:10px;color:#888;">${characterAsset.split('/').pop()}</span>`;
  placeholder.appendChild(loadingMsg);
  if (spinnerEl) container.replaceChild(placeholder, spinnerEl);
  else container.insertBefore(placeholder, container.firstChild);

  // 🔍 Open-calibrator button — same icon as fs-btn but opens the dedicated
  // pose calibrator fullscreen mode (with controls panel) instead of the plain
  // GLB viewer.
  const openBtn = document.createElement('button');
  openBtn.className = 'fs-btn';
  openBtn.textContent = '🔍';
  openBtn.title = 'Open pose calibrator (fullscreen with tuning controls)';
  openBtn.style.opacity = '1'; // always visible (not just on hover)
  openBtn.addEventListener('click', e => { e.stopPropagation(); openFsPoseCalibrator(container.__poseSlot); });
  container.insertBefore(openBtn, container.firstChild);

  // Register the card with the shared renderer EARLY with an empty scene so
  // something visible appears while the GLB load is in flight.
  const scene  = makeBaseScene();
  const camera = new THREE.PerspectiveCamera(35, 1.5, 0.01, 200);
  const controls = new OrbitControls(camera, placeholder);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  camera.position.set(2, 2, 4); controls.target.set(0, 1, 0); controls.update();
  const cardCtx = { mixerHolder: { current: null } };
  registerCard({
    placeholder,
    scene, camera, controls,
    bgColor: 0x0d1520,
    update: (dt) => { cardCtx.mixerHolder.current?.update(dt); },
  });

  let mixer = null;
  const actions = new Map();
  let currentAction = null;
  let charScene = null;
  let propScene = null;
  let attachedBone = null;
  // Live-edited pose state — lives outside loadGLB closures so the sliders can mutate
  const pose = {
    position: [...defaultPose.position],
    rotation: [...defaultPose.rotation],
    scale: defaultPose.scale,
  };
  const allBones = []; // populated after character loads

  // Load character + prop concurrently
  const loader = makeGLTFLoader();
  let charGltf, propGltf;
  console.log(`[pose] loading ${characterAsset} + ${propAsset} ...`);
  const t0 = performance.now();
  try {
    [charGltf, propGltf] = await Promise.all([
      new Promise((res, rej) => loader.load(`/assets/${characterAsset}?t=${Date.now()}`,
        res,
        (xhr) => { if (xhr.lengthComputable) loadingMsg.innerHTML = `🎯 Loading character… ${(xhr.loaded/1024/1024).toFixed(1)} / ${(xhr.total/1024/1024).toFixed(1)} MB`; },
        rej)),
      new Promise((res, rej) => loader.load(`/assets/${propAsset}?t=${Date.now()}`, res, null, rej)),
    ]);
    console.log(`[pose] loaded in ${((performance.now()-t0)/1000).toFixed(1)}s`);
  } catch (e) {
    console.error('[pose] Pose calibrator load FAILED:', e);
    loadingMsg.innerHTML = `<div style="color:#f55;font-size:12px;padding:20px;">❌ Load failed: ${characterAsset} or ${propAsset}<br><br>${e?.message || e}<br><br>Check Network tab.</div>`;
    return;
  }
  // Hide the loading message — scene is about to be populated
  loadingMsg.remove();

  // ── Place character (centered, scaled to ~2 units tall, feet on grid) ──
  charScene = charGltf.scene;
  const cBox = new THREE.Box3().setFromObject(charScene);
  const cSize = cBox.getSize(new THREE.Vector3());
  const cScale = 2 / Math.max(cSize.x, cSize.y, cSize.z);
  charScene.scale.setScalar(cScale);
  charScene.position.copy(cBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(cScale);
  const cBox2 = new THREE.Box3().setFromObject(charScene);
  charScene.position.y -= cBox2.min.y;
  scene.add(charScene);

  // Collect all bones for the dropdown
  charScene.traverse(o => { if (o.type === 'Bone' && o.name) allBones.push(o.name); });

  // Set up animation mixer on the loaded character (uncentered raw scene)
  if (charGltf.animations && charGltf.animations.length > 0) {
    mixer = new THREE.AnimationMixer(charScene);
    cardCtx.mixerHolder.current = mixer;
    for (const clip of charGltf.animations) {
      const action = mixer.clipAction(clip);
      action.setLoop(THREE.LoopRepeat, Infinity);
      const shortName = clip.name.replace(/^.*[|:.]/, '').toLowerCase();
      actions.set(shortName, action);
    }
    const startName = actions.has('idle') ? 'idle' : actions.keys().next().value;
    currentAction = actions.get(startName);
    currentAction?.play();
  }

  // ── Prop ─────────────────────────────────────────────────────────────────
  // Normalize prop to a known size (0.6 unit baseline) — same convention as
  // the game's normalizeAndPlace.
  propScene = propGltf.scene;
  const pBox = new THREE.Box3().setFromObject(propScene);
  const pSize = pBox.getSize(new THREE.Vector3());
  const pScale = 0.6 / Math.max(pSize.x, pSize.y, pSize.z);
  propScene.scale.setScalar(pScale);
  propScene.position.copy(pBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(pScale);

  // Frame the camera on the character
  const sz = cBox2.getSize(new THREE.Vector3());
  const dist = Math.max(sz.x, sz.y, sz.z) * 1.6;
  camera.position.set(dist * 0.7, sz.y * 0.55, dist * 0.9);
  controls.target.set(0, sz.y * 0.5, 0); controls.update();

  // ── Find + attach to the chosen bone ─────────────────────────────────────
  const findBone = (name) => {
    let found = null;
    charScene.traverse(o => { if (!found && o.name === name) found = o; });
    return found;
  };
  const attachToBone = (name) => {
    const bone = findBone(name);
    if (!bone) { console.warn('[pose] bone not found:', name); return; }
    if (propScene.parent) propScene.parent.remove(propScene);
    bone.add(propScene);
    attachedBone = bone;
    applyPose();
  };
  const applyPose = () => {
    if (!attachedBone || !propScene) return;
    // The hand bone has a tiny world scale (~0.025) inherited from the armature
    // normalize. Without compensation, a position of 0.02 in bone-local coords
    // becomes 0.0005 in world — invisibly small. Multiply by `inv` so the
    // user-facing position values read as approximate WORLD units (matches
    // what they see for the rifle's size).
    const ws = new THREE.Vector3(); attachedBone.getWorldScale(ws);
    const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
    propScene.position.set(pose.position[0] * inv, pose.position[1] * inv, pose.position[2] * inv);
    propScene.rotation.set(pose.rotation[0], pose.rotation[1], pose.rotation[2]);
    propScene.scale.setScalar(pose.scale * inv);
  };

  attachToBone(defaultBone);

  // Card preview animation chip-bar — same UX as regular GLB cards. Lets the
  // user cycle clips without entering fullscreen to validate that the pose
  // holds across all animations. Built INSIDE the card after the info panel.
  // Friendly labels: chip names come from the FBX filename in merge-mixamo-to-glb.py
  // (e.g. `mom_reload_idle.fbx` → `reload_idle`). Map to readable Mixamo names.
  const FRIENDLY_CLIP_LABELS = {
    idle:         'idle',
    walk:         'walk',
    aim_rifle:    'run + rifle',
    reload:       'reload',
    reload_idle:  'rifle idle',  // ⭐ Mixamo "Rifle Idle" — static armed stance
  };
  console.log('[pose] clips loaded:', Array.from(actions.keys()));
  if (actions.size > 0) {
    const animBar = document.createElement('div');
    animBar.className = 'anim-bar';
    animBar.innerHTML =
      `<span class="anim-label">Animation</span>` +
      Array.from(actions.entries()).map(([name, action]) => {
        const isActive = action === currentAction;
        const label = FRIENDLY_CLIP_LABELS[name] || name;
        return `<button class="anim-chip${isActive?' active':''}" data-clip="${name}" title="${name}">${label}</button>`;
      }).join('') +
      `<button class="anim-chip pause-chip" data-pause title="Pause animation (lock the current frame for fine-tuning)">⏸ pause</button>`;
    const infoEl = container.querySelector('.info');
    container.insertBefore(animBar, infoEl);
    animBar.addEventListener('click', e => {
      const btn = e.target.closest('.anim-chip');
      if (!btn) return;
      // Pause toggle — freeze/unfreeze the mixer at the current frame
      if (btn.dataset.pause !== undefined) {
        const paused = btn.classList.toggle('active');
        if (mixer) mixer.timeScale = paused ? 0 : 1;
        btn.textContent = paused ? '▶ resume' : '⏸ pause';
        return;
      }
      // Switching clip implicitly resumes
      animBar.querySelectorAll('.anim-chip').forEach(c => c.classList.remove('active'));
      btn.classList.add('active');
      if (mixer) mixer.timeScale = 1;
      const pauseBtn = animBar.querySelector('[data-pause]');
      if (pauseBtn) { pauseBtn.classList.remove('active'); pauseBtn.textContent = '⏸ pause'; }
      const next = actions.get(btn.dataset.clip);
      if (!next || next === currentAction) return;
      next.reset().play();
      currentAction?.crossFadeTo(next, 0.25, false);
      currentAction = next;
    });
  }

  // Update stats line — quick at-a-glance summary of what this card does
  const statsEl = container.querySelector('.stats');
  if (statsEl) statsEl.innerHTML =
    `<span>🦴 ${allBones.length} bones</span>` +
    `<span class="has-anim">✦ ${actions.size} clip${actions.size===1?'':'s'}</span>` +
    `<span>🔍 click to tune</span>`;

  console.log(`[pose] ready — ${allBones.length} bones, ${actions.size} clips, attached to ${defaultBone}. Click 🔍 to tune.`);
}

// ── Fullscreen Pose Calibrator ───────────────────────────────────────────────
// Reuses the existing fs-modal but loads char + prop with bone attachment +
// a control panel (#fs-pose-panel) for live pose tuning. Triggered by the 🔍
// button on a pose-calibrator card.
function openFsPoseCalibrator(slot) {
  if (!slot) return;
  const characterAsset = slot.characterAsset;
  const propAsset      = slot.propAsset;
  const defaultBone    = slot.defaultBone;
  const defaultPose    = slot.defaultPose;

  fsModal.classList.add('open');
  fsTitle.firstChild.nodeValue = `🎯 ${slot.label || 'Pose Calibrator'} `;
  fsMeta.textContent = '· tune position/rotation/scale · drag to orbit · scroll to zoom';
  fsImgWrap.style.display = 'none';
  fsCanvas.style.display = 'block';
  fsZoom.style.display = 'none';
  if (fsAnimBar) fsAnimBar.style.display = 'none';

  // Hide other side panels (asset/iter panel) so the pose UI gets the right side
  const _assetPanelHide = document.getElementById('fs-asset-panel');
  if (_assetPanelHide) { _assetPanelHide.style.display = 'none'; _assetPanelHide.innerHTML = ''; }
  // Build a fresh modal renderer (separate context, only alive while modal open)
  const renderer = new THREE.WebGLRenderer({ canvas: fsCanvas, antialias: true });
  renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0d1520); makeLights(scene);
  scene.add(new THREE.GridHelper(10, 20, 0x1a2a3a, 0x1a2a3a));
  const camera = new THREE.PerspectiveCamera(40, fsCanvas.clientWidth / fsCanvas.clientHeight, 0.01, 200);
  camera.position.set(2, 2, 4);
  const controls = new OrbitControls(camera, fsCanvas);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  controls.target.set(0, 1, 0); controls.update();

  let stop = false;
  let mixer = null;
  const actions = new Map();
  let currentAction = null;
  let charScene = null, propScene = null, attachedBone = null;
  const allBones = [];
  const pose = {
    position: [...defaultPose.position],
    rotation: [...defaultPose.rotation],
    scale: defaultPose.scale,
  };
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const STEP_ROT = 5;       // degrees per click
  const STEP_POS = 0.05;    // world units (~5cm, since pose values are world-unit-equivalent now)
  const STEP_SCL = 0.05;

  // ── Undo/redo history ───────────────────────────────────────────────────
  // Single linear history with a moving pointer. Each entry is a deep snapshot
  // of `pose`. New changes after an undo discard the redo tail.
  const HISTORY_MAX = 100;
  const snapshotPose = () => ({ position: [...pose.position], rotation: [...pose.rotation], scale: pose.scale });
  const history = [snapshotPose()];
  let historyIdx = 0;
  const pushHistory = () => {
    // Coalesce no-op pushes (compare with current entry)
    const cur = history[historyIdx];
    const same = cur && cur.scale === pose.scale &&
      cur.position[0] === pose.position[0] && cur.position[1] === pose.position[1] && cur.position[2] === pose.position[2] &&
      cur.rotation[0] === pose.rotation[0] && cur.rotation[1] === pose.rotation[1] && cur.rotation[2] === pose.rotation[2];
    if (same) return;
    history.length = historyIdx + 1; // trim redo tail
    history.push(snapshotPose());
    if (history.length > HISTORY_MAX) history.shift();
    else historyIdx++;
    updateHistoryUi();
  };
  const restoreFrom = (snap) => {
    pose.position[0] = snap.position[0]; pose.position[1] = snap.position[1]; pose.position[2] = snap.position[2];
    pose.rotation[0] = snap.rotation[0]; pose.rotation[1] = snap.rotation[1]; pose.rotation[2] = snap.rotation[2];
    pose.scale = snap.scale;
    applyPose();
  };
  const doUndo = () => {
    if (historyIdx <= 0) return;
    historyIdx--; restoreFrom(history[historyIdx]); updateHistoryUi();
  };
  const doRedo = () => {
    if (historyIdx >= history.length - 1) return;
    historyIdx++; restoreFrom(history[historyIdx]); updateHistoryUi();
  };
  const updateHistoryUi = () => {
    const undoBtn = panel.querySelector('.pose-undo');
    const redoBtn = panel.querySelector('.pose-redo');
    const status  = panel.querySelector('.pose-history-status');
    if (undoBtn) undoBtn.disabled = historyIdx <= 0;
    if (redoBtn) redoBtn.disabled = historyIdx >= history.length - 1;
    if (status)  status.textContent = `${historyIdx + 1} / ${history.length}`;
  };

  fsState = { kind: 'pose', renderer, scene, camera, controls, stop: () => stop = true };

  // Build the side panel right away (controls disabled until load completes)
  const panel = document.getElementById('fs-pose-panel');
  panel.style.display = 'block';
  panel.innerHTML = `
    <h4>🦴 Bone</h4>
    <select class="pose-bone-select" disabled><option>Loading…</option></select>
    <h4>🎬 Animation</h4>
    <div class="pose-anim-bar"><span style="color:#888;">Loading…</span></div>
    <h4>🖱 Gizmo (drag in 3D)</h4>
    <div class="gizmo-mode-bar" style="display:flex;gap:4px;margin-bottom:4px;">
      <button class="gizmo-btn active" data-gizmo="translate" title="Translate (W) — drag arrows to move">↔ Translate</button>
      <button class="gizmo-btn" data-gizmo="rotate" title="Rotate (E) — drag rings to rotate">⟳ Rotate</button>
      <button class="gizmo-btn" data-gizmo="scale" title="Scale (R) — drag squares to scale">⊞ Scale</button>
      <button class="gizmo-btn" data-gizmo="off" title="Hide gizmo (G)">∅</button>
    </div>
    <div class="gizmo-space-bar" style="display:flex;gap:4px;margin-bottom:6px;">
      <button class="gizmo-space-btn active" data-space="world" title="World space — axes aligned with world XYZ (Q to toggle)">🌐 World</button>
      <button class="gizmo-space-btn" data-space="local" title="Local space — axes aligned with the object's own orientation (Q to toggle)">📍 Local</button>
    </div>
    <div style="font-size:9px;color:#888;line-height:1.3;margin-bottom:6px;">
      <kbd>W</kbd>/<kbd>E</kbd>/<kbd>R</kbd> mode · <kbd>Q</kbd> world/local · <kbd>X</kbd>/<kbd>Y</kbd>/<kbd>Z</kbd> axis · <kbd>Shift</kbd> snap · <kbd>G</kbd> toggle<br>
      <kbd>Ctrl+Z</kbd> undo · <kbd>Ctrl+Shift+Z</kbd> / <kbd>Ctrl+Y</kbd> redo
    </div>
    <h4>📐 Position</h4>
    <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-pose="px-">−</button><span class="pose-val" data-pose-val="px" contenteditable="true">0.00</span><button data-pose="px+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-pose="py-">−</button><span class="pose-val" data-pose-val="py" contenteditable="true">0.00</span><button data-pose="py+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-pose="pz-">−</button><span class="pose-val" data-pose-val="pz" contenteditable="true">0.00</span><button data-pose="pz+">+</button></div>
    <h4>🔄 Rotation (deg)</h4>
    <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-pose="rx-">−</button><span class="pose-val" data-pose-val="rx" contenteditable="true">0°</span><button data-pose="rx+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-pose="ry-">−</button><span class="pose-val" data-pose-val="ry" contenteditable="true">0°</span><button data-pose="ry+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-pose="rz-">−</button><span class="pose-val" data-pose-val="rz" contenteditable="true">0°</span><button data-pose="rz+">+</button></div>
    <h4>📏 Scale</h4>
    <div class="fs-pose-row"><label>×</label><button data-pose="sc-">−</button><span class="pose-val" data-pose-val="sc" contenteditable="true">1.00</span><button data-pose="sc+">+</button></div>
    <div class="pose-actions" style="margin-top:6px;">
      <button class="secondary pose-undo" title="Undo (Ctrl+Z)" disabled>↶ Undo</button>
      <button class="secondary pose-redo" title="Redo (Ctrl+Shift+Z / Ctrl+Y)" disabled>↷ Redo</button>
      <span class="pose-history-status" style="flex:0 0 auto;align-self:center;font-size:10px;color:#888;font-variant-numeric:tabular-nums;padding:0 4px;">1 / 1</span>
    </div>
    <div class="pose-actions">
      <button class="pose-copy">📋 Copy code</button>
      <button class="secondary pose-reset">↺ Reset</button>
    </div>
  `;

  const findBone = (name) => { let f = null; charScene?.traverse(o => { if (!f && o.name === name) f = o; }); return f; };
  const attachToBone = (name) => {
    const bone = findBone(name);
    if (!bone || !propScene) return;
    if (propScene.parent) propScene.parent.remove(propScene);
    bone.add(propScene);
    attachedBone = bone;
    applyPose();
  };
  const applyPose = () => {
    if (!attachedBone || !propScene) return;
    // Same scale compensation as the inline card path — see comment there for
    // rationale. Pose values are world-unit-equivalent, not bone-local.
    const ws = new THREE.Vector3(); attachedBone.getWorldScale(ws);
    const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
    propScene.position.set(pose.position[0] * inv, pose.position[1] * inv, pose.position[2] * inv);
    propScene.rotation.set(pose.rotation[0], pose.rotation[1], pose.rotation[2]);
    propScene.scale.setScalar(pose.scale * inv);
    updateLabels();
  };
  const updateLabels = () => {
    const setVal = (code, txt) => { const el = panel.querySelector(`[data-pose-val="${code}"]`); if (el) el.textContent = txt; };
    setVal('px', pose.position[0].toFixed(2));
    setVal('py', pose.position[1].toFixed(2));
    setVal('pz', pose.position[2].toFixed(2));
    setVal('rx', `${(pose.rotation[0] * R2D).toFixed(0)}°`);
    setVal('ry', `${(pose.rotation[1] * R2D).toFixed(0)}°`);
    setVal('rz', `${(pose.rotation[2] * R2D).toFixed(0)}°`);
    setVal('sc', pose.scale.toFixed(2));
  };

  // Wire pose-tuning buttons (works even before load — applyPose no-ops until ready)
  panel.addEventListener('click', e => {
    const btn = e.target.closest('button[data-pose]');
    if (!btn) return;
    const c = btn.dataset.pose;
    if (c === 'px-') pose.position[0] -= STEP_POS;
    else if (c === 'px+') pose.position[0] += STEP_POS;
    else if (c === 'py-') pose.position[1] -= STEP_POS;
    else if (c === 'py+') pose.position[1] += STEP_POS;
    else if (c === 'pz-') pose.position[2] -= STEP_POS;
    else if (c === 'pz+') pose.position[2] += STEP_POS;
    else if (c === 'rx-') pose.rotation[0] -= STEP_ROT * D2R;
    else if (c === 'rx+') pose.rotation[0] += STEP_ROT * D2R;
    else if (c === 'ry-') pose.rotation[1] -= STEP_ROT * D2R;
    else if (c === 'ry+') pose.rotation[1] += STEP_ROT * D2R;
    else if (c === 'rz-') pose.rotation[2] -= STEP_ROT * D2R;
    else if (c === 'rz+') pose.rotation[2] += STEP_ROT * D2R;
    else if (c === 'sc-') pose.scale = Math.max(0.05, pose.scale - STEP_SCL);
    else if (c === 'sc+') pose.scale += STEP_SCL;
    applyPose();
    pushHistory();
  });
  panel.querySelectorAll('.pose-val[contenteditable]').forEach(el => {
    el.addEventListener('blur', () => {
      const c = el.dataset.poseVal;
      const num = parseFloat(el.textContent.replace(/[°\s]/g, ''));
      if (isNaN(num)) { updateLabels(); return; }
      if (c === 'px') pose.position[0] = num;
      else if (c === 'py') pose.position[1] = num;
      else if (c === 'pz') pose.position[2] = num;
      else if (c === 'rx') pose.rotation[0] = num * D2R;
      else if (c === 'ry') pose.rotation[1] = num * D2R;
      else if (c === 'rz') pose.rotation[2] = num * D2R;
      else if (c === 'sc') pose.scale = Math.max(0.05, num);
      applyPose();
      pushHistory();
    });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
  });
  // Undo/redo button wiring
  panel.querySelector('.pose-undo')?.addEventListener('click', doUndo);
  panel.querySelector('.pose-redo')?.addEventListener('click', doRedo);
  panel.querySelector('.pose-copy').addEventListener('click', async () => {
    // Position values are world-unit-equivalent — must be multiplied by `inv`
    // when applied (matches what the calibrator does internally). Rotation is
    // unaffected by scale; scale uses `* inv` to compensate for the armature.
    const code = `// Calibrated pose for ${attachedBone?.name || defaultBone}\nthis.rifleProp.position.set(${pose.position[0].toFixed(3)} * inv, ${pose.position[1].toFixed(3)} * inv, ${pose.position[2].toFixed(3)} * inv);\nthis.rifleProp.rotation.set(${pose.rotation[0].toFixed(4)}, ${pose.rotation[1].toFixed(4)}, ${pose.rotation[2].toFixed(4)}); // (${(pose.rotation[0]*R2D).toFixed(0)}°, ${(pose.rotation[1]*R2D).toFixed(0)}°, ${(pose.rotation[2]*R2D).toFixed(0)}°)\nthis.rifleProp.scale.setScalar(${pose.scale.toFixed(3)} * inv);`;
    try { await navigator.clipboard.writeText(code); console.log('[pose] copied:\n' + code); } catch { console.log('[pose] copy blocked:\n' + code); }
    const btn = panel.querySelector('.pose-copy'); const old = btn.textContent;
    btn.textContent = '✅ Copied!'; setTimeout(() => { btn.textContent = old; }, 1200);
  });
  panel.querySelector('.pose-reset').addEventListener('click', () => {
    pose.position = [...defaultPose.position];
    pose.rotation = [...defaultPose.rotation];
    pose.scale = defaultPose.scale;
    applyPose();
    pushHistory();
  });

  // Load both GLBs in the modal scene
  (async () => {
    const loader = makeGLTFLoader();
    let charGltf, propGltf;
    try {
      [charGltf, propGltf] = await Promise.all([
        new Promise((res, rej) => loader.load(`/assets/${characterAsset}?t=${Date.now()}`, res, null, rej)),
        new Promise((res, rej) => loader.load(`/assets/${propAsset}?t=${Date.now()}`,      res, null, rej)),
      ]);
    } catch (e) { console.error('[fs-pose] load failed:', e); fsMeta.textContent = `· load failed: ${e?.message || e}`; return; }
    if (stop) return;

    charScene = charGltf.scene;
    const cBox = new THREE.Box3().setFromObject(charScene);
    const cSize = cBox.getSize(new THREE.Vector3());
    const cScale = 2 / Math.max(cSize.x, cSize.y, cSize.z);
    charScene.scale.setScalar(cScale);
    charScene.position.copy(cBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(cScale);
    const cBox2 = new THREE.Box3().setFromObject(charScene);
    charScene.position.y -= cBox2.min.y;
    scene.add(charScene);

    charScene.traverse(o => { if (o.type === 'Bone' && o.name) allBones.push(o.name); });

    if (charGltf.animations && charGltf.animations.length > 0) {
      mixer = new THREE.AnimationMixer(charScene);
      for (const clip of charGltf.animations) {
        const action = mixer.clipAction(clip);
        action.setLoop(THREE.LoopRepeat, Infinity);
        const shortName = clip.name.replace(/^.*[|:.]/, '').toLowerCase();
        actions.set(shortName, action);
      }
      const startName = actions.has('idle') ? 'idle' : actions.keys().next().value;
      currentAction = actions.get(startName);
      currentAction?.play();
    }

    propScene = propGltf.scene;
    const pBox = new THREE.Box3().setFromObject(propScene);
    const pSize = pBox.getSize(new THREE.Vector3());
    const pScale = 0.6 / Math.max(pSize.x, pSize.y, pSize.z);
    propScene.scale.setScalar(pScale);
    propScene.position.copy(pBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(pScale);

    // Frame camera on character
    const sz = cBox2.getSize(new THREE.Vector3());
    const dist = Math.max(sz.x, sz.y, sz.z) * 1.4;
    camera.position.set(dist * 0.6, sz.y * 0.6, dist * 0.9);
    controls.target.set(0, sz.y * 0.5, 0); controls.update();

    attachToBone(defaultBone);

    // ── TransformControls — Blender-style 3D gizmo ──────────────────────────
    // Drag arrows/rings/squares directly on the rifle to translate/rotate/scale
    // it in 3D. Updates `pose` state on every drag tick so the +/- buttons +
    // Copy code stay in sync with what's visible. World space so dragging X
    // moves along the world X axis (matches the position/rotation row colors).
    const gizmo = new TransformControls(camera, renderer.domElement);
    gizmo.setSpace('world');
    gizmo.setSize(0.7);
    gizmo.attach(propScene);
    // TransformControls in r150+ exposes its visual via getHelper() (older
    // versions added `gizmo` itself). Try the new API first, fall back to old.
    if (typeof gizmo.getHelper === 'function') scene.add(gizmo.getHelper());
    else scene.add(gizmo);
    fsState.gizmo = gizmo;

    // Disable orbit while dragging the gizmo (otherwise both fight for the mouse).
    // Also snapshot to history at the END of each drag (one undo per drag,
    // not one per frame).
    gizmo.addEventListener('dragging-changed', (ev) => {
      controls.enabled = !ev.value;
      if (ev.value === false) pushHistory();
    });

    // Sync pose state from the live transform on every drag tick
    gizmo.addEventListener('objectChange', () => {
      // propScene is parented to a bone with world scale ~0.025. Our pose state
      // stores world-unit-equivalent values, so multiply local values by the
      // bone world scale to recover them.
      if (!attachedBone) return;
      const ws = new THREE.Vector3(); attachedBone.getWorldScale(ws);
      const boneScale = ws.x;
      pose.position[0] = propScene.position.x * boneScale;
      pose.position[1] = propScene.position.y * boneScale;
      pose.position[2] = propScene.position.z * boneScale;
      pose.rotation[0] = propScene.rotation.x;
      pose.rotation[1] = propScene.rotation.y;
      pose.rotation[2] = propScene.rotation.z;
      pose.scale = propScene.scale.x * boneScale; // uniform scale assumed
      updateLabels();
    });

    // Mode switcher buttons (translate/rotate/scale/off)
    const setGizmoMode = (mode) => {
      panel.querySelectorAll('.gizmo-btn').forEach(b => b.classList.toggle('active', b.dataset.gizmo === mode));
      if (mode === 'off') { gizmo.enabled = false; gizmo.visible = false; return; }
      gizmo.enabled = true; gizmo.visible = true;
      gizmo.setMode(mode);
    };
    panel.querySelector('.gizmo-mode-bar').addEventListener('click', e => {
      const btn = e.target.closest('.gizmo-btn');
      if (btn) setGizmoMode(btn.dataset.gizmo);
    });

    // Space switcher buttons (world / local) — controls how the gizmo arrows
    // are oriented. World: aligned with global XYZ axes (good for gross
    // positioning). Local: aligned with the object's current rotation (good
    // for fine adjustments along the rifle's barrel/grip axes).
    const setGizmoSpace = (space) => {
      panel.querySelectorAll('.gizmo-space-btn').forEach(b => b.classList.toggle('active', b.dataset.space === space));
      gizmo.setSpace(space);
    };
    panel.querySelector('.gizmo-space-bar').addEventListener('click', e => {
      const btn = e.target.closest('.gizmo-space-btn');
      if (btn) setGizmoSpace(btn.dataset.space);
    });

    // Keyboard shortcuts (Blender-ish): W/E/R modes, X/Y/Z axis lock, G toggle,
    // Shift snap, Q world/local. Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y for undo/redo.
    const onKey = (e) => {
      if (!fsModal.classList.contains('open')) return;
      // Undo/redo work even when a contenteditable has focus (typical IDE
      // behaviour). Check FIRST so they don't get hijacked by single-letter
      // shortcuts that bail on editing focus.
      const isModZ = (e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z');
      const isModY = (e.ctrlKey || e.metaKey) && (e.key === 'y' || e.key === 'Y');
      if (isModZ && e.shiftKey) { e.preventDefault(); doRedo(); return; }
      if (isModZ)              { e.preventDefault(); doUndo(); return; }
      if (isModY)              { e.preventDefault(); doRedo(); return; }
      if (e.target instanceof HTMLElement && e.target.isContentEditable) return; // don't hijack editing
      if (e.key === 'w' || e.key === 'W') { e.preventDefault(); setGizmoMode('translate'); }
      else if (e.key === 'e' || e.key === 'E') { e.preventDefault(); setGizmoMode('rotate'); }
      else if (e.key === 'r' || e.key === 'R') { e.preventDefault(); setGizmoMode('scale'); }
      else if (e.key === 'g' || e.key === 'G') { e.preventDefault(); setGizmoMode(gizmo.visible ? 'off' : 'translate'); }
      else if (e.key === 'q' || e.key === 'Q') { e.preventDefault(); setGizmoSpace(gizmo.space === 'world' ? 'local' : 'world'); }
      else if (e.shiftKey) {
        gizmo.setTranslationSnap(0.1); gizmo.setRotationSnap(THREE.MathUtils.degToRad(15)); gizmo.setScaleSnap(0.1);
      }
    };
    const onKeyUp = (e) => { if (!e.shiftKey) { gizmo.setTranslationSnap(null); gizmo.setRotationSnap(null); gizmo.setScaleSnap(null); } };
    window.addEventListener('keydown', onKey);
    window.addEventListener('keyup', onKeyUp);
    fsState.onGizmoKey = onKey;
    fsState.onGizmoKeyUp = onKeyUp;

    // Now wire bone select + animation chips with real data
    const boneSelect = panel.querySelector('.pose-bone-select');
    boneSelect.disabled = false;
    boneSelect.innerHTML = allBones.map(n => `<option value="${n}"${n===defaultBone?' selected':''}>${n}</option>`).join('');
    boneSelect.addEventListener('change', () => attachToBone(boneSelect.value));

    const animBar = panel.querySelector('.pose-anim-bar');
    animBar.innerHTML = '';
    const FRIENDLY = { idle:'idle', walk:'walk', aim_rifle:'run + rifle', reload:'reload', reload_idle:'rifle idle' };
    for (const [name, action] of actions.entries()) {
      const b = document.createElement('button');
      b.textContent = FRIENDLY[name] || name;
      b.title = name;
      if (action === currentAction) b.classList.add('active');
      b.addEventListener('click', () => {
        animBar.querySelectorAll('button').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        if (mixer) mixer.timeScale = 1;
        const pBtn = animBar.querySelector('[data-pause]');
        if (pBtn) { pBtn.classList.remove('active'); pBtn.textContent = '⏸ pause'; }
        if (currentAction && currentAction !== action) {
          action.reset().play();
          currentAction.crossFadeTo(action, 0.25, false);
        } else { action.reset().play(); }
        currentAction = action;
      });
      animBar.appendChild(b);
    }
    // Pause toggle — freeze the current frame so the user can fine-tune the
    // pose offsets without the model swaying. Click again to resume.
    const pauseBtn = document.createElement('button');
    pauseBtn.textContent = '⏸ pause';
    pauseBtn.title = 'Freeze the current frame for fine-tuning';
    pauseBtn.dataset.pause = '';
    pauseBtn.addEventListener('click', () => {
      const paused = pauseBtn.classList.toggle('active');
      if (mixer) mixer.timeScale = paused ? 0 : 1;
      pauseBtn.textContent = paused ? '▶ resume' : '⏸ pause';
    });
    animBar.appendChild(pauseBtn);
    fsMeta.textContent = `· ${allBones.length} bones · ${actions.size} clip${actions.size===1?'':'s'} · drag to orbit · scroll zoom`;
    updateLabels();
  })();

  function onResize() {
    if (stop) return;
    renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
    camera.aspect = fsCanvas.clientWidth / fsCanvas.clientHeight;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', onResize);
  fsState.cleanup = () => {
    window.removeEventListener('resize', onResize);
    if (fsState.onGizmoKey) window.removeEventListener('keydown', fsState.onGizmoKey);
    if (fsState.onGizmoKeyUp) window.removeEventListener('keyup', fsState.onGizmoKeyUp);
    if (fsState.gizmo) {
      try { fsState.gizmo.detach(); fsState.gizmo.dispose(); } catch {}
      const helper = fsState.gizmo.getHelper && fsState.gizmo.getHelper();
      if (helper && helper.parent) helper.parent.remove(helper);
    }
    renderer.dispose();
    if (panel) { panel.style.display = 'none'; panel.innerHTML = ''; }
  };
  setTimeout(onResize, 50);

  let lastT = performance.now();
  (function loop(now) {
    if (stop) return;
    requestAnimationFrame(loop);
    const dt = Math.min(((now||performance.now()) - lastT) / 1000, 0.1);
    lastT = now || performance.now();
    mixer?.update(dt);
    controls.update();
    renderer.render(scene, camera);
  })();
}

// ── Bone Offset Tuner Card ───────────────────────────────────────────────────
// Calibrate a per-bone constant rotation/position overlay that's applied on
// top of the running animations. Use case: "the right hand doesn't quite
// reach the rifle in the reload clip" — rotate the hand bone +5° once and the
// correction sticks across every animation. Saves to /assets/<stem>.bone-offsets.json
// which the game's runtime loadBoneOffsets() picks up automatically.
//
// Slot config schema:
//   { id, label, category, kind:'bone-offset-tuner',
//     characterAsset: 'mom_stylized_rigged.glb',  // rigged character GLB
//     defaultBone:    'mixamorigRightHand'  // bone selected by default
//   }
async function makeBoneOffsetTunerCard(container, slot) {
  const opts = slot || {};
  const characterAsset = opts.characterAsset || 'mom_stylized_rigged.glb';
  const defaultBone    = opts.defaultBone    || 'mixamorigRightHand';
  container.classList.add('pose-calibrator'); // reuse same compact card style
  container.__boneOffsetSlot = { characterAsset, defaultBone, label: slot.label };

  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.className = 'gl-placeholder';
  placeholder.style.cssText = 'width:100%;display:block;cursor:grab;background:#0d1520;position:relative;';
  const loadingMsg = document.createElement('div');
  loadingMsg.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#a78bfa;font:11px/1.4 system-ui;text-align:center;pointer-events:none;padding:8px;';
  loadingMsg.innerHTML = `🦴 Loading skeleton…<br><span style="font-size:10px;color:#888;">${characterAsset}</span>`;
  placeholder.appendChild(loadingMsg);
  if (spinnerEl) container.replaceChild(placeholder, spinnerEl);
  else container.insertBefore(placeholder, container.firstChild);

  // 🔍 fullscreen-tuner button (always visible, top-left)
  const openBtn = document.createElement('button');
  openBtn.className = 'fs-btn';
  openBtn.textContent = '🔍';
  openBtn.title = 'Open bone-offset tuner (fullscreen with sliders + save)';
  openBtn.style.opacity = '1';
  openBtn.addEventListener('click', e => { e.stopPropagation(); openFsBoneOffsetTuner(container.__boneOffsetSlot); });
  container.insertBefore(openBtn, container.firstChild);

  // Render preview with the same shared-renderer pattern as pose-calibrator
  const scene  = makeBaseScene();
  const camera = new THREE.PerspectiveCamera(35, 1.5, 0.01, 200);
  const controls = new OrbitControls(camera, placeholder);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  camera.position.set(2, 2, 4); controls.target.set(0, 1, 0); controls.update();
  const cardCtx = { mixerHolder: { current: null }, applyHolder: { current: null } };
  registerCard({
    placeholder,
    scene, camera, controls,
    bgColor: 0x0d1520,
    update: (dt) => {
      cardCtx.mixerHolder.current?.update(dt);
      cardCtx.applyHolder.current?.();
    },
  });

  // Load character + existing offsets
  const loader = makeGLTFLoader();
  let charGltf;
  try {
    charGltf = await new Promise((res, rej) => loader.load(`/assets/${characterAsset}?t=${Date.now()}`, res, null, rej));
  } catch (e) {
    console.error('[bone-offset] character load failed:', e);
    loadingMsg.innerHTML = `<div style="color:#f55;font-size:11px;">Failed: ${e?.message || e}</div>`;
    return;
  }
  loadingMsg.remove();

  const charScene = charGltf.scene;
  const cBox = new THREE.Box3().setFromObject(charScene);
  const cSize = cBox.getSize(new THREE.Vector3());
  const cScale = 2 / Math.max(cSize.x, cSize.y, cSize.z);
  charScene.scale.setScalar(cScale);
  charScene.position.copy(cBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(cScale);
  const cBox2 = new THREE.Box3().setFromObject(charScene);
  charScene.position.y -= cBox2.min.y;
  scene.add(charScene);

  const bones = [];
  charScene.traverse(o => { if (o.type === 'Bone' && o.name) bones.push(o); });

  // Mixer + actions for animation playback in the preview
  const actions = new Map();
  let currentAction = null;
  let mixer = null;
  if (charGltf.animations && charGltf.animations.length > 0) {
    mixer = new THREE.AnimationMixer(charScene);
    cardCtx.mixerHolder.current = mixer;
    for (const clip of charGltf.animations) {
      const action = mixer.clipAction(clip);
      action.setLoop(THREE.LoopRepeat, Infinity);
      const shortName = clip.name.replace(/^.*[|:.]/, '').toLowerCase();
      actions.set(shortName, action);
    }
    const startName = actions.has('idle') ? 'idle' : actions.keys().next().value;
    currentAction = actions.get(startName);
    currentAction?.play();
  }

  // Load existing offsets from disk
  const offsets = new Map();
  try {
    const r = await fetch(`/api/bone-offsets/${encodeURIComponent(characterAsset)}`);
    if (r.ok) {
      const data = await r.json();
      for (const [name, off] of Object.entries(data.boneOffsets || {})) {
        offsets.set(name, { rotation: off.rotation || [0,0,0], position: off.position || [0,0,0] });
      }
    }
  } catch (e) { console.warn('[bone-offset] preload failed:', e); }

  // Apply loop: post-multiply qOffset and add posOffset on top of mixer's writes
  const _eul = new THREE.Euler();
  const _quat = new THREE.Quaternion();
  const _vec = new THREE.Vector3();
  const applyOffsets = () => {
    for (const [name, off] of offsets) {
      const bone = charScene.getObjectByName(name);
      if (!bone) continue;
      _eul.set(off.rotation[0], off.rotation[1], off.rotation[2]);
      _quat.setFromEuler(_eul);
      bone.quaternion.multiply(_quat);
      // Position is stored world-unit-equivalent → convert to local via inv
      const ws = new THREE.Vector3(); bone.getWorldScale(ws);
      const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
      _vec.set(off.position[0] * inv, off.position[1] * inv, off.position[2] * inv);
      bone.position.add(_vec);
    }
  };
  cardCtx.applyHolder.current = applyOffsets;

  // Card stats
  const statsEl = container.querySelector('.stats');
  if (statsEl) statsEl.innerHTML =
    `<span>🦴 ${bones.length} bones</span>` +
    `<span class="has-anim">✦ ${actions.size} clip${actions.size===1?'':'s'}</span>` +
    `<span style="color:${offsets.size>0?'#a78bfa':'#888'};">${offsets.size} offset${offsets.size===1?'':'s'}</span>` +
    `<span>🔍 click to tune</span>`;

  // Stash for fullscreen access
  container.__boneOffsetSlot.preloadedOffsets = offsets;
  console.log(`[bone-offset] ready — ${bones.length} bones, ${actions.size} clips, ${offsets.size} offsets loaded`);
}

// ── Fullscreen Bone Offset Tuner ─────────────────────────────────────────────
function openFsBoneOffsetTuner(slot) {
  if (!slot) return;
  const characterAsset = slot.characterAsset;
  const defaultBone    = slot.defaultBone;

  fsModal.classList.add('open');
  fsTitle.firstChild.nodeValue = `🦴 ${slot.label || 'Bone Offset Tuner'} `;
  fsMeta.textContent = '· per-bone rotation/position overlay · drag to orbit';
  fsImgWrap.style.display = 'none';
  fsCanvas.style.display = 'block';
  fsZoom.style.display = 'none';
  if (fsAnimBar) fsAnimBar.style.display = 'none';
  // Hide asset panel (mutually exclusive — bone-offset tuner uses the right side)
  const _assetPanelHide2 = document.getElementById('fs-asset-panel');
  if (_assetPanelHide2) { _assetPanelHide2.style.display = 'none'; _assetPanelHide2.innerHTML = ''; }

  const renderer = new THREE.WebGLRenderer({ canvas: fsCanvas, antialias: true });
  renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0d1520); makeLights(scene);
  scene.add(new THREE.GridHelper(10, 20, 0x1a2a3a, 0x1a2a3a));
  const camera = new THREE.PerspectiveCamera(40, fsCanvas.clientWidth / fsCanvas.clientHeight, 0.01, 200);
  camera.position.set(2, 2, 4);
  const controls = new OrbitControls(camera, fsCanvas);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  controls.target.set(0, 1, 0); controls.update();

  let stop = false;
  let mixer = null;
  const actions = new Map();
  let currentAction = null;
  let charScene = null;
  const bones = [];
  const offsets = new Map(); // boneName → { rotation:[3], position:[3] }
  let selectedBone = defaultBone;
  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const STEP_ROT = 5, STEP_POS = 0.01;
  fsState = { kind: 'bone-offset', renderer, scene, camera, controls, stop: () => stop = true };

  // Build the side panel
  const panel = document.getElementById('fs-pose-panel');
  panel.style.display = 'block';
  panel.innerHTML = `
    <h4>🦴 Selected bone</h4>
    <select class="bone-offset-select" disabled><option>Loading…</option></select>
    <h4>🎬 Animation</h4>
    <div class="pose-anim-bar"><span style="color:#888;">Loading…</span></div>
    <h4>🔄 Rotation offset (deg)</h4>
    <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-bone="rx-">−</button><span class="pose-val" data-bone-val="rx" contenteditable="true">0°</span><button data-bone="rx+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-bone="ry-">−</button><span class="pose-val" data-bone-val="ry" contenteditable="true">0°</span><button data-bone="ry+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-bone="rz-">−</button><span class="pose-val" data-bone-val="rz" contenteditable="true">0°</span><button data-bone="rz+">+</button></div>
    <h4>📐 Position offset</h4>
    <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-bone="px-">−</button><span class="pose-val" data-bone-val="px" contenteditable="true">0.00</span><button data-bone="px+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-bone="py-">−</button><span class="pose-val" data-bone-val="py" contenteditable="true">0.00</span><button data-bone="py+">+</button></div>
    <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-bone="pz-">−</button><span class="pose-val" data-bone-val="pz" contenteditable="true">0.00</span><button data-bone="pz+">+</button></div>
    <div style="font-size:10px;color:#888;margin-top:6px;">Active offsets: <span class="bone-offset-count">0</span></div>
    <div class="pose-actions">
      <button class="pose-reset-bone secondary" title="Clear offsets for this bone">↺ Reset bone</button>
      <button class="pose-reset-all secondary" title="Clear ALL bone offsets" style="color:#ff7a7a;">⚠ Reset all</button>
    </div>
    <div class="pose-actions">
      <button class="bone-save">💾 Save to disk</button>
    </div>
    <div style="font-size:10px;color:#888;margin-top:4px;line-height:1.4;">
      Saves to <code style="color:#aaa;">${characterAsset.replace('.glb','.bone-offsets.json')}</code><br>
      Game picks it up automatically on next reload.
    </div>
  `;

  const getOffset = (name) => {
    if (!offsets.has(name)) offsets.set(name, { rotation: [0,0,0], position: [0,0,0] });
    return offsets.get(name);
  };
  const cleanIfZero = (name) => {
    const o = offsets.get(name);
    if (!o) return;
    if (o.rotation.every(v => v === 0) && o.position.every(v => v === 0)) offsets.delete(name);
  };
  const updateLabels = () => {
    const o = offsets.get(selectedBone) || { rotation: [0,0,0], position: [0,0,0] };
    const setVal = (code, txt) => { const el = panel.querySelector(`[data-bone-val="${code}"]`); if (el) el.textContent = txt; };
    setVal('rx', `${(o.rotation[0]*R2D).toFixed(0)}°`);
    setVal('ry', `${(o.rotation[1]*R2D).toFixed(0)}°`);
    setVal('rz', `${(o.rotation[2]*R2D).toFixed(0)}°`);
    setVal('px', o.position[0].toFixed(2));
    setVal('py', o.position[1].toFixed(2));
    setVal('pz', o.position[2].toFixed(2));
    panel.querySelector('.bone-offset-count').textContent = offsets.size;
  };

  // Sliders
  panel.addEventListener('click', e => {
    const btn = e.target.closest('button[data-bone]');
    if (!btn) return;
    const c = btn.dataset.bone;
    const o = getOffset(selectedBone);
    if      (c === 'rx-') o.rotation[0] -= STEP_ROT * D2R;
    else if (c === 'rx+') o.rotation[0] += STEP_ROT * D2R;
    else if (c === 'ry-') o.rotation[1] -= STEP_ROT * D2R;
    else if (c === 'ry+') o.rotation[1] += STEP_ROT * D2R;
    else if (c === 'rz-') o.rotation[2] -= STEP_ROT * D2R;
    else if (c === 'rz+') o.rotation[2] += STEP_ROT * D2R;
    else if (c === 'px-') o.position[0] -= STEP_POS;
    else if (c === 'px+') o.position[0] += STEP_POS;
    else if (c === 'py-') o.position[1] -= STEP_POS;
    else if (c === 'py+') o.position[1] += STEP_POS;
    else if (c === 'pz-') o.position[2] -= STEP_POS;
    else if (c === 'pz+') o.position[2] += STEP_POS;
    cleanIfZero(selectedBone);
    updateLabels();
  });
  panel.querySelectorAll('.pose-val[contenteditable]').forEach(el => {
    el.addEventListener('blur', () => {
      const c = el.dataset.boneVal;
      const num = parseFloat(el.textContent.replace(/[°\s]/g, ''));
      if (isNaN(num)) { updateLabels(); return; }
      const o = getOffset(selectedBone);
      if      (c === 'rx') o.rotation[0] = num * D2R;
      else if (c === 'ry') o.rotation[1] = num * D2R;
      else if (c === 'rz') o.rotation[2] = num * D2R;
      else if (c === 'px') o.position[0] = num;
      else if (c === 'py') o.position[1] = num;
      else if (c === 'pz') o.position[2] = num;
      cleanIfZero(selectedBone);
      updateLabels();
    });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
  });
  panel.querySelector('.pose-reset-bone').addEventListener('click', () => {
    offsets.delete(selectedBone); updateLabels();
  });
  panel.querySelector('.pose-reset-all').addEventListener('click', () => {
    if (offsets.size === 0) return;
    if (!confirm(`Clear ALL ${offsets.size} bone offsets? This cannot be undone (until you save).`)) return;
    offsets.clear(); updateLabels();
  });
  panel.querySelector('.bone-save').addEventListener('click', async () => {
    const body = { boneOffsets: {} };
    for (const [name, o] of offsets) body.boneOffsets[name] = { rotation: o.rotation, position: o.position };
    const btn = panel.querySelector('.bone-save');
    const old = btn.textContent;
    btn.textContent = 'Saving…'; btn.disabled = true;
    try {
      const res = await fetch(`/api/bone-offsets/${encodeURIComponent(characterAsset)}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      btn.textContent = `✅ Saved ${data.count} offsets`;
      console.log('[bone-offset] saved', data);
    } catch (e) { btn.textContent = `❌ ${e.message}`; console.error(e); }
    setTimeout(() => { btn.textContent = old; btn.disabled = false; }, 1500);
  });

  // Load + populate
  (async () => {
    const loader = makeGLTFLoader();
    let charGltf;
    try {
      charGltf = await new Promise((res, rej) => loader.load(`/assets/${characterAsset}?t=${Date.now()}`, res, null, rej));
    } catch (e) { console.error('[fs-bone] load failed', e); fsMeta.textContent = `· load failed: ${e?.message}`; return; }
    if (stop) return;

    charScene = charGltf.scene;
    const cBox = new THREE.Box3().setFromObject(charScene);
    const cSize = cBox.getSize(new THREE.Vector3());
    const cScale = 2 / Math.max(cSize.x, cSize.y, cSize.z);
    charScene.scale.setScalar(cScale);
    charScene.position.copy(cBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(cScale);
    const cBox2 = new THREE.Box3().setFromObject(charScene);
    charScene.position.y -= cBox2.min.y;
    scene.add(charScene);

    charScene.traverse(o => { if (o.type === 'Bone' && o.name) bones.push(o); });

    if (charGltf.animations && charGltf.animations.length > 0) {
      mixer = new THREE.AnimationMixer(charScene);
      for (const clip of charGltf.animations) {
        const action = mixer.clipAction(clip);
        action.setLoop(THREE.LoopRepeat, Infinity);
        const shortName = clip.name.replace(/^.*[|:.]/, '').toLowerCase();
        actions.set(shortName, action);
      }
      const startName = actions.has('idle') ? 'idle' : actions.keys().next().value;
      currentAction = actions.get(startName);
      currentAction?.play();
    }

    // Load existing offsets
    try {
      const r = await fetch(`/api/bone-offsets/${encodeURIComponent(characterAsset)}`);
      if (r.ok) {
        const data = await r.json();
        for (const [name, o] of Object.entries(data.boneOffsets || {})) {
          offsets.set(name, { rotation: o.rotation || [0,0,0], position: o.position || [0,0,0] });
        }
      }
    } catch {}

    // Frame camera
    const sz = cBox2.getSize(new THREE.Vector3());
    const dist = Math.max(sz.x, sz.y, sz.z) * 1.4;
    camera.position.set(dist * 0.6, sz.y * 0.6, dist * 0.9);
    controls.target.set(0, sz.y * 0.5, 0); controls.update();

    // Bone selector
    const boneSelect = panel.querySelector('.bone-offset-select');
    boneSelect.disabled = false;
    boneSelect.innerHTML = bones.map(b => {
      const has = offsets.has(b.name);
      return `<option value="${b.name}"${b.name===defaultBone?' selected':''}>${has?'● ':''}${b.name}</option>`;
    }).join('');
    boneSelect.addEventListener('change', () => {
      selectedBone = boneSelect.value;
      updateLabels();
    });

    // Animation chips with friendly labels
    const animBar = panel.querySelector('.pose-anim-bar');
    animBar.innerHTML = '';
    const FRIENDLY = { idle:'idle', walk:'walk', aim_rifle:'run + rifle', reload:'reload', reload_idle:'rifle idle' };
    for (const [name, action] of actions.entries()) {
      const b = document.createElement('button');
      b.textContent = FRIENDLY[name] || name; b.title = name;
      if (action === currentAction) b.classList.add('active');
      b.addEventListener('click', () => {
        animBar.querySelectorAll('button').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        if (mixer) mixer.timeScale = 1;
        const pBtn = animBar.querySelector('[data-pause]');
        if (pBtn) { pBtn.classList.remove('active'); pBtn.textContent = '⏸ pause'; }
        if (currentAction && currentAction !== action) {
          action.reset().play();
          currentAction.crossFadeTo(action, 0.25, false);
        } else { action.reset().play(); }
        currentAction = action;
      });
      animBar.appendChild(b);
    }
    const pauseBtn = document.createElement('button');
    pauseBtn.textContent = '⏸ pause'; pauseBtn.dataset.pause = '';
    pauseBtn.addEventListener('click', () => {
      const paused = pauseBtn.classList.toggle('active');
      if (mixer) mixer.timeScale = paused ? 0 : 1;
      pauseBtn.textContent = paused ? '▶ resume' : '⏸ pause';
    });
    animBar.appendChild(pauseBtn);

    fsMeta.textContent = `· ${bones.length} bones · ${actions.size} clips · ${offsets.size} offsets loaded`;
    selectedBone = defaultBone;
    updateLabels();
  })();

  // Apply offsets after each mixer.update
  const applyOffsets = () => {
    if (!charScene) return;
    const eul = new THREE.Euler(); const quat = new THREE.Quaternion(); const vec = new THREE.Vector3(); const ws = new THREE.Vector3();
    for (const [name, off] of offsets) {
      const bone = charScene.getObjectByName(name);
      if (!bone) continue;
      eul.set(off.rotation[0], off.rotation[1], off.rotation[2]);
      quat.setFromEuler(eul);
      bone.quaternion.multiply(quat);
      // Position offset is world-unit-equivalent — convert to local via inv
      bone.getWorldScale(ws);
      const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
      vec.set(off.position[0] * inv, off.position[1] * inv, off.position[2] * inv);
      bone.position.add(vec);
    }
  };

  function onResize() {
    if (stop) return;
    renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
    camera.aspect = fsCanvas.clientWidth / fsCanvas.clientHeight;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', onResize);
  fsState.cleanup = () => {
    window.removeEventListener('resize', onResize);
    renderer.dispose();
    if (panel) { panel.style.display = 'none'; panel.innerHTML = ''; }
  };
  setTimeout(onResize, 50);

  let lastT = performance.now();
  (function loop(now) {
    if (stop) return;
    requestAnimationFrame(loop);
    const dt = Math.min(((now||performance.now()) - lastT) / 1000, 0.1);
    lastT = now || performance.now();
    mixer?.update(dt);
    applyOffsets();
    controls.update();
    renderer.render(scene, camera);
  })();
}

// ── Rig Tuner Card (unified pose calibrator + bone offset tuner) ────────────
// One card to tune rigged characters end-to-end:
//   - Pick any character GLB from the asset library (auto-detected as rigged)
//   - Pick any prop GLB to attach to a chosen bone (or no prop)
//   - Browse animations to validate the tuning across clips
//   - Tune attached prop pose (position/rotation/scale) on the chosen bone
//   - Tune per-bone constant offsets that overlay on top of all animations
//   - Save everything to <char>.tune.json which the game reads automatically
//
// Slot config:
//   { id, label, category, kind:'rig-tuner',
//     defaultCharacter: 'mom_stylized_rigged.glb',  // initial dropdown selection
//     defaultProp:      'rifle.glb',           // optional initial prop
//     defaultBone:      'mixamorigRightHand'  // initial bone for prop attach
//   }
function makeRigTunerCard(container, slot) {
  const opts = slot || {};
  const defaultCharacter = opts.defaultCharacter || 'mom_stylized_rigged.glb';
  const defaultProp      = opts.defaultProp      || 'rifle.glb';
  const defaultBone      = opts.defaultBone      || 'mixamorigRightHand';

  container.classList.add('pose-calibrator');
  container.__rigTunerSlot = { defaultCharacter, defaultProp, defaultBone, label: slot.label };

  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.className = 'gl-placeholder';
  placeholder.style.cssText = 'width:100%;display:block;cursor:grab;background:#0d1520;position:relative;';
  const loadingMsg = document.createElement('div');
  loadingMsg.style.cssText = 'position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#a78bfa;font:11px/1.4 system-ui;text-align:center;pointer-events:none;padding:8px;';
  loadingMsg.innerHTML = `🎛 Loading rig tuner…<br><span style="font-size:10px;color:#888;">${defaultCharacter}</span>`;
  placeholder.appendChild(loadingMsg);
  if (spinnerEl) container.replaceChild(placeholder, spinnerEl);
  else container.insertBefore(placeholder, container.firstChild);

  const openBtn = document.createElement('button');
  openBtn.className = 'fs-btn';
  openBtn.textContent = '🔍';
  openBtn.title = 'Open rig tuner (fullscreen with character + prop selectors + tabs)';
  openBtn.style.opacity = '1';
  openBtn.addEventListener('click', e => { e.stopPropagation(); openFsRigTuner(container.__rigTunerSlot); });
  container.insertBefore(openBtn, container.firstChild);

  // Compact preview: just load the default character + prop and play idle
  const scene  = makeBaseScene();
  const camera = new THREE.PerspectiveCamera(35, 1.5, 0.01, 200);
  const controls = new OrbitControls(camera, placeholder);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  camera.position.set(2, 2, 4); controls.target.set(0, 1, 0); controls.update();
  const cardCtx = { mixerHolder: { current: null }, applyHolder: { current: null } };
  registerCard({
    placeholder, scene, camera, controls, bgColor: 0x0d1520,
    update: (dt) => {
      cardCtx.mixerHolder.current?.update(dt);
      cardCtx.applyHolder.current?.();
    },
  });

  const loader = makeGLTFLoader();
  (async () => {
    let charGltf, propGltf;
    try {
      [charGltf, propGltf] = await Promise.all([
        new Promise((res, rej) => loader.load(`/assets/${defaultCharacter}?t=${Date.now()}`, res, null, rej)),
        new Promise((res, rej) => loader.load(`/assets/${defaultProp}?t=${Date.now()}`,      res, null, rej)),
      ]);
    } catch (e) {
      console.error('[rig-tuner] preview load failed:', e);
      loadingMsg.innerHTML = `<div style="color:#f55;">Failed: ${e?.message}</div>`;
      return;
    }
    loadingMsg.remove();

    const charScene = charGltf.scene;
    const cBox = new THREE.Box3().setFromObject(charScene);
    const cSize = cBox.getSize(new THREE.Vector3());
    const cScale = 2 / Math.max(cSize.x, cSize.y, cSize.z);
    charScene.scale.setScalar(cScale);
    charScene.position.copy(cBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(cScale);
    const cBox2 = new THREE.Box3().setFromObject(charScene);
    charScene.position.y -= cBox2.min.y;
    scene.add(charScene);

    const bones = [];
    charScene.traverse(o => { if (o.type === 'Bone' && o.name) bones.push(o); });

    let mixer = null;
    const actions = new Map();
    if (charGltf.animations?.length > 0) {
      mixer = new THREE.AnimationMixer(charScene);
      cardCtx.mixerHolder.current = mixer;
      for (const clip of charGltf.animations) {
        const action = mixer.clipAction(clip); action.setLoop(THREE.LoopRepeat, Infinity);
        actions.set(clip.name.replace(/^.*[|:.]/, '').toLowerCase(), action);
      }
      const startName = actions.has('idle') ? 'idle' : actions.keys().next().value;
      actions.get(startName)?.play();
    }

    // ── Tune state (re-assignable so SSE refresh can mutate it) ─────────────
    // Schema (new — session 9):
    //   boneOffsets: { default: {boneName: {rotation, position}}, overrides: {clipName: {...}} }
    //   props:       { propName: {bone, position, rotation, scale} }
    // Old flat boneOffsets format also accepted (treated as default).
    // Card preview reads the same effective offset the game does:
    //   active-clip override → default fallback.
    let tune       = { boneOffsets: {}, props: {} };
    let propTune   = null;
    let attachedToBone = null;       // re-evaluated on SSE if propTune.bone changes
    const reloadTune = async () => {
      try {
        const r = await fetch(`/api/tune/${encodeURIComponent(defaultCharacter)}?t=${Date.now()}`);
        if (r.ok) tune = await r.json();
      } catch {}
      propTune = tune.props?.[defaultProp] || null;
      // Re-parent prop if the saved bone differs from where it currently sits.
      const wantBone = propTune?.bone || defaultBone;
      if (wantBone !== attachedToBone) {
        if (propScene.parent) propScene.parent.remove(propScene);
        const target = bones.find(b => b.name === wantBone);
        if (target) { target.add(propScene); attachedToBone = wantBone; }
      }
      // Refresh card stats line so the live "N offsets" count stays accurate.
      container.__rigTunerRefreshStats?.();
    };

    // Attach prop initially with default pose (will be re-positioned by applyHolder)
    const propScene = propGltf.scene;
    const pBox = new THREE.Box3().setFromObject(propScene);
    const pSize = pBox.getSize(new THREE.Vector3());
    const pScale = 0.6 / Math.max(pSize.x, pSize.y, pSize.z);
    propScene.scale.setScalar(pScale);
    propScene.position.copy(pBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(pScale);
    await reloadTune();

    // ── lastAnimQ snapshot (same architecture as session 9 fullscreen fix) ──
    // Prevents offset compounding on frames where PropertyMixer.apply skips
    // writes (mixer paused, or clip flat sections). Pre-mixer reset uses this
    // snapshot to restore a clean (offset-free) bone state; post-mixer capture
    // re-fills it only when the mixer is actively advancing.
    const lastAnimQ = new Map();
    for (const b of bones) {
      lastAnimQ.set(b.name, { quat: b.quaternion.clone(), pos: b.position.clone() });
    }
    const captureLastAnim = () => {
      if (!mixer || mixer.timeScale <= 0) return;
      for (const b of bones) {
        let e = lastAnimQ.get(b.name);
        if (!e) { e = { quat: new THREE.Quaternion(), pos: new THREE.Vector3() }; lastAnimQ.set(b.name, e); }
        e.quat.copy(b.quaternion); e.pos.copy(b.position);
      }
    };

    // Active clip name lookup for effective-offset selection.
    const currentClipName = () => {
      for (const [name, action] of actions) if (action.isRunning && action.getEffectiveWeight() > 0.5) return name;
      return '';
    };

    // ── Per-frame apply: pre-reset → mixer write (handled by cardCtx) → effective offsets ──
    // Order in registerCard's update(dt): mixerHolder.update(dt), then applyHolder().
    // We hijack applyHolder to do BOTH the pre-reset trick (before mixer would have
    // run if we owned the order) AND the offset multiply. Since the card's update
    // calls mixer.update FIRST then applyHolder, we run capture+apply in applyHolder.
    // The compounding fix relies on a stable bone.q baseline each frame; here we
    // restore from lastAnimQ at the START of applyHolder, then apply offsets.
    const _eul = new THREE.Euler(); const _quat = new THREE.Quaternion(); const _vec = new THREE.Vector3();
    cardCtx.applyHolder.current = () => {
      captureLastAnim();
      // Restore from snapshot (clean baseline) before offset multiply.
      for (const b of bones) {
        const e = lastAnimQ.get(b.name);
        if (!e) continue;
        b.quaternion.copy(e.quat);
        b.position.copy(e.pos);
      }
      // Effective offsets: active-clip override → default fallback.
      const bo = tune.boneOffsets || {};
      const isNewSchema = (bo.default !== undefined || bo.overrides !== undefined);
      const defaults  = isNewSchema ? (bo.default || {})   : bo;
      const overrides = isNewSchema ? (bo.overrides || {}) : {};
      const clipOvr = overrides[currentClipName()] || null;
      const allNames = new Set([...Object.keys(defaults), ...(clipOvr ? Object.keys(clipOvr) : [])]);
      const _ws = new THREE.Vector3();
      for (const name of allNames) {
        const off = (clipOvr && clipOvr[name]) || defaults[name];
        if (!off) continue;
        const b = charScene.getObjectByName(name); if (!b) continue;
        _eul.set((off.rotation||[0,0,0])[0], (off.rotation||[0,0,0])[1], (off.rotation||[0,0,0])[2]);
        _quat.setFromEuler(_eul); b.quaternion.multiply(_quat);
        b.getWorldScale(_ws);
        const inv = _ws.x > 0.0001 ? 1 / _ws.x : 1;
        const p = off.position || [0,0,0];
        _vec.set(p[0] * inv, p[1] * inv, p[2] * inv);
        b.position.add(_vec);
      }
      // Prop pose (in bone-local coords with scale compensation).
      if (propTune && attachedToBone) {
        const bone = charScene.getObjectByName(attachedToBone);
        if (bone) {
          const ws = new THREE.Vector3(); bone.getWorldScale(ws);
          const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
          const p = propTune.position || [0,0,0]; const r = propTune.rotation || [0,0,0];
          propScene.position.set(p[0]*inv, p[1]*inv, p[2]*inv);
          propScene.rotation.set(r[0], r[1], r[2]);
          propScene.scale.setScalar((propTune.scale ?? 1) * inv);
        }
      }
    };

    // ── SSE refresh hook: re-read tune.json when the studio saves ───────────
    // The save in fullscreen Rig Tuner writes <character>.tune.json which the
    // asset server watches; it fires asset-updated for that filename. We
    // re-fetch and the next applyHolder frame picks up the new offsets.
    const tuneFile = defaultCharacter.replace(/\.glb$/i, '.tune.json');
    const onTuneUpdate = (ev) => {
      const name = ev?.detail?.name;
      if (!name) return;
      if (name === tuneFile || name === defaultCharacter) {
        console.log('[rig-tuner card] reloading tune for', defaultCharacter, '(triggered by', name, ')');
        reloadTune();
      }
    };
    if (typeof window !== 'undefined' && window.__sseBus) {
      window.__sseBus.addEventListener('asset-updated', onTuneUpdate);
    }
    container.__rigTunerTuneDisposer = () => {
      if (typeof window !== 'undefined' && window.__sseBus) {
        window.__sseBus.removeEventListener('asset-updated', onTuneUpdate);
      }
    };

    // Frame camera
    const sz = cBox2.getSize(new THREE.Vector3());
    const dist = Math.max(sz.x, sz.y, sz.z) * 1.4;
    camera.position.set(dist * 0.6, sz.y * 0.6, dist * 0.9);
    controls.target.set(0, sz.y * 0.5, 0); controls.update();

    const statsEl = container.querySelector('.stats');
    const refreshStats = () => {
      if (!statsEl) return;
      const bo = tune.boneOffsets || {};
      const isNew = (bo.default !== undefined || bo.overrides !== undefined);
      const names = new Set();
      if (isNew) {
        for (const n of Object.keys(bo.default || {})) names.add(n);
        for (const m of Object.values(bo.overrides || {})) for (const n of Object.keys(m)) names.add(n);
      } else { for (const n of Object.keys(bo)) names.add(n); }
      const ovrCount = isNew ? Object.keys(bo.overrides || {}).length : 0;
      const ovrLabel = ovrCount > 0 ? ` <span style="color:#666;">(+${ovrCount} clip ovr)</span>` : '';
      statsEl.innerHTML =
        `<span>🦴 ${bones.length} bones</span>` +
        `<span class="has-anim">✦ ${actions.size} clips</span>` +
        `<span style="color:${names.size>0?'#a78bfa':'#888'};">${names.size} offsets${ovrLabel}</span>` +
        `<span style="color:${Object.keys(tune.props||{}).length>0?'#ffd97a':'#888'};">${Object.keys(tune.props||{}).length} props</span>` +
        `<span>🔍 click to tune</span>`;
    };
    refreshStats();
    // Stash on container so reloadTune (via SSE) can re-render stats too.
    container.__rigTunerRefreshStats = refreshStats;
  })();
}

// ── Fullscreen Rig Tuner ─────────────────────────────────────────────────────
async function openFsRigTuner(slot) {
  if (!slot) return;
  // List ALL .glb assets — both dropdowns share the same list. Whether something
  // is "the character" or "the prop" is just a role assignment per session;
  // any GLB can play either role. Rig info (bones + animations) is detected
  // dynamically on load. The default selection comes from the slot config but
  // the user can pick anything else from the project.
  // GLBs live in TWO places in initData: assigned to slots (DATA.slots[].fills)
  // and unassigned (DATA.orphans[]). Both contribute.
  const glbSet = new Set();
  for (const s of (DATA.slots || [])) {
    for (const f of (s.fills || [])) if (/\.glb$/i.test(f)) glbSet.add(f);
  }
  for (const o of (DATA.orphans || [])) if (/\.glb$/i.test(o.name)) glbSet.add(o.name);
  // Always include defaults even if neither source lists them yet.
  if (slot.defaultCharacter) glbSet.add(slot.defaultCharacter);
  if (slot.defaultProp)      glbSet.add(slot.defaultProp);
  const allGLBs = [...glbSet].sort();

  let currentCharacter = slot.defaultCharacter || allGLBs[0] || '';
  let currentProp      = slot.defaultProp || '';
  let activeTab        = 'prop'; // 'prop' | 'bones'
  let propTouched      = false;  // true only when user actually edits the prop pose this session

  fsModal.classList.add('open');
  fsTitle.firstChild.nodeValue = `🎛 ${slot.label || 'Rig Tuner'} `;
  fsMeta.textContent = '· universal rig tuner · drag to orbit';
  fsImgWrap.style.display = 'none';
  fsCanvas.style.display = 'block';
  fsZoom.style.display = 'none';
  if (fsAnimBar) fsAnimBar.style.display = 'none';
  const _ap = document.getElementById('fs-asset-panel');
  if (_ap) { _ap.style.display = 'none'; _ap.innerHTML = ''; }

  const renderer = new THREE.WebGLRenderer({ canvas: fsCanvas, antialias: true });
  renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0d1520); makeLights(scene);
  scene.add(new THREE.GridHelper(10, 20, 0x1a2a3a, 0x1a2a3a));
  const camera = new THREE.PerspectiveCamera(40, fsCanvas.clientWidth/fsCanvas.clientHeight, 0.01, 200);
  const controls = new OrbitControls(camera, fsCanvas);
  controls.enableDamping = true; controls.dampingFactor = 0.08;

  let stop = false;
  fsState = { kind: 'rig-tuner', renderer, scene, camera, controls, stop: () => stop = true };
  // Dev hook for browser-console debugging during tool development.
  window.__rt = {
    get tuneState() { return tuneState; },
    get scene() { return scene; },
    get camera() { return camera; },
    get gizmo() { return gizmo; },
    get controls() { return controls; },
    // Convenience: refresh the panel labels after programmatic mutations
    refresh: () => { try { refreshLabels(); } catch {} },
  };

  // Shared Map instance so boneOffsets starts pointing to boneOffsetsDefault
  const _boneOffsetsDefault = new Map();

  // Mutable state populated after each character/prop load
  const tuneState = {
    charScene: null,
    propScene: null,
    mixer: null,
    actions: new Map(),
    currentAction: null,
    bones: [],
    propBone: slot.defaultBone,                   // bone the prop is attached to
    propPose: { position:[0,0,0], rotation:[0,0,-Math.PI/2], scale: 0.9 },
    boneOffsets: _boneOffsetsDefault,             // POINTER to whichever scope is being edited
    boneOffsetsDefault: _boneOffsetsDefault,      // universal fallback: boneName → {rotation, position}
    boneOffsetsOverrides: new Map(),              // clipName → Map<boneName, {rotation, position}>
    boneOffsetScope: 'default',                   // 'default' | clipName
    lastAnimQ: new Map(),                         // boneName → {quat, pos} captured after mixer.update each frame
                                                  // — used by applyAll to reset bones BEFORE multiplying offsets,
                                                  // so paused/loop-wrap frames where three.js' PropertyMixer.apply
                                                  // skips writes (because values didn't change) don't cause offset
                                                  // compounding (bone.q × offset × offset × ... per frame).
    selectedOffsetBone: slot.defaultBone,
    tune: { boneOffsets: {}, props: {} },         // loaded JSON
    bindPose: false,                              // true = freeze char in T-pose for offset calibration
    boneFilterAttach: '',                         // search input value for prop-attach bone select
    boneFilterOffset: '',                         // search input value for bone-offset bone select
  };

  const D2R = Math.PI / 180, R2D = 180 / Math.PI;
  const STEP_ROT = 5, STEP_POS = 0.05, STEP_SCL = 0.05;
  const STEP_BONE_ROT = 5, STEP_BONE_POS = 0.01;

  // Build the side panel
  const panel = document.getElementById('fs-pose-panel');
  panel.style.display = 'block';

  const renderPanel = () => {
    const charOpts = allGLBs.map(n => `<option value="${n}"${n===currentCharacter?' selected':''}>${n}</option>`).join('');
    const propOpts = allGLBs.map(n => `<option value="${n}"${n===currentProp?' selected':''}>${n}</option>`).join('');
    panel.innerHTML = `
      <h4>🎬 Character (${allGLBs.length} GLBs)</h4>
      <select class="rt-char">${charOpts}</select>
      <div class="rt-char-info" style="font-size:10px;color:#888;margin-top:2px;">—</div>
      <h4>📦 Prop</h4>
      <select class="rt-prop"><option value="">(none)</option>${propOpts}</select>
      <h4>🎞 Animation</h4>
      <div class="pose-anim-bar"><span style="color:#888;">—</span></div>
      <button class="rt-bind-toggle ${tuneState.bindPose?'active':''}" title="Toggle T-pose / bind pose. Recommended ON for Bone offsets tab — calibrates against rest pose so the offset works uniformly across all animations.">🦴 ${tuneState.bindPose ? 'Bind pose ON (T-pose)' : 'Bind pose OFF (animating)'}</button>
      <h4 style="margin-top:10px;">🖱 Gizmo (drag in 3D)</h4>
      <div style="display:flex;gap:4px;margin-bottom:4px;">
        <button class="rt-gizmo-btn ${activeTab==='bones'?'':'active'}" data-gz="translate" ${activeTab==='bones'?'disabled title="Translate is disabled on bones — it stretches the SkinnedMesh because bone origin moves but parent-weighted vertices do not. Rotation pivots around the joint without distortion. Use the +/- position sliders below for rare deliberate translates (e.g. Hips height)."':'title="Translate (W)"'}>↔ T</button>
        <button class="rt-gizmo-btn ${activeTab==='bones'?'active':''}" data-gz="rotate" title="Rotate (E)">⟳ R</button>
        <button class="rt-gizmo-btn" data-gz="scale" ${activeTab==='bones'?'disabled title="Scale on bones distorts the rig. Prop-only."':'title="Scale (R) — prop only"'}>⊞ S</button>
        <button class="rt-gizmo-btn" data-gz="off" title="Hide gizmo (G)">∅</button>
      </div>
      ${activeTab==='bones' ? '<div style="font-size:9px;color:#a78bfa;line-height:1.3;margin-bottom:6px;">💡 Bones use rotation. Translate stretches mesh skin (use sliders below for rare cases like Hips).</div>' : ''}
      <div style="display:flex;gap:4px;margin-bottom:6px;">
        <button class="rt-gizmo-space active" data-sp="world" title="World axes (Q)">🌐 World</button>
        <button class="rt-gizmo-space" data-sp="local" title="Local axes (Q)">📍 Local</button>
      </div>
      <div style="font-size:9px;color:#888;line-height:1.3;margin-bottom:6px;">
        <kbd>W</kbd>/<kbd>E</kbd>/<kbd>R</kbd> mode · <kbd>Q</kbd> space · <kbd>G</kbd> toggle · <kbd>Shift</kbd> snap
      </div>
      <div style="display:flex;gap:6px;margin:8px 0 4px 0;border-bottom:1px solid rgba(255,255,255,0.1);">
        <button class="rt-tab ${activeTab==='prop'?'active':''}" data-tab="prop">📦 Prop pose</button>
        <button class="rt-tab ${activeTab==='bones'?'active':''}" data-tab="bones">🦴 Bone offsets</button>
      </div>
      <div class="rt-tab-body"></div>
      <div class="pose-actions" style="margin-top:8px;">
        <button class="rt-save">💾 Save tune</button>
      </div>
      <div style="font-size:10px;color:#888;margin-top:4px;line-height:1.4;">
        Saves to <code style="color:#aaa;">${(currentCharacter || '<character>').replace('.glb','.tune.json')}</code>
      </div>
    `;
    renderTabBody();
    wireOuterPanel();
    wirePanel();
  };
  const updateCharInfo = () => {
    const el = panel.querySelector('.rt-char-info');
    if (!el) return;
    const hasRig = tuneState.bones.length > 0;
    const hasAnim = tuneState.actions.size > 0;
    el.innerHTML = hasRig
      ? `<span style="color:${hasAnim?'#a3e635':'#ffd97a'};">🦴 ${tuneState.bones.length} bones · ${hasAnim ? '✦ '+tuneState.actions.size+' clips' : '⚠ no animations'}</span>`
      : `<span style="color:#ff7a7a;">⚠ static GLB (no skeleton)</span>`;
  };

  const renderTabBody = () => {
    const body = panel.querySelector('.rt-tab-body');
    if (!body) return;
    // Filter bones by the search input value (case-insensitive substring match)
    const filterBones = (q) => {
      const needle = (q || '').toLowerCase().trim();
      if (!needle) return tuneState.bones;
      return tuneState.bones.filter(b => b.name.toLowerCase().includes(needle));
    };
    if (activeTab === 'prop') {
      const p = tuneState.propPose;
      const visibleBones = filterBones(tuneState.boneFilterAttach || '');
      body.innerHTML = `
        <h4 style="margin-top:8px;">🦴 Attached to bone</h4>
        <input class="rt-bone-filter rt-bone-filter-attach" type="text" placeholder="Filter (e.g. 'right hand', 'spine', 'foot')" value="${(tuneState.boneFilterAttach||'').replace(/"/g,'&quot;')}" />
        <select class="rt-attach-bone" ${visibleBones.length===0?'disabled':''}>
          ${visibleBones.map(b => `<option value="${b.name}"${b.name===tuneState.propBone?' selected':''}>${b.name}</option>`).join('')}
        </select>
        <div style="font-size:10px;color:#888;margin:2px 0 6px 0;">${visibleBones.length} / ${tuneState.bones.length} bones</div>
        <h4>📐 Position (world units)</h4>
        <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-rt="px-">−</button><span class="pose-val" data-rt-val="px" contenteditable="true">${p.position[0].toFixed(2)}</span><button data-rt="px+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-rt="py-">−</button><span class="pose-val" data-rt-val="py" contenteditable="true">${p.position[1].toFixed(2)}</span><button data-rt="py+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-rt="pz-">−</button><span class="pose-val" data-rt-val="pz" contenteditable="true">${p.position[2].toFixed(2)}</span><button data-rt="pz+">+</button></div>
        <h4>🔄 Rotation (deg)</h4>
        <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-rt="rx-">−</button><span class="pose-val" data-rt-val="rx" contenteditable="true">${(p.rotation[0]*R2D).toFixed(0)}°</span><button data-rt="rx+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-rt="ry-">−</button><span class="pose-val" data-rt-val="ry" contenteditable="true">${(p.rotation[1]*R2D).toFixed(0)}°</span><button data-rt="ry+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-rt="rz-">−</button><span class="pose-val" data-rt-val="rz" contenteditable="true">${(p.rotation[2]*R2D).toFixed(0)}°</span><button data-rt="rz+">+</button></div>
        <h4>📏 Scale</h4>
        <div class="fs-pose-row"><label>×</label><button data-rt="sc-">−</button><span class="pose-val" data-rt-val="sc" contenteditable="true">${p.scale.toFixed(2)}</span><button data-rt="sc+">+</button></div>
      `;
    } else {
      const o = tuneState.boneOffsets.get(tuneState.selectedOffsetBone) || { rotation:[0,0,0], position:[0,0,0] };
      const visibleBones = filterBones(tuneState.boneFilterOffset || '');
      // Count descendants of the selected bone — these will inherit the
      // rotation when the offset is applied (correct rig hierarchy behaviour),
      // but visually it can look like "random body parts moving".
      // Surface this as an informational badge so the user knows which area
      // their offset affects before they start dragging.
      const selBone = tuneState.charScene?.getObjectByName(tuneState.selectedOffsetBone);
      let descCount = 0;
      const descNames = [];
      if (selBone) {
        selBone.traverse(o => { if (o !== selBone && o.type === 'Bone') { descCount++; if (descNames.length < 3) descNames.push(o.name.replace(/^mixamorig/,'')); } });
      }
      const descSummary = descCount === 0
        ? 'leaf bone (no descendants)'
        : `affects ${descCount} descendant bone${descCount===1?'':'s'}: ${descNames.join(', ')}${descCount > descNames.length ? '…' : ''}`;
      // Active clip name — used for the scope selector
      const activeClipName = [...tuneState.actions.entries()].find(([,a]) => a === tuneState.currentAction)?.[0] ?? '';
      const overrideClips = [...tuneState.boneOffsetsOverrides.keys()];
      const canAddOverride = activeClipName && !tuneState.boneOffsetsOverrides.has(activeClipName);
      body.innerHTML = `
        <div class="rt-scope-bar" style="display:flex;flex-wrap:wrap;gap:4px;margin:8px 0 4px;align-items:center;">
          <span style="font-size:10px;color:#888;flex-shrink:0;">Scope:</span>
          <button class="rt-scope-btn${tuneState.boneOffsetScope==='default'?' rt-scope-active':''}" data-scope="default" style="font-size:10px;padding:2px 7px;border-radius:10px;border:1px solid rgba(255,255,255,0.2);background:${tuneState.boneOffsetScope==='default'?'rgba(167,139,250,0.25)':'rgba(255,255,255,0.05)'};color:#fff;cursor:pointer;">Default</button>
          ${overrideClips.map(clip=>`<button class="rt-scope-btn${tuneState.boneOffsetScope===clip?' rt-scope-active':''}" data-scope="${clip}" style="font-size:10px;padding:2px 7px;border-radius:10px;border:1px solid rgba(255,255,255,0.2);background:${tuneState.boneOffsetScope===clip?'rgba(167,139,250,0.25)':'rgba(255,255,255,0.05)'};color:#fff;cursor:pointer;">${clip}</button>`).join('')}
          ${canAddOverride?`<button class="rt-scope-add" data-scope="${activeClipName}" title="Create override for clip '${activeClipName}'" style="font-size:10px;padding:2px 7px;border-radius:10px;border:1px dashed rgba(167,139,250,0.5);background:transparent;color:#a78bfa;cursor:pointer;">+ ${activeClipName}</button>`:''}
          ${tuneState.boneOffsetScope!=='default'?`<button class="rt-scope-del" data-scope="${tuneState.boneOffsetScope}" title="Delete '${tuneState.boneOffsetScope}' override" style="font-size:10px;padding:2px 5px;border-radius:10px;border:1px solid rgba(255,100,100,0.4);background:transparent;color:#ff7a7a;cursor:pointer;">🗑</button>`:''}
        </div>
        <h4 style="margin-top:4px;">🦴 Selected bone</h4>
        <input class="rt-bone-filter rt-bone-filter-offset" type="text" placeholder="Filter (e.g. 'right hand', 'spine', 'foot')" value="${(tuneState.boneFilterOffset||'').replace(/"/g,'&quot;')}" />
        <select class="rt-offset-bone" ${visibleBones.length===0?'disabled':''}>
          ${visibleBones.map(b => {
            const has = tuneState.boneOffsets.has(b.name);
            return `<option value="${b.name}"${b.name===tuneState.selectedOffsetBone?' selected':''}>${has?'● ':''}${b.name}</option>`;
          }).join('')}
        </select>
        <div style="font-size:10px;color:#888;margin:2px 0 6px 0;">${visibleBones.length} / ${tuneState.bones.length} bones · <span style="color:${descCount>0?'#a78bfa':'#666'};">${descSummary}</span></div>
        <h4>🔄 Rotation offset (deg)</h4>
        <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-rt="brx-">−</button><span class="pose-val" data-rt-val="brx" contenteditable="true">${(o.rotation[0]*R2D).toFixed(0)}°</span><button data-rt="brx+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-rt="bry-">−</button><span class="pose-val" data-rt-val="bry" contenteditable="true">${(o.rotation[1]*R2D).toFixed(0)}°</span><button data-rt="bry+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-rt="brz-">−</button><span class="pose-val" data-rt-val="brz" contenteditable="true">${(o.rotation[2]*R2D).toFixed(0)}°</span><button data-rt="brz+">+</button></div>
        <h4>📐 Position offset</h4>
        <div class="fs-pose-row"><label class="pose-axis-x">X</label><button data-rt="bpx-">−</button><span class="pose-val" data-rt-val="bpx" contenteditable="true">${o.position[0].toFixed(2)}</span><button data-rt="bpx+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-y">Y</label><button data-rt="bpy-">−</button><span class="pose-val" data-rt-val="bpy" contenteditable="true">${o.position[1].toFixed(2)}</span><button data-rt="bpy+">+</button></div>
        <div class="fs-pose-row"><label class="pose-axis-z">Z</label><button data-rt="bpz-">−</button><span class="pose-val" data-rt-val="bpz" contenteditable="true">${o.position[2].toFixed(2)}</span><button data-rt="bpz+">+</button></div>
        <div style="font-size:10px;color:#888;margin-top:6px;">Active offsets: <span class="rt-bones-count">${tuneState.boneOffsets.size}</span></div>
        <div style="display:flex;gap:6px;margin-top:6px;">
          <button class="rt-reset-bone" style="flex:1;background:rgba(255,255,255,0.06);color:#fff;border:1px solid rgba(255,255,255,0.15);border-radius:5px;padding:5px;font:inherit;font-size:10px;cursor:pointer;">↺ Reset bone</button>
          <button class="rt-reset-all-bones" style="flex:1;background:rgba(255,255,255,0.06);color:#ff7a7a;border:1px solid rgba(255,255,255,0.15);border-radius:5px;padding:5px;font:inherit;font-size:10px;cursor:pointer;">⚠ Reset all</button>
        </div>
        ${(() => {
          // Mirror button — visible only when the selected bone has a clear
          // Left/Right opposite in the naming convention. Avoids confusing
          // PMs when they're on a central bone (Hips/Spine/Neck) where
          // mirroring has no obvious target.
          const sel = tuneState.selectedOffsetBone || '';
          const opp = sel.includes('Left') ? sel.replace('Left', 'Right')
                    : sel.includes('Right') ? sel.replace('Right', 'Left')
                    : null;
          if (!opp) return '';
          return `<button class="rt-mirror-bone" data-opp="${opp}" style="margin-top:6px;width:100%;background:rgba(167,139,250,.15);color:#cfb8ff;border:1px solid rgba(167,139,250,.45);border-radius:5px;padding:6px;font:inherit;font-size:10px;cursor:pointer;" title="Copy this bone's offset to ${opp} with X-axis mirroring (negate Y/Z rotation, negate X position)">→ Mirror to ${opp.replace(/^mixamorig/, '')}</button>`;
        })()}
      `;
    }
  };

  // Outer-panel wiring — runs ONCE per renderPanel (which calls panel.innerHTML
  // = ... destroying inner listeners). DO NOT call this from renderTabBody:
  // renderTabBody only replaces the .rt-tab-body inner HTML, leaving outer
  // elements (char/prop selectors, tabs, bind toggle, gizmo buttons, save)
  // intact — re-attaching listeners would cause them to stack and clicks to
  // fire N times instead of once.
  const wireOuterPanel = () => {
    panel.querySelector('.rt-char').addEventListener('change', e => { currentCharacter = e.target.value; reload(); });
    panel.querySelector('.rt-prop').addEventListener('change', e => { currentProp = e.target.value; reload(); });
    panel.querySelectorAll('.rt-tab').forEach(b => {
      b.addEventListener('click', () => {
        activeTab = b.dataset.tab;
        // Default bind pose ON when switching to Bone offsets, OFF when
        // switching to Prop pose (where you usually want to see the prop
        // moving with the rifle idle anim, not in T-pose).
        tuneState.bindPose = (activeTab === 'bones');
        renderPanel();
        rebuildAnimChips();
        applyGizmoTarget();
        // On Bones tab, force gizmo to rotate (translate/scale are disabled
        // because they distort the SkinnedMesh) AND default to LOCAL space.
        // World-space rotation around (e.g.) Y produces a multi-axis rotation
        // in the bone's LOCAL coordinate system because the bone's local axes
        // don't align with world axes — that's why dragging one handle "leaks"
        // into other axes when decomposed to Euler XYZ. Local space rotates
        // around the bone's own axes, matching user expectation.
        if (activeTab === 'bones') { setGizmoMode('rotate'); setGizmoSpace('local'); }
      });
    });
    panel.querySelector('.rt-bind-toggle')?.addEventListener('click', () => {
      tuneState.bindPose = !tuneState.bindPose;
      const btn = panel.querySelector('.rt-bind-toggle');
      if (btn) {
        btn.classList.toggle('active', tuneState.bindPose);
        btn.textContent = `🦴 ${tuneState.bindPose ? 'Bind pose ON (T-pose)' : 'Bind pose OFF (animating)'}`;
      }
    });
    panel.querySelectorAll('.rt-gizmo-btn').forEach(b => {
      b.addEventListener('click', () => setGizmoMode(b.dataset.gz));
    });
    panel.querySelectorAll('.rt-gizmo-space').forEach(b => {
      b.addEventListener('click', () => setGizmoSpace(b.dataset.sp));
    });
    panel.querySelector('.rt-save').addEventListener('click', saveTune);
  };

  // Inner (tab-body) wiring — runs every time renderTabBody() rebuilds the
  // body DOM. Only attach listeners to elements created by renderTabBody.
  const wirePanel = () => {

    // Tab body wiring (wired after every renderTabBody since the DOM is replaced)
    // Bone filter — debounced rebuild of the filtered select on each keystroke.
    // Re-renders only the tab body, preserving focus + caret on the input.
    const wireFilter = (selector, key) => {
      const inp = panel.querySelector(selector);
      if (!inp) return;
      inp.addEventListener('input', () => {
        tuneState[key] = inp.value;
        const caret = inp.selectionStart;
        renderTabBody(); wirePanel();
        // Restore focus to the filter input + cursor position
        const newInp = panel.querySelector(selector);
        if (newInp) { newInp.focus(); try { newInp.setSelectionRange(caret, caret); } catch {} }
      });
    };
    if (activeTab === 'prop') {
      wireFilter('.rt-bone-filter-attach', 'boneFilterAttach');
      const attachSel = panel.querySelector('.rt-attach-bone');
      attachSel?.addEventListener('change', () => {
        tuneState.propBone = attachSel.value;
        propTouched = true;
        attachPropToBone(tuneState.propBone);
        applyGizmoTarget();
      });
    } else {
      // Scope selector — switch between default and per-clip override Maps
      const switchScope = (scope) => {
        tuneState.boneOffsetScope = scope;
        if (scope === 'default') {
          tuneState.boneOffsets = tuneState.boneOffsetsDefault;
        } else {
          if (!tuneState.boneOffsetsOverrides.has(scope)) {
            tuneState.boneOffsetsOverrides.set(scope, new Map());
          }
          tuneState.boneOffsets = tuneState.boneOffsetsOverrides.get(scope);
        }
        renderTabBody(); wirePanel();
      };
      panel.querySelectorAll('.rt-scope-btn, .rt-scope-add').forEach(btn => {
        btn.addEventListener('click', () => switchScope(btn.dataset.scope));
      });
      panel.querySelector('.rt-scope-del')?.addEventListener('click', (e) => {
        const clip = e.currentTarget.dataset.scope;
        if (!confirm(`Delete "${clip}" override? This cannot be undone.`)) return;
        tuneState.boneOffsetsOverrides.delete(clip);
        switchScope('default');
      });

      wireFilter('.rt-bone-filter-offset', 'boneFilterOffset');
      const offsetSel = panel.querySelector('.rt-offset-bone');
      offsetSel?.addEventListener('change', () => {
        tuneState.selectedOffsetBone = offsetSel.value;
        renderTabBody(); wirePanel();
        applyGizmoTarget();
      });
      panel.querySelector('.rt-reset-bone')?.addEventListener('click', () => {
        tuneState.boneOffsets.delete(tuneState.selectedOffsetBone);
        renderTabBody(); wirePanel();
      });
      panel.querySelector('.rt-reset-all-bones')?.addEventListener('click', () => {
        if (tuneState.boneOffsets.size === 0) return;
        if (!confirm(`Clear all ${tuneState.boneOffsets.size} bone offsets?`)) return;
        tuneState.boneOffsets.clear(); renderTabBody(); wirePanel();
      });
      // Mirror button — copies the selected bone's offset to its Left/Right
      // opposite with X-axis mirroring (Mixamo convention: characters face -Z,
      // mirror plane is YZ at x=0, so X position negates, Y/Z rotation negate,
      // X rotation stays). The result lands in the same scope as the source
      // (override Map if editing an override; default if editing default).
      panel.querySelector('.rt-mirror-bone')?.addEventListener('click', (e) => {
        const opp = e.currentTarget.dataset.opp;
        const src = tuneState.boneOffsets.get(tuneState.selectedOffsetBone);
        if (!opp || !src) return;
        const mirrored = {
          rotation: [src.rotation[0], -src.rotation[1], -src.rotation[2]],
          position: [-src.position[0], src.position[1], src.position[2]],
        };
        tuneState.boneOffsets.set(opp, mirrored);
        // Switch selection to the newly-mirrored bone so PM can immediately
        // verify the result by inspecting the offset values.
        tuneState.selectedOffsetBone = opp;
        renderTabBody(); wirePanel();
      });
    }

    // ±/edit handlers — single delegated listener (data-rt button + data-rt-val span)
    panel.querySelectorAll('button[data-rt]').forEach(btn => {
      btn.addEventListener('click', () => { applyDelta(btn.dataset.rt); refreshLabels(); });
    });
    panel.querySelectorAll('.pose-val[data-rt-val]').forEach(el => {
      el.addEventListener('blur', () => {
        const c = el.dataset.rtVal;
        const num = parseFloat(el.textContent.replace(/[°\s]/g, ''));
        if (isNaN(num)) { refreshLabels(); return; }
        applyAbsolute(c, num);
        refreshLabels();
      });
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); el.blur(); } });
    });
  };

  const applyDelta = (code) => {
    const p = tuneState.propPose;
    const pickOffset = () => {
      if (!tuneState.boneOffsets.has(tuneState.selectedOffsetBone))
        tuneState.boneOffsets.set(tuneState.selectedOffsetBone, { rotation:[0,0,0], position:[0,0,0] });
      return tuneState.boneOffsets.get(tuneState.selectedOffsetBone);
    };
    if (code.startsWith('p')) {
      // Prop pose
      if      (code === 'px-') p.position[0] -= STEP_POS;
      else if (code === 'px+') p.position[0] += STEP_POS;
      else if (code === 'py-') p.position[1] -= STEP_POS;
      else if (code === 'py+') p.position[1] += STEP_POS;
      else if (code === 'pz-') p.position[2] -= STEP_POS;
      else if (code === 'pz+') p.position[2] += STEP_POS;
      propTouched = true;
    } else if (code.startsWith('r')) {
      if      (code === 'rx-') p.rotation[0] -= STEP_ROT * D2R;
      else if (code === 'rx+') p.rotation[0] += STEP_ROT * D2R;
      else if (code === 'ry-') p.rotation[1] -= STEP_ROT * D2R;
      else if (code === 'ry+') p.rotation[1] += STEP_ROT * D2R;
      else if (code === 'rz-') p.rotation[2] -= STEP_ROT * D2R;
      else if (code === 'rz+') p.rotation[2] += STEP_ROT * D2R;
      propTouched = true;
    } else if (code === 'sc-') { p.scale = Math.max(0.05, p.scale - STEP_SCL); propTouched = true; }
    else if  (code === 'sc+') { p.scale += STEP_SCL; propTouched = true; }
    else if (code.startsWith('br')) {
      const o = pickOffset();
      if      (code === 'brx-') o.rotation[0] -= STEP_BONE_ROT * D2R;
      else if (code === 'brx+') o.rotation[0] += STEP_BONE_ROT * D2R;
      else if (code === 'bry-') o.rotation[1] -= STEP_BONE_ROT * D2R;
      else if (code === 'bry+') o.rotation[1] += STEP_BONE_ROT * D2R;
      else if (code === 'brz-') o.rotation[2] -= STEP_BONE_ROT * D2R;
      else if (code === 'brz+') o.rotation[2] += STEP_BONE_ROT * D2R;
      cleanIfZero();
    } else if (code.startsWith('bp')) {
      const o = pickOffset();
      if      (code === 'bpx-') o.position[0] -= STEP_BONE_POS;
      else if (code === 'bpx+') o.position[0] += STEP_BONE_POS;
      else if (code === 'bpy-') o.position[1] -= STEP_BONE_POS;
      else if (code === 'bpy+') o.position[1] += STEP_BONE_POS;
      else if (code === 'bpz-') o.position[2] -= STEP_BONE_POS;
      else if (code === 'bpz+') o.position[2] += STEP_BONE_POS;
      cleanIfZero();
    }
  };
  const applyAbsolute = (c, num) => {
    const p = tuneState.propPose;
    if      (c === 'px') { p.position[0] = num; propTouched = true; }
    else if (c === 'py') { p.position[1] = num; propTouched = true; }
    else if (c === 'pz') { p.position[2] = num; propTouched = true; }
    else if (c === 'rx') { p.rotation[0] = num * D2R; propTouched = true; }
    else if (c === 'ry') { p.rotation[1] = num * D2R; propTouched = true; }
    else if (c === 'rz') { p.rotation[2] = num * D2R; propTouched = true; }
    else if (c === 'sc') { p.scale = Math.max(0.05, num); propTouched = true; }
    else {
      if (!tuneState.boneOffsets.has(tuneState.selectedOffsetBone))
        tuneState.boneOffsets.set(tuneState.selectedOffsetBone, { rotation:[0,0,0], position:[0,0,0] });
      const o = tuneState.boneOffsets.get(tuneState.selectedOffsetBone);
      if      (c === 'brx') o.rotation[0] = num * D2R;
      else if (c === 'bry') o.rotation[1] = num * D2R;
      else if (c === 'brz') o.rotation[2] = num * D2R;
      else if (c === 'bpx') o.position[0] = num;
      else if (c === 'bpy') o.position[1] = num;
      else if (c === 'bpz') o.position[2] = num;
      cleanIfZero();
    }
  };
  const cleanIfZero = () => {
    const o = tuneState.boneOffsets.get(tuneState.selectedOffsetBone);
    if (!o) return;
    if (o.rotation.every(v => v === 0) && o.position.every(v => v === 0)) tuneState.boneOffsets.delete(tuneState.selectedOffsetBone);
  };
  const refreshLabels = () => {
    const p = tuneState.propPose;
    const setVal = (code, txt) => { const el = panel.querySelector(`[data-rt-val="${code}"]`); if (el) el.textContent = txt; };
    if (activeTab === 'prop') {
      setVal('px', p.position[0].toFixed(2));
      setVal('py', p.position[1].toFixed(2));
      setVal('pz', p.position[2].toFixed(2));
      setVal('rx', `${(p.rotation[0]*R2D).toFixed(0)}°`);
      setVal('ry', `${(p.rotation[1]*R2D).toFixed(0)}°`);
      setVal('rz', `${(p.rotation[2]*R2D).toFixed(0)}°`);
      setVal('sc', p.scale.toFixed(2));
    } else {
      const o = tuneState.boneOffsets.get(tuneState.selectedOffsetBone) || { rotation:[0,0,0], position:[0,0,0] };
      setVal('brx', `${(o.rotation[0]*R2D).toFixed(0)}°`);
      setVal('bry', `${(o.rotation[1]*R2D).toFixed(0)}°`);
      setVal('brz', `${(o.rotation[2]*R2D).toFixed(0)}°`);
      setVal('bpx', o.position[0].toFixed(2));
      setVal('bpy', o.position[1].toFixed(2));
      setVal('bpz', o.position[2].toFixed(2));
      const cnt = panel.querySelector('.rt-bones-count'); if (cnt) cnt.textContent = tuneState.boneOffsets.size;
    }
  };

  const rebuildAnimChips = () => {
    const animBar = panel.querySelector('.pose-anim-bar');
    if (!animBar) return;
    animBar.innerHTML = '';
    const FRIENDLY = { idle:'idle', walk:'walk', aim_rifle:'run + rifle', reload:'reload', reload_idle:'rifle idle' };
    for (const [name, action] of tuneState.actions.entries()) {
      const b = document.createElement('button');
      b.textContent = FRIENDLY[name] || name; b.title = name;
      if (action === tuneState.currentAction) b.classList.add('active');
      b.addEventListener('click', () => {
        animBar.querySelectorAll('button').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        if (tuneState.mixer) tuneState.mixer.timeScale = 1;
        // Picking an animation implicitly exits bind pose (you want to see
        // the anim playing). Sync the toggle button if it's visible.
        if (tuneState.bindPose) {
          tuneState.bindPose = false;
          const bindBtn = panel.querySelector('.rt-bind-toggle');
          if (bindBtn) {
            bindBtn.classList.remove('active');
            bindBtn.textContent = '🦴 Bind pose OFF (animating)';
          }
        }
        const pBtn = animBar.querySelector('[data-pause]');
        if (pBtn) { pBtn.classList.remove('active'); pBtn.textContent = '⏸ pause'; }
        if (tuneState.currentAction && tuneState.currentAction !== action) {
          action.reset().play();
          tuneState.currentAction.crossFadeTo(action, 0.25, false);
        } else { action.reset().play(); }
        tuneState.currentAction = action;
      });
      animBar.appendChild(b);
    }
    if (tuneState.actions.size > 0) {
      const pauseBtn = document.createElement('button');
      pauseBtn.textContent = '⏸ pause'; pauseBtn.dataset.pause = '';
      pauseBtn.addEventListener('click', () => {
        const paused = pauseBtn.classList.toggle('active');
        if (tuneState.mixer) tuneState.mixer.timeScale = paused ? 0 : 1;
        pauseBtn.textContent = paused ? '▶ resume' : '⏸ pause';
      });
      animBar.appendChild(pauseBtn);
    }
  };

  const attachPropToBone = (boneName) => {
    if (!tuneState.propScene || !tuneState.charScene) return;
    if (tuneState.propScene.parent) tuneState.propScene.parent.remove(tuneState.propScene);
    const bone = tuneState.charScene.getObjectByName(boneName);
    if (bone) bone.add(tuneState.propScene);
  };

  const reload = async () => {
    propTouched = false; // new char/prop load resets the "was touched" flag
    // Tear down current scene contents (keep grid + lights)
    if (tuneState.charScene) scene.remove(tuneState.charScene);
    tuneState.charScene = tuneState.propScene = null;
    tuneState.mixer = null;
    tuneState.actions.clear();
    tuneState.bones = [];
    // Reset per-clip offset stores and point boneOffsets back to default scope
    tuneState.boneOffsetsDefault.clear();
    tuneState.boneOffsetsOverrides.clear();
    tuneState.boneOffsetScope = 'default';
    tuneState.boneOffsets = tuneState.boneOffsetsDefault;

    const loader = makeGLTFLoader();
    let charGltf, propGltf = null;
    try {
      charGltf = await new Promise((res, rej) => loader.load(`/assets/${currentCharacter}?t=${Date.now()}`, res, null, rej));
      if (currentProp) propGltf = await new Promise((res, rej) => loader.load(`/assets/${currentProp}?t=${Date.now()}`, res, null, rej));
    } catch (e) {
      console.error('[fs-rig] load failed', e); fsMeta.textContent = `· load failed: ${e?.message}`; return;
    }
    if (stop) return;

    const cs = charGltf.scene;
    const cBox = new THREE.Box3().setFromObject(cs);
    const cSize = cBox.getSize(new THREE.Vector3());
    const cScale = 2 / Math.max(cSize.x, cSize.y, cSize.z);
    cs.scale.setScalar(cScale);
    cs.position.copy(cBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(cScale);
    const cBox2 = new THREE.Box3().setFromObject(cs);
    cs.position.y -= cBox2.min.y;
    scene.add(cs);
    tuneState.charScene = cs;

    cs.traverse(o => { if (o.type === 'Bone' && o.name) tuneState.bones.push(o); });

    // Capture each bone's BIND POSE — the LOCAL position/rotation as authored
    // in the GLB. We capture RIGHT AFTER load, before any animation runs, so
    // the bones are still at their authored bind values. We deliberately DO
    // NOT call skeleton.pose() here — that helper writes world-space matrices
    // and decomposes them locally assuming the armature root is at identity.
    // Since we scale+center charScene, pose() corrupts the root bone's local
    // values (Hips ends up with world coords as if local) — bind capture
    // would record garbage and the model would render lying on the floor.
    tuneState.bindPoses = new Map();
    tuneState.lastAnimQ.clear();
    for (const b of tuneState.bones) {
      tuneState.bindPoses.set(b.name, {
        position:   b.position.clone(),
        quaternion: b.quaternion.clone(),
      });
      // Seed lastAnimQ with bind values so applyAll has a valid baseline to
      // reset to BEFORE the first mixer.update runs (or for characters that
      // have no animations at all). Otherwise the first applyAll iteration
      // would multiply offsets without resetting → compounding.
      tuneState.lastAnimQ.set(b.name, {
        pos:  b.position.clone(),
        quat: b.quaternion.clone(),
      });
    }

    if (charGltf.animations?.length > 0) {
      tuneState.mixer = new THREE.AnimationMixer(cs);
      for (const clip of charGltf.animations) {
        const action = tuneState.mixer.clipAction(clip); action.setLoop(THREE.LoopRepeat, Infinity);
        tuneState.actions.set(clip.name.replace(/^.*[|:.]/, '').toLowerCase(), action);
      }
      const startName = tuneState.actions.has('idle') ? 'idle' : tuneState.actions.keys().next().value;
      tuneState.currentAction = tuneState.actions.get(startName);
      tuneState.currentAction?.play();
    }

    // Load existing tune for this character
    try {
      const r = await fetch(`/api/tune/${encodeURIComponent(currentCharacter)}`);
      if (r.ok) {
        const data = await r.json();
        tuneState.tune = data;
        // Parse boneOffsets — supports both old flat format and new {default, overrides} format.
        const rawBo = data.boneOffsets || {};
        const parseInto = (m, flat) => {
          for (const [name, o] of Object.entries(flat || {}))
            m.set(name, { rotation: o.rotation || [0,0,0], position: o.position || [0,0,0] });
        };
        if (rawBo.default !== undefined || rawBo.overrides !== undefined) {
          // New format
          parseInto(tuneState.boneOffsetsDefault, rawBo.default || {});
          for (const [clip, boneMap] of Object.entries(rawBo.overrides || {})) {
            const m = new Map();
            parseInto(m, boneMap);
            tuneState.boneOffsetsOverrides.set(clip, m);
          }
        } else {
          // Old flat format — treat as default (backward compat)
          parseInto(tuneState.boneOffsetsDefault, rawBo);
        }
        tuneState.boneOffsets = tuneState.boneOffsetsDefault;
        tuneState.boneOffsetScope = 'default';
        // If there's a saved pose for the current prop, hydrate it
        if (currentProp && data.props?.[currentProp]) {
          const p = data.props[currentProp];
          tuneState.propBone = p.bone || tuneState.propBone;
          tuneState.propPose = { position: p.position||[0,0,0], rotation: p.rotation||[0,0,-Math.PI/2], scale: p.scale ?? 0.9 };
        }
      }
    } catch {}

    // Attach prop
    if (propGltf) {
      const ps = propGltf.scene;
      const pBox = new THREE.Box3().setFromObject(ps);
      const pSize = pBox.getSize(new THREE.Vector3());
      const pScale = 0.6 / Math.max(pSize.x, pSize.y, pSize.z);
      ps.scale.setScalar(pScale);
      ps.position.copy(pBox.getCenter(new THREE.Vector3())).negate().multiplyScalar(pScale);
      tuneState.propScene = ps;
      attachPropToBone(tuneState.propBone);
    }

    // Frame camera
    const sz = cBox2.getSize(new THREE.Vector3());
    const dist = Math.max(sz.x, sz.y, sz.z) * 1.4;
    camera.position.set(dist * 0.6, sz.y * 0.6, dist * 0.9);
    controls.target.set(0, sz.y * 0.5, 0); controls.update();

    fsMeta.textContent = `· ${tuneState.bones.length} bones · ${tuneState.actions.size} clips · ${tuneState.boneOffsets.size} offsets`;
    renderPanel();
    rebuildAnimChips();
    updateCharInfo();
    applyGizmoTarget();
    refreshStatsOverlay();
    // Re-apply current wireframe mode so the new char/prop respect the toggle
    // state if the PM had previously hit 2 or 3.
    if (_wireframeMode !== 1) setWireframeMode(_wireframeMode);
  };

  // Capture mixer output to lastAnimQ so applyAll can reset bones BEFORE
  // multiplying offsets each frame. ONLY capture when mixer is actively
  // playing (timeScale > 0). When paused, bone.q already has the previous
  // frame's offset multiplied in; capturing it would lock the offset into
  // lastAnimQ and the next applyAll would multiply offset on top → compounding
  // (same bug we're trying to fix). Skipping capture when paused preserves
  // the last clean anim_q snapshot from when the mixer was running.
  const captureLastAnim = () => {
    if (!tuneState.charScene) return;
    if (!tuneState.mixer || tuneState.mixer.timeScale <= 0) return;
    for (const b of tuneState.bones) {
      let e = tuneState.lastAnimQ.get(b.name);
      if (!e) { e = { quat: new THREE.Quaternion(), pos: new THREE.Vector3() }; tuneState.lastAnimQ.set(b.name, e); }
      e.quat.copy(b.quaternion);
      e.pos.copy(b.position);
    }
  };

  // Apply loop: bone offsets + prop pose, run each frame after mixer.update
  const _eul = new THREE.Euler(); const _quat = new THREE.Quaternion(); const _vec = new THREE.Vector3();
  const applyAll = () => {
    if (!tuneState.charScene) return;
    // During bone gizmo drag, skip applyAll entirely. The render loop also
    // skips mixer.update during drag (so bone.q is not refreshed from anim
    // each frame). If applyAll's offset multiply ran, it would COMPOUND the
    // offset onto bone.q every frame (since there's no mixer reset to clear
    // it), making the bone rotate further on each frame even with a stationary
    // cursor. With both skipped, TC owns the dragged bone exclusively and
    // other bones freeze at their pre-drag pose — acceptable for calibration.
    if (tuneState.boneGizmoActive) return;
    // RESET PHASE: every frame, restore bones to a known clean baseline before
    // multiplying offsets. Two modes:
    //   - bindPose=true: reset to captured bind values (T-pose calibration view)
    //   - bindPose=false: reset to lastAnimQ (the last value mixer wrote — could
    //     be the current playing frame, or the last frame mixer ran before pause)
    // Without this reset, offsets compound onto bone.q each frame because
    // PropertyMixer.apply skips writes when its buffer didn't change (paused
    // anim, or static loop wrap moments). The "rotates crazily when paused"
    // bug was exactly this: mixer.update no-op on paused frames + applyAll
    // multiply each frame = exponential rotation.
    const skipBoneName = null;
    if (tuneState.bindPose && tuneState.bindPoses) {
      for (const b of tuneState.bones) {
        if (b.name === skipBoneName) continue;
        const bind = tuneState.bindPoses.get(b.name);
        if (!bind) continue;
        b.position.copy(bind.position);
        b.quaternion.copy(bind.quaternion);
      }
    } else if (tuneState.lastAnimQ.size > 0) {
      for (const b of tuneState.bones) {
        if (b.name === skipBoneName) continue;
        const e = tuneState.lastAnimQ.get(b.name);
        if (!e) continue;
        b.position.copy(e.pos);
        b.quaternion.copy(e.quat);
      }
    }
    // Effective offset: per-clip override takes priority over default.
    // This means editing the 'run' scope while the 'idle' clip plays will
    // show the idle default for bones not in the run override — giving a
    // realistic preview of the combined result.
    const _effClipName = [...tuneState.actions.entries()].find(([,a]) => a === tuneState.currentAction)?.[0] ?? '';
    const _effOvr = tuneState.boneOffsetsOverrides.get(_effClipName);
    const _effBones = new Set([...tuneState.boneOffsetsDefault.keys(), ...(_effOvr ? _effOvr.keys() : [])]);
    for (const name of _effBones) {
      if (name === skipBoneName) continue;
      const off = (_effOvr?.get(name)) ?? tuneState.boneOffsetsDefault.get(name);
      if (!off) continue;
      const b = tuneState.charScene.getObjectByName(name); if (!b) continue;
      _eul.set(off.rotation[0], off.rotation[1], off.rotation[2]);
      _quat.setFromEuler(_eul); b.quaternion.multiply(_quat);
      // Position offsets are stored in WORLD-unit-equivalent. Convert to
      // bone-local before adding (multiply by inv = 1/boneWorldScale).
      // Matches prop-pose convention and the pose calibrator.
      const ws = new THREE.Vector3();
      b.getWorldScale(ws);
      const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
      _vec.set(off.position[0] * inv, off.position[1] * inv, off.position[2] * inv);
      b.position.add(_vec);
    }
    if (tuneState.propScene && tuneState.propScene.parent) {
      // Skip writing position/rotation/scale to the prop while the user is
      // dragging the gizmo on it — TransformControls sets propScene.* and we
      // don't want applyAll to immediately overwrite it. The drag-changed
      // listener takes care of syncing pose state from the new transforms.
      if (!tuneState.propGizmoActive) {
        const bone = tuneState.propScene.parent;
        const ws = new THREE.Vector3(); bone.getWorldScale(ws);
        const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
        const p = tuneState.propPose;
        tuneState.propScene.position.set(p.position[0]*inv, p.position[1]*inv, p.position[2]*inv);
        tuneState.propScene.rotation.set(p.rotation[0], p.rotation[1], p.rotation[2]);
        tuneState.propScene.scale.setScalar(p.scale * inv);
      }
    }
  };

  // ── Gizmo (Blender-style W/E/R + world/local) ────────────────────────────
  // One TransformControls instance, swap its target between propScene (Prop tab)
  // and the selected bone (Bone offsets tab). For bone gizmo we force bind
  // pose so the bone is at rest while user drags; on drag end we read the
  // delta vs the captured bindPose and store as the offset.
  const gizmo = new TransformControls(camera, renderer.domElement);
  gizmo.setSpace('world');
  gizmo.setSize(0.7);
  if (typeof gizmo.getHelper === 'function') scene.add(gizmo.getHelper());
  else scene.add(gizmo);

  const applyGizmoTarget = () => {
    gizmo.detach();
    if (!tuneState.charScene) return;
    if (activeTab === 'prop' && tuneState.propScene) {
      gizmo.attach(tuneState.propScene);
    } else if (activeTab === 'bones') {
      const b = tuneState.charScene.getObjectByName(tuneState.selectedOffsetBone);
      if (b) gizmo.attach(b);
    }
  };

  // Disable orbit while dragging the gizmo. Track active state on tuneState
  // so applyAll skips its overwrite during drag.
  gizmo.addEventListener('dragging-changed', (ev) => {
    controls.enabled = !ev.value;
    if (activeTab === 'prop') tuneState.propGizmoActive = ev.value;
    if (activeTab === 'bones') {
      tuneState.boneGizmoActive = ev.value;
      if (ev.value) {
        // Drag start: pause the mixer so the anim doesn't drift while user is
        // tuning. Capture the bone's CURRENT animated state (bone.q before any
        // offset was applied this frame) so we can compute the drag delta as
        // an additive offset on top of the anim. Result: model stays in its
        // current anim pose during drag, no T-pose flash.
        if (tuneState.mixer) {
          tuneState._wasMixerScale = tuneState.mixer.timeScale;
          tuneState.mixer.timeScale = 0;
        }
        const b = tuneState.charScene?.getObjectByName(tuneState.selectedOffsetBone);
        if (b) {
          // The bone's current state is `anim_q × effective_offset_q`. We need
          // the pure anim part as the reference. Subtract the EFFECTIVE offset
          // that applyAll just applied (override for active clip → default).
          // Using only the editing-scope's entry would give a wrong baseline
          // when a different scope is what's actually visible.
          const _activeClipName = [...tuneState.actions.entries()].find(([,a]) => a === tuneState.currentAction)?.[0] ?? '';
          const _activeOvr = tuneState.boneOffsetsOverrides.get(_activeClipName);
          const existing = _activeOvr?.get(tuneState.selectedOffsetBone)
            ?? tuneState.boneOffsetsDefault.get(tuneState.selectedOffsetBone);
          if (existing) {
            const exQ = new THREE.Quaternion().setFromEuler(
              new THREE.Euler(existing.rotation[0], existing.rotation[1], existing.rotation[2])
            );
            tuneState._dragRefQ = b.quaternion.clone().multiply(exQ.invert());
            const ws = new THREE.Vector3(); b.getWorldScale(ws);
            const inv = ws.x > 0.0001 ? 1 / ws.x : 1;
            const exPosLocal = new THREE.Vector3(existing.position[0]*inv, existing.position[1]*inv, existing.position[2]*inv);
            tuneState._dragRefPos = b.position.clone().sub(exPosLocal);
          } else {
            tuneState._dragRefQ = b.quaternion.clone();
            tuneState._dragRefPos = b.position.clone();
          }
        }
      } else {
        // Drag end: restore mixer scale.
        if (tuneState.mixer && tuneState._wasMixerScale !== undefined) {
          tuneState.mixer.timeScale = tuneState._wasMixerScale;
          tuneState._wasMixerScale = undefined;
        }
        tuneState._dragRefQ = null;
        tuneState._dragRefPos = null;
      }
    }
  });

  // Live sync: when gizmo moves the prop or bone, update tuneState
  gizmo.addEventListener('objectChange', () => {
    if (activeTab === 'prop' && tuneState.propScene && tuneState.propScene.parent) {
      const bone = tuneState.propScene.parent;
      const ws = new THREE.Vector3(); bone.getWorldScale(ws);
      const boneScale = ws.x > 0.0001 ? ws.x : 1;
      // Convert local prop transforms back to world-unit pose values
      tuneState.propPose.position[0] = tuneState.propScene.position.x * boneScale;
      tuneState.propPose.position[1] = tuneState.propScene.position.y * boneScale;
      tuneState.propPose.position[2] = tuneState.propScene.position.z * boneScale;
      tuneState.propPose.rotation[0] = tuneState.propScene.rotation.x;
      tuneState.propPose.rotation[1] = tuneState.propScene.rotation.y;
      tuneState.propPose.rotation[2] = tuneState.propScene.rotation.z;
      tuneState.propPose.scale = tuneState.propScene.scale.x * boneScale;
      propTouched = true;
      refreshLabels && refreshLabels();
    }
    if (activeTab === 'bones') {
      const b = tuneState.charScene?.getObjectByName(tuneState.selectedOffsetBone);
      // Reference: the bone's anim-only state captured at drag start.
      // bone.q at drag end = anim_q × new_offset_q  →  new_offset_q = anim_q⁻¹ × bone.q
      // This makes offsets ADDITIVE on top of the animation (post-multiply),
      // so the model stays in anim pose during drag (no T-pose flash) and
      // the offset still works uniformly across every clip.
      const refQ = tuneState._dragRefQ;
      const refPos = tuneState._dragRefPos;
      if (!b || !refQ || !refPos) return;
      const offQ = refQ.clone().invert().multiply(b.quaternion);
      const eu = new THREE.Euler().setFromQuaternion(offQ, 'XYZ');
      // Position offset in WORLD units (multiply local delta by bone world scale)
      const ws = new THREE.Vector3();
      b.getWorldScale(ws);
      const localDelta = new THREE.Vector3().subVectors(b.position, refPos);
      const worldDelta = localDelta.multiplyScalar(ws.x);
      if (!tuneState.boneOffsets.has(tuneState.selectedOffsetBone)) {
        tuneState.boneOffsets.set(tuneState.selectedOffsetBone, { rotation:[0,0,0], position:[0,0,0] });
      }
      const off = tuneState.boneOffsets.get(tuneState.selectedOffsetBone);
      off.rotation[0] = eu.x; off.rotation[1] = eu.y; off.rotation[2] = eu.z;
      off.position[0] = worldDelta.x; off.position[1] = worldDelta.y; off.position[2] = worldDelta.z;
      cleanIfZero && cleanIfZero();
      refreshLabels && refreshLabels();
    }
  });

  // Mode + space switchers — wired via panel buttons (renderTabBody adds them)
  const setGizmoMode = (mode) => {
    // Translate + Scale gizmos on bones cause SkinnedMesh stretching: moving
    // a bone's origin shifts vertices weighted to it but NOT vertices weighted
    // to its parent, so the seam between them deforms. Rotation pivots around
    // the joint without stretching. Force rotate on Bone offsets tab.
    if (activeTab === 'bones' && (mode === 'translate' || mode === 'scale')) {
      mode = 'rotate';
    }
    panel.querySelectorAll('.rt-gizmo-btn').forEach(b => b.classList.toggle('active', b.dataset.gz === mode));
    if (mode === 'off') { gizmo.enabled = false; gizmo.visible = false; return; }
    gizmo.enabled = true; gizmo.visible = true;
    gizmo.setMode(mode);
  };
  const setGizmoSpace = (space) => {
    panel.querySelectorAll('.rt-gizmo-space').forEach(b => b.classList.toggle('active', b.dataset.sp === space));
    gizmo.setSpace(space);
  };

  const saveTune = async () => {
    // Snap floating-point noise on save. Rotation values from the gizmo or
    // sliders often end up as 0.30000000000000004 etc. — clean numbers in the
    // JSON help with diffs, debug, and copy-paste. Precision chosen:
    //   - rotation: 4 decimal places of radians = ~0.006° precision (overkill
    //     for visual rigging, plenty for game runtime)
    //   - position: 4 decimal places of world units = 0.1mm precision
    //   - scale: 3 decimal places (~0.1% precision)
    // Also drops trailing zeros: 0.5236 instead of 0.523600000000001.
    const snap = (n, d = 4) => {
      if (typeof n !== 'number' || !isFinite(n)) return 0;
      // Quantize to grid at 10^-d to remove float noise, then round to d decimals
      const m = Math.pow(10, d);
      return Math.round(n * m) / m;
    };
    const snapArr = (arr, d = 4) => arr.map(v => snap(v, d));
    const body = {
      boneOffsets: { default: {}, overrides: {} },
      props: {},
    };
    for (const [name, o] of tuneState.boneOffsetsDefault) {
      body.boneOffsets.default[name] = { rotation: snapArr(o.rotation, 4), position: snapArr(o.position, 4) };
    }
    for (const [clip, m] of tuneState.boneOffsetsOverrides) {
      if (m.size === 0) continue;
      body.boneOffsets.overrides[clip] = {};
      for (const [name, o] of m) {
        body.boneOffsets.overrides[clip][name] = { rotation: snapArr(o.rotation, 4), position: snapArr(o.position, 4) };
      }
    }
    // Only write the current prop's pose if the user actually touched it this session.
    // Without this guard, every Save while on the Bone Offsets tab would overwrite
    // the previously-calibrated prop pose with the default values loaded from tune.json.
    if (currentProp && tuneState.propScene && propTouched) {
      body.props[currentProp] = {
        bone: tuneState.propBone,
        position: snapArr(tuneState.propPose.position, 4),
        rotation: snapArr(tuneState.propPose.rotation, 4),
        scale: snap(tuneState.propPose.scale, 3),
      };
    }
    // Preserve ALL props that were already saved (including currentProp if not touched)
    if (tuneState.tune?.props) {
      for (const [name, val] of Object.entries(tuneState.tune.props)) {
        if (!body.props[name]) body.props[name] = val;
      }
    }
    const btn = panel.querySelector('.rt-save');
    const old = btn.textContent; btn.textContent = 'Saving…'; btn.disabled = true;
    try {
      const res = await fetch(`/api/tune/${encodeURIComponent(currentCharacter)}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      tuneState.tune = body;
      btn.textContent = `✅ ${data.boneCount} bones, ${data.propCount} props`;
    } catch (e) { btn.textContent = `❌ ${e.message}`; console.error(e); }
    setTimeout(() => { btn.textContent = old; btn.disabled = false; }, 1800);
  };

  // Wireframe + stats helpers MUST be declared before `await reload()` because
  // the reload() body calls both. JS const/let are hoisted but in the TDZ until
  // their declaration runs — putting them after reload() invocation causes
  // "Cannot access 'setWireframeMode' before initialization" and reload silently
  // aborts mid-flight (no model renders).
  let _wireframeMode = 1;            // 1=solid, 2=wireframe-all, 3=overlay-all
  const _edgeOverlay = [];
  const _wfTargets = new Set();      // mesh UUIDs that are individually wireframed (click selection)
  // Walk char + prop scenes ONCE each, with deduplication. The prop is parented
  // to a bone inside the char's armature, so traversing the char already covers
  // the prop — but if propScene is detached (no parent), we walk it directly.
  // Deduplicate via a visited Set so a mesh seen via both paths processes once.
  const _forEachMesh = (cb) => {
    const seen = new Set();
    const visit = (root) => {
      if (!root) return;
      root.traverse(o => {
        if (o.isMesh && o.material && !seen.has(o.uuid)) {
          seen.add(o.uuid);
          cb(o);
        }
      });
    };
    visit(tuneState.charScene);
    // Only walk propScene if it's NOT already a descendant of charScene
    // (avoids the double-pass that caused inconsistent wireframe + duplicate edges).
    if (tuneState.propScene) {
      let p = tuneState.propScene.parent;
      let isDescOfChar = false;
      while (p) {
        if (p === tuneState.charScene) { isDescOfChar = true; break; }
        p = p.parent;
      }
      if (!isDescOfChar) visit(tuneState.propScene);
    }
  };
  const applyWireframeState = () => {
    for (const e of _edgeOverlay) e.parent?.remove(e);
    _edgeOverlay.length = 0;
    _forEachMesh(o => {
      const wantWire = _wireframeMode === 2 || _wfTargets.has(o.uuid);
      const mats = Array.isArray(o.material) ? o.material : [o.material];
      for (const m of mats) if ("wireframe" in m) m.wireframe = wantWire;
      // Mode 3 adds an edge-line overlay on top of the (still solid) mesh.
      // Skip when this mesh is individually wireframed (overlay would be redundant).
      if (_wireframeMode === 3 && o.geometry && !_wfTargets.has(o.uuid)) {
        const eg = new THREE.EdgesGeometry(o.geometry, 30);
        const em = new THREE.LineBasicMaterial({ color: 0x9aebbf, depthTest: true, transparent: true, opacity: 0.85 });
        const edges = new THREE.LineSegments(eg, em);
        edges.userData.__edgeOverlay = true;
        o.add(edges);
        _edgeOverlay.push(edges);
      }
    });
  };
  const setWireframeMode = (mode) => { _wireframeMode = mode; applyWireframeState(); };

  // Click-to-select wireframe: when global mode is 1 (solid), clicking a mesh
  // in the canvas toggles its individual wireframe. Lets the PM inspect ONE
  // specific mesh in wireframe without losing context on the rest. Shift+click
  // toggles WITHOUT touching the others (additive); plain click resets selection
  // first so it acts as "isolate this mesh in wireframe".
  const _wfRaycaster = new THREE.Raycaster();
  const _wfMouse = new THREE.Vector2();
  const onCanvasClick = (e) => {
    // Skip if the gizmo is being dragged (controls.enabled === false), or if the
    // click was on the panel (e.target inside #fs-pose-panel).
    if (e.target.closest && e.target.closest('#fs-pose-panel')) return;
    if (tuneState.boneGizmoActive || tuneState.propGizmoActive) return;
    if (gizmo.dragging) return;
    const rect = fsCanvas.getBoundingClientRect();
    _wfMouse.x = ((e.clientX - rect.left) / rect.width)  *  2 - 1;
    _wfMouse.y = ((e.clientY - rect.top)  / rect.height) * -2 + 1;
    _wfRaycaster.setFromCamera(_wfMouse, camera);
    const targets = [];
    _forEachMesh(o => targets.push(o));
    const hits = _wfRaycaster.intersectObjects(targets, false);
    if (!hits.length) return;
    const hit = hits[0].object;
    if (!e.shiftKey) {
      // Plain click: isolate this mesh. Clear others first.
      _wfTargets.clear();
    }
    if (_wfTargets.has(hit.uuid)) _wfTargets.delete(hit.uuid);
    else _wfTargets.add(hit.uuid);
    applyWireframeState();
    // Update stats hint to confirm which mesh is selected.
    if (statsOverlay && _wireframeMode === 1) {
      const isolatedCount = _wfTargets.size;
      const hint = statsOverlay.querySelector('.wf-isolate-hint');
      if (hint) {
        hint.textContent = isolatedCount === 0
          ? 'Press 1/2/3 for solid/wireframe/overlay · click mesh to isolate'
          : `Wireframing ${isolatedCount} mesh${isolatedCount === 1 ? '' : 'es'} (shift+click to add, 1 to reset)`;
      }
    }
  };
  fsCanvas.addEventListener('click', onCanvasClick);

  const statsOverlay = document.createElement('div');
  statsOverlay.className = 'rt-stats-overlay';
  statsOverlay.style.cssText = 'position:absolute;bottom:8px;left:8px;background:rgba(0,0,0,.55);backdrop-filter:blur(6px);border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:6px 10px;font:11px/1.4 system-ui;color:#cfe5ff;pointer-events:none;z-index:5;font-variant-numeric:tabular-nums;display:none;';
  fsCanvas.parentNode?.appendChild(statsOverlay);
  const refreshStatsOverlay = () => {
    let tris = 0, verts = 0, meshes = 0, texBytes = 0;
    const texSeen = new Set();
    const walk = (root) => {
      if (!root) return;
      root.traverse(o => {
        if (o.isMesh && o.geometry) {
          meshes++;
          const g = o.geometry;
          const pos = g.attributes?.position;
          if (pos) verts += pos.count;
          if (g.index) tris += g.index.count / 3;
          else if (pos) tris += pos.count / 3;
          const mats = Array.isArray(o.material) ? o.material : [o.material];
          for (const m of mats) {
            for (const k of ["map","normalMap","roughnessMap","metalnessMap","aoMap","emissiveMap"]) {
              const t = m?.[k];
              if (t?.image && !texSeen.has(t)) {
                texSeen.add(t);
                const w = t.image.width || 0, h = t.image.height || 0;
                texBytes += w * h * 4;
              }
            }
          }
        }
      });
    };
    walk(tuneState.charScene); walk(tuneState.propScene);
    const fmtN = n => n >= 1e6 ? (n/1e6).toFixed(1)+'M' : n >= 1e3 ? (n/1e3).toFixed(1)+'k' : String(Math.round(n));
    const texMB = texBytes / (1024 * 1024);
    statsOverlay.innerHTML =
      `<div>📐 <b>${fmtN(tris)}</b> tris · <b>${fmtN(verts)}</b> verts · <b>${meshes}</b> meshes</div>` +
      `<div>🖼 <b>${texMB.toFixed(2)}</b> MB tex (${texSeen.size} unique)</div>` +
      `<div class="wf-isolate-hint" style="color:#888;">Press 1/2/3 for solid/wireframe/overlay · click mesh to isolate</div>`;
    statsOverlay.style.display = 'block';
  };

  // Boot — initial render and load
  renderPanel();
  await reload();

  function onResize() {
    if (stop) return;
    renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
    camera.aspect = fsCanvas.clientWidth / fsCanvas.clientHeight;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', onResize);

  // Keyboard shortcuts (Blender-ish): W/E/R modes, Q world/local, G toggle, Shift snap,
  // 1/2/3 wireframe mode.
  const onKey = (e) => {
    if (!fsModal.classList.contains('open')) return;
    if (e.target instanceof HTMLElement && (e.target.isContentEditable || e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) return;
    if (e.key === 'w' || e.key === 'W') { e.preventDefault(); setGizmoMode('translate'); }
    else if (e.key === 'e' || e.key === 'E') { e.preventDefault(); setGizmoMode('rotate'); }
    else if (e.key === 'r' || e.key === 'R') { e.preventDefault(); setGizmoMode('scale'); }
    else if (e.key === 'g' || e.key === 'G') { e.preventDefault(); setGizmoMode(gizmo.visible ? 'off' : 'translate'); }
    else if (e.key === 'q' || e.key === 'Q') { e.preventDefault(); setGizmoSpace(gizmo.space === 'world' ? 'local' : 'world'); }
    else if (e.key === '1') { e.preventDefault(); _wfTargets.clear(); setWireframeMode(1); }
    else if (e.key === '2') { e.preventDefault(); setWireframeMode(2); }
    else if (e.key === '3') { e.preventDefault(); setWireframeMode(3); }
    else if (e.shiftKey) {
      gizmo.setTranslationSnap(0.05); gizmo.setRotationSnap(THREE.MathUtils.degToRad(15)); gizmo.setScaleSnap(0.1);
    }
  };
  const onKeyUp = (e) => {
    if (!e.shiftKey) { gizmo.setTranslationSnap(null); gizmo.setRotationSnap(null); gizmo.setScaleSnap(null); }
  };
  window.addEventListener('keydown', onKey);
  window.addEventListener('keyup', onKeyUp);

  fsState.cleanup = () => {
    window.removeEventListener('resize', onResize);
    window.removeEventListener('keydown', onKey);
    window.removeEventListener('keyup', onKeyUp);
    fsCanvas.removeEventListener('click', onCanvasClick);
    if (statsOverlay && statsOverlay.parentNode) statsOverlay.parentNode.removeChild(statsOverlay);
    try { gizmo.detach(); gizmo.dispose(); } catch {}
    const helper = gizmo.getHelper && gizmo.getHelper();
    if (helper && helper.parent) helper.parent.remove(helper);
    renderer.dispose();
    if (panel) { panel.style.display = 'none'; panel.innerHTML = ''; }
  };
  setTimeout(onResize, 50);

  let lastT = performance.now();
  (function loop(now) {
    if (stop) return;
    requestAnimationFrame(loop);
    const dt = Math.min(((now||performance.now()) - lastT) / 1000, 0.1);
    lastT = now || performance.now();
    // Skip mixer.update entirely during a bone gizmo drag. timeScale=0 only
    // halts clip time advancement — the mixer still WRITES bone.q each frame
    // (via binding.apply with the current accumulated values), which fights
    // the TransformControls writes and the user sees the bone snapping back to
    // anim_q each frame. Skipping update gives TC exclusive ownership of the
    // dragged bone; other bones freeze at their last animated pose, which is
    // what we want for calibration anyway.
    if (!tuneState.boneGizmoActive) {
      // Pre-mixer reset: copy lastAnimQ onto bone.q BEFORE mixer.update runs.
      // This guarantees bone.q is in a clean (offset-free) state. mixer.update
      // either overwrites with fresh anim values (still clean, no offset
      // baked in) or skips when its accumulator buffer didn't change. Either
      // way, the post-mixer captureLastAnim sees a clean bone.q. Without this
      // pre-reset, on frames where mixer skips writes (paused, or clip flat
      // sections), captureLastAnim would see the previous applyAll's output
      // (which has offsets baked in) and lock the offset into lastAnimQ —
      // next frame's applyAll would then multiply offset again on top → the
      // exact compounding bug we're fighting.
      for (const b of tuneState.bones) {
        const e = tuneState.lastAnimQ.get(b.name);
        if (!e) continue;
        b.position.copy(e.pos);
        b.quaternion.copy(e.quat);
      }
      tuneState.mixer?.update(dt);
      captureLastAnim();
    }
    applyAll();
    controls.update();
    renderer.render(scene, camera);
  })();
}

// ── Procedural mom (shared-renderer) ──────────────────────────────────────────
function makeProcMomCard(container) {
  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.style.cssText = 'width:100%;height:200px;display:block;cursor:grab;background:#0d1520;position:relative;';
  container.replaceChild(placeholder, spinnerEl);

  let scene, camera, controls;
  // The animate loop and chip click handler reference these via closure.
  let root, leftLeg, rightLeg, torso, head, LA, RA, badge, animBar;
  let pI = 0, pT = 0, autoPlay = true, t = 0;
  const POSES = ['WALK','IDLE','CARRY','RIFLE'];

  // Single init — scene lives forever, master loop only renders when visible.
  scene    = makeBaseScene();
  camera   = new THREE.PerspectiveCamera(42, 1.2, 0.01, 50);
  camera.position.set(0, 2.2, 5);
  controls = new OrbitControls(camera, placeholder);
  controls.target.set(0,1,0); controls.enableDamping = true; controls.dampingFactor = .08; controls.update();
  buildRig(scene);

  function buildRig(_scene) {

  const M = {
    skin:  new THREE.MeshLambertMaterial({color:0xf0c69a}), hair: new THREE.MeshLambertMaterial({color:0x6b4a2e}),
    shirt: new THREE.MeshLambertMaterial({color:0xc94a55}), sleeve:new THREE.MeshLambertMaterial({color:0xa83a45}),
    pants: new THREE.MeshLambertMaterial({color:0x3a4a72}), boot: new THREE.MeshLambertMaterial({color:0x2a1a10}),
    eye:   new THREE.MeshBasicMaterial({color:0x1a1a1a}),   pack: new THREE.MeshLambertMaterial({color:0x6b4a2e}),
  };
  const CYL=(rt,rb,h,s)=>new THREE.CylinderGeometry(rt,rb,h,s);
  const BOX=(x,y,z)=>new THREE.BoxGeometry(x,y,z);
  const SPH=(r,ws,hs)=>new THREE.SphereGeometry(r,ws,hs);
  const mk=(geo,mat,px=0,py=0,pz=0)=>{const m=new THREE.Mesh(geo,mat);m.position.set(px,py,pz);return m;};

  root=new THREE.Group();
  const makeLeg=x=>{const h=new THREE.Group();h.position.set(x,.85,0);h.add(mk(CYL(.13,.12,.5,10),M.pants,0,-.25,0));h.add(mk(CYL(.10,.10,.45,10),M.pants,0,-.70,0));h.add(mk(BOX(.25,.18,.32),M.boot,0,-.93,.04));return h;};
  leftLeg=makeLeg(-.13);rightLeg=makeLeg(.13);
  root.add(leftLeg,rightLeg);
  torso=new THREE.Group();torso.position.set(0,.85,0);
  torso.add(mk(CYL(.32,.30,.7,12),M.shirt,0,.35,0));torso.add(mk(CYL(.31,.31,.06,12),M.boot,0,.04,0));torso.add(mk(BOX(.46,.42,.18),M.pack,0,.55,-.32));
  root.add(torso);
  head=new THREE.Group();head.position.set(0,1.10,0);
  head.add(mk(SPH(.22,16,14),M.skin));
  const hc=new THREE.Mesh(new THREE.SphereGeometry(.235,14,10,0,Math.PI*2,0,Math.PI/1.6),M.hair);hc.position.y=.04;head.add(hc);
  const pony=mk(SPH(.13,10,8),M.hair,0,-.05,-.22);pony.scale.set(1,1.4,.7);head.add(pony);
  head.add(mk(SPH(.025,6,5),M.eye,-.08,.02,.20));head.add(mk(SPH(.025,6,5),M.eye,.08,.02,.20));
  torso.add(head);
  const makeArm=(x,right)=>{const sh=new THREE.Group();sh.position.set(x,.62,0);sh.add(mk(CYL(.085,.075,.36,10),M.sleeve,0,-.18,0));const elbow=new THREE.Group();elbow.position.y=-.36;elbow.add(mk(CYL(.07,.06,.32,10),M.skin,0,-.16,0));const hand=new THREE.Group();hand.position.y=-.32;const hm=mk(SPH(.085,10,8),M.skin);hm.scale.set(1,.7,1);hand.add(hm);elbow.add(hand);sh.add(elbow);sh.rotation.x=-.05;sh.rotation.z=right?-.04:.04;return sh;};
  LA=makeArm(-.34,false);RA=makeArm(.34,true);
  torso.add(LA,RA);
  _scene.add(root);
  } // end of buildRig

  // — UI: stats line + chip bar + badge built ONCE on first init (DOM is reused)
  container.querySelector('.stats').innerHTML='<span>🦴 7 bones</span><span class="has-anim">✦ walk·idle·carry·rifle</span>';

  // Animation chip bar — built-in poses for the procedural rig
  animBar = document.createElement('div');
  animBar.className = 'anim-bar';
  animBar.innerHTML =
    `<span class="anim-label">Animation</span>` +
    `<button class="anim-chip auto active" data-auto>AUTO</button>` +
    POSES.map((p,i) => `<button class="anim-chip" data-i="${i}">${p}</button>`).join('');
  const infoEl = container.querySelector('.info');
  container.insertBefore(animBar, infoEl);

  // Tiny live status indicator (top-left, below the fs-btn / hist-btn)
  badge = document.createElement('div');
  badge.style.cssText='position:absolute;top:42px;left:8px;font-size:10px;font-weight:700;letter-spacing:1px;color:var(--accent);background:rgba(0,0,0,.55);padding:2px 7px;border-radius:10px;pointer-events:none;z-index:5;';
  container.insertBefore(badge, container.firstChild);

  function setActive(idx, auto) {
    animBar.querySelectorAll('.anim-chip').forEach(c => c.classList.remove('active'));
    if (auto) { animBar.querySelector('[data-auto]').classList.add('active'); autoPlay = true; }
    else      { animBar.querySelector(`[data-i="${idx}"]`).classList.add('active'); autoPlay = false; pI = idx; pT = 0; }
  }
  animBar.addEventListener('click', e => {
    const btn = e.target.closest('.anim-chip');
    if (!btn) return;
    if (btn.dataset.auto !== undefined) setActive(0, true);
    else setActive(parseInt(btn.dataset.i, 10), false);
  });

  const RAD=d=>d*Math.PI/180,lerp=(a,b,k)=>a+(b-a)*k;

  registerCard({
    placeholder,
    scene, camera, controls,
    bgColor: 0x0d1520,
    update: (dt) => {
      t += dt;
      if (autoPlay) { pT += dt; if (pT > 4.5) { pT = 0; pI = (pI + 1) % POSES.length; } }
      if (badge) badge.textContent = (autoPlay ? '🔄 ' : '') + POSES[pI];
      const p = POSES[pI];
      if(p==='WALK'){const ph=t*9;leftLeg.rotation.x=Math.sin(ph)*RAD(36);rightLeg.rotation.x=-Math.sin(ph)*RAD(36);LA.rotation.x=-Math.sin(ph)*RAD(24)-.05;RA.rotation.x=Math.sin(ph)*RAD(24)-.05;torso.rotation.z=Math.sin(ph)*RAD(5);root.position.y=Math.abs(Math.sin(ph))*.07;}
      else if(p==='IDLE'){torso.scale.y=1+Math.sin(t*1.8)*.02;root.position.y=0;torso.rotation.z=Math.sin(t*.7)*RAD(2);head.rotation.z=Math.sin(t*.5)*RAD(3);leftLeg.rotation.x=lerp(leftLeg.rotation.x,0,.1);rightLeg.rotation.x=lerp(rightLeg.rotation.x,0,.1);LA.rotation.x=lerp(LA.rotation.x,-.05,.08);RA.rotation.x=lerp(RA.rotation.x,-.05,.08);}
      else if(p==='CARRY'){const ph=t*8;leftLeg.rotation.x=Math.sin(ph)*RAD(28);rightLeg.rotation.x=-Math.sin(ph)*RAD(28);root.position.y=Math.abs(Math.sin(ph))*.06;LA.rotation.x=lerp(LA.rotation.x,RAD(28),.12);RA.rotation.x=lerp(RA.rotation.x,RAD(28),.12);LA.rotation.z=lerp(LA.rotation.z,RAD(18),.1);RA.rotation.z=lerp(RA.rotation.z,RAD(-18),.1);torso.rotation.x=lerp(torso.rotation.x,RAD(9),.1);}
      else if(p==='RIFLE'){root.position.y=0;leftLeg.rotation.x=lerp(leftLeg.rotation.x,0,.1);rightLeg.rotation.x=lerp(rightLeg.rotation.x,0,.1);RA.rotation.x=lerp(RA.rotation.x,RAD(-72),.15);LA.rotation.x=lerp(LA.rotation.x,RAD(-58),.15);torso.rotation.x=lerp(torso.rotation.x,RAD(-6),.1);const sT=(t%.9)/.9;if(sT<.07)RA.rotation.x-=.25*(1-sT/.07);}
    },
  });
}

// ── Generic procedural-card spawner ───────────────────────────────────────────
// Factories below use this to avoid 30 lines of canvas/renderer/orbit boilerplate
// per asset. The build() callback receives the scene + the card container so it
// can add geometry and update stats.
function spawnProcGalleryCard(container, build, opts = {}) {
  // Shared-renderer pattern: replace the per-card WebGL canvas with a <div>
  // placeholder. Master loop renders into it via viewport+scissor when visible.
  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.style.cssText = 'width:100%;height:200px;display:block;cursor:grab;background:#0d1520;position:relative;';
  container.replaceChild(placeholder, spinnerEl);

  const scene = makeBaseScene();
  const camera = new THREE.PerspectiveCamera(opts.fov || 42, 1.2, 0.01, 50);
  const cam = opts.cam || [0, 2, 5];
  camera.position.set(cam[0], cam[1], cam[2]);
  const controls = new OrbitControls(camera, placeholder);
  const tgt = opts.target || [0, 1, 0];
  controls.target.set(tgt[0], tgt[1], tgt[2]);
  controls.enableDamping = true; controls.dampingFactor = .08;
  controls.autoRotate = opts.autoRotate !== false;
  controls.autoRotateSpeed = opts.autoRotateSpeed || 1.4;
  controls.update();
  build(scene, container);

  // Per-card update: if the build callback wired scene.userData.update for
  // particle/flame animations, master loop will call it via this hook.
  registerCard({
    placeholder,
    scene, camera, controls,
    bgColor: 0x0d1520,
    update: (dt) => { try { scene.userData.update?.(dt); } catch {} },
  });
}

// ── Procedural environment factories (mirror what main.ts builds in-game) ────
function makeProcTree(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const tree = new THREE.Group();
    const trunkMat = new THREE.MeshLambertMaterial({color: 0x5a3a20});
    const snowMat = new THREE.MeshLambertMaterial({color: 0xeff4f7});
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.32, 1.5, 7), trunkMat);
    trunk.position.y = 0.75; tree.add(trunk);
    const tiers = [{r:1.4,h:1.1,y:1.55,cm:0x2d4a2e},{r:1.15,h:1.05,y:2.10,cm:0x3a5a3a},{r:0.9,h:1.0,y:2.65,cm:0x2d4a2e},{r:0.62,h:0.95,y:3.20,cm:0x4a6a4a}];
    for (const t of tiers) {
      const cone = new THREE.Mesh(new THREE.ConeGeometry(t.r, t.h, 7), new THREE.MeshLambertMaterial({color: t.cm}));
      cone.position.y = t.y; tree.add(cone);
      const snow = new THREE.Mesh(new THREE.ConeGeometry(t.r * 1.08, t.h * 0.45, 7), snowMat);
      snow.position.y = t.y + t.h/2 - t.h*0.45/2 - 0.02; tree.add(snow);
    }
    const tipSnow = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.36, 6), snowMat);
    tipSnow.position.y = 3.95; tree.add(tipSnow);
    scene.add(tree);
    c.querySelector('.stats').innerHTML = '<span>🌲 4 cone tiers + snow caps</span><span class="has-anim">✦ procedural live</span>';
  }, { cam: [3.5, 2.8, 4.5], target: [0, 2, 0] });
}

function makeProcCabin(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const cab = new THREE.Group();
    const wood = new THREE.MeshLambertMaterial({color: 0xa89580});
    const woodDark = new THREE.MeshLambertMaterial({color: 0x8a7560});
    const roof = new THREE.MeshLambertMaterial({color: 0x5b6470});
    const snow = new THREE.MeshLambertMaterial({color: 0xeff4f7});
    const W = 4.5, D = 3.5, H = 2.0;
    // Floor
    cab.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(W + 0.4, 0.12, D + 0.4), woodDark);_m.position.set(0,0,0);return _m;})());
    // 4 stacked log walls (cylinders) — front, back, left, right
    const logR = 0.12;
    for (let i = 0; i < 8; i++) {
      const y = 0.18 + i * (logR * 1.8);
      const log1 = new THREE.Mesh(new THREE.CylinderGeometry(logR, logR, W, 8), wood);
      log1.rotation.z = Math.PI / 2; log1.position.set(0, y, -D/2); cab.add(log1);
      const log2 = log1.clone(); log2.position.z = D/2; cab.add(log2);
      const log3 = new THREE.Mesh(new THREE.CylinderGeometry(logR, logR, D, 8), wood);
      log3.rotation.x = Math.PI / 2; log3.position.set(-W/2, y, 0); cab.add(log3);
      const log4 = log3.clone(); log4.position.x = W/2; cab.add(log4);
    }
    // Pitched roof — two angled boxes
    const rR = new THREE.Mesh(new THREE.BoxGeometry(W + 0.5, 0.1, D * 0.78), roof);
    rR.position.set(0, H + 0.45, D * 0.22); rR.rotation.x = -0.4;
    cab.add(rR);
    const rL = rR.clone(); rL.position.z = -D * 0.22; rL.rotation.x = 0.4; cab.add(rL);
    // Snow on roof
    const sR = new THREE.Mesh(new THREE.BoxGeometry(W + 0.55, 0.05, D * 0.78), snow);
    sR.position.set(0, H + 0.52, D * 0.22); sR.rotation.x = -0.4; cab.add(sR);
    const sL = sR.clone(); sL.position.z = -D * 0.22; sL.rotation.x = 0.4; cab.add(sL);
    // Door (front, dark rectangle)
    const door = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.4, 0.08), new THREE.MeshLambertMaterial({color: 0x4a3a28}));
    door.position.set(0, 0.78, D/2 + 0.05); cab.add(door);
    // Window (broken — dark rectangle on side)
    const window1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.6, 0.7), new THREE.MeshBasicMaterial({color: 0x1a2238}));
    window1.position.set(W/2 + 0.04, 1.1, 0); cab.add(window1);
    scene.add(cab);
    c.querySelector('.stats').innerHTML = '<span>🏚 8 log courses</span><span class="has-anim">✦ procedural cut-away approx</span>';
  }, { cam: [6, 5, 7], target: [0, 1.2, 0] });
}

function makeProcBed(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const bed = new THREE.Group();
    const woodDark = new THREE.MeshLambertMaterial({color: 0x6b4a2e});
    const mattressMat = new THREE.MeshLambertMaterial({color: 0xe6d8c4});
    const quiltMat = new THREE.MeshLambertMaterial({color: 0xa05a6c}); // pink
    const pillowMat = new THREE.MeshLambertMaterial({color: 0xf1eadd});
    bed.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.4, 1.6), woodDark);_m.position.set(0,0.2,0);return _m;})());
    // 4 corner posts
    for (const [x,z] of [[-1.3,-0.7],[1.3,-0.7],[-1.3,0.7],[1.3,0.7]]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 1.4, 8), woodDark);
      p.position.set(x, 0.7 + 0.2, z); bed.add(p);
    }
    bed.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.24, 1.4), mattressMat);_m.position.set(0,0.52,0);return _m;})());
    bed.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.13, 1.25), quiltMat);_m.position.set(0,0.71,0.05);return _m;})());
    bed.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.14, 0.5), pillowMat);_m.position.set(-0.85,0.72,-0.4);return _m;})());
    scene.add(bed);
    c.querySelector('.stats').innerHTML = '<span>🛏 frame + posts + quilt</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [3.5, 2.5, 4], target: [0, 0.5, 0] });
}

function makeProcFireplace(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const fp = new THREE.Group();
    const stone = new THREE.MeshLambertMaterial({color: 0x8a8580});
    const stoneDark = new THREE.MeshLambertMaterial({color: 0x6a6560});
    const dark = new THREE.MeshLambertMaterial({color: 0x1a1108});
    fp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.5, 1.0), stoneDark);_m.position.set(0,0.25,0);return _m;})());
    fp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.2, 0.8), stone);_m.position.set(-0.85,1.1,0);return _m;})());
    fp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.2, 0.8), stone);_m.position.set(0.85,1.1,0);return _m;})());
    fp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.32, 0.9), stone);_m.position.set(0,1.85,0);return _m;})());
    fp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.05, 0.5), dark);_m.position.set(0,1.0,0.15);return _m;})());
    fp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(1.1, 4.6, 0.95), stoneDark);_m.position.set(0,4.3,-0.05);return _m;})());
    // Animated flame inside the hearth
    const flame = new THREE.Mesh(new THREE.SphereGeometry(0.35, 12, 10), new THREE.MeshBasicMaterial({color: 0xff9a4a, transparent: true, opacity: .85}));
    flame.position.set(0, 0.85, 0.22); flame.scale.set(1, 1.6, 0.7);
    fp.add(flame);
    scene.add(fp);
    let t = 0;
    scene.userData.update = dt => {
      t += dt;
      flame.scale.y = 1.6 + Math.sin(t * 5) * 0.18;
      flame.scale.x = 1 + Math.sin(t * 6.7) * 0.1;
      flame.material.opacity = 0.78 + Math.sin(t * 8) * 0.1;
    };
    // scene.userData.update wired above; master loop calls it via shared renderer.
    c.querySelector('.stats').innerHTML = '<span>🔥 hearth + chimney + flame</span><span class="has-anim">✦ procedural live</span>';
  }, { cam: [4, 3.5, 6], target: [0, 1.5, 0] });
}

function makeProcFence(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const f = new THREE.Group();
    const fenceMat = new THREE.MeshLambertMaterial({color: 0x6b5235});
    const postMat = new THREE.MeshLambertMaterial({color: 0x4a3a28});
    const snowMat = new THREE.MeshLambertMaterial({color: 0xeff4f7});
    // 3 posts
    for (let i = 0; i < 3; i++) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1.0, 0.18), postMat);
      p.position.set((i - 1) * 1.6, 0.5, 0); f.add(p);
    }
    // 2 horizontal rails between posts
    for (let i = 0; i < 2; i++) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.15, 0.1), fenceMat);
      rail.position.set(0, 0.32 + i * 0.5, 0); f.add(rail);
    }
    // Snow caps on top of posts
    for (let i = 0; i < 3; i++) {
      const s = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.06, 0.22), snowMat);
      s.position.set((i - 1) * 1.6, 1.03, 0); f.add(s);
    }
    scene.add(f);
    c.querySelector('.stats').innerHTML = '<span>🪵 3 posts + 2 rails + snow</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [2.5, 1.8, 3.5], target: [0, 0.5, 0] });
}

function makeProcWoodPlank(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const plank = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, 0.3), new THREE.MeshLambertMaterial({color: 0x8a6a4a}));
    plank.position.y = 0.04; scene.add(plank);
    // Subtle grain stripes
    for (let i = 0; i < 3; i++) {
      const s = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.005, 0.04), new THREE.MeshLambertMaterial({color: 0x6a4a2e}));
      s.position.set(0, 0.085, -0.1 + i * 0.1); scene.add(s);
    }
    c.querySelector('.stats').innerHTML = '<span>🪵 wood plank</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [1.2, 0.9, 1.4], target: [0, 0.05, 0], autoRotateSpeed: 2.5 });
}

function makeProcMedkit(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const grp = new THREE.Group();
    const white = new THREE.MeshLambertMaterial({color: 0xf4f4f4});
    const lid = new THREE.MeshLambertMaterial({color: 0xe0e0e0});
    const red = new THREE.MeshLambertMaterial({color: 0xd83a3a});
    const dark = new THREE.MeshLambertMaterial({color: 0x666666});
    // Body
    grp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.32, 0.4), white);_m.position.set(0,0.16,0);return _m;})());
    // Lid
    grp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.06, 0.42), lid);_m.position.set(0,0.35,0);return _m;})());
    // Latch
    grp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.05, 0.05), dark);_m.position.set(0,0.32,0.22);return _m;})());
    // Red cross — vertical bar
    grp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.04, 0.22), red);_m.position.set(0,0.21,0.21);return _m;})());
    // Red cross — horizontal bar
    grp.add((()=>{const _m=new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.04, 0.08), red);_m.position.set(0,0.21,0.21);return _m;})());
    scene.add(grp);
    c.querySelector('.stats').innerHTML = '<span>💊 medkit + cross</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [1.4, 1, 1.6], target: [0, 0.2, 0], autoRotateSpeed: 2 });
}

function makeProcRifleBarrel(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.8, 12), new THREE.MeshLambertMaterial({color: 0x4a4a4a, emissive: 0x222222}));
    barrel.rotation.z = Math.PI / 2; barrel.position.y = 0.1;
    scene.add(barrel);
    // Front sight nub
    const sight = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.06, 0.04), new THREE.MeshLambertMaterial({color: 0x2a2a2a}));
    sight.position.set(0.32, 0.16, 0); scene.add(sight);
    c.querySelector('.stats').innerHTML = '<span>🔫 barrel cylinder</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [1.2, 0.8, 1.4], target: [0, 0.1, 0], autoRotateSpeed: 2.5 });
}

function makeProcRifleStock(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const wood = new THREE.MeshLambertMaterial({color: 0x6b4a2e});
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.16, 0.14), wood);
    stock.position.set(0, 0.18, 0); scene.add(stock);
    // Butt plate
    const butt = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.22, 0.16), new THREE.MeshLambertMaterial({color: 0x2a1a10}));
    butt.position.set(-0.28, 0.18, 0); scene.add(butt);
    // Forearm taper (thinner box)
    const forearm = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.1, 0.12), wood);
    forearm.position.set(0.22, 0.21, 0); scene.add(forearm);
    c.querySelector('.stats').innerHTML = '<span>🪵 wooden stock</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [1.2, 0.9, 1.4], target: [0, 0.18, 0], autoRotateSpeed: 2.5 });
}

function makeProcRifleScope(container) {
  spawnProcGalleryCard(container, (scene, c) => {
    const black = new THREE.MeshLambertMaterial({color: 0x18191b});
    const lensMat = new THREE.MeshBasicMaterial({color: 0x4a90e2, transparent: true, opacity: 0.7});
    const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.18, 12), black);
    scope.rotation.z = Math.PI / 2; scope.position.y = 0.15;
    scene.add(scope);
    // Front lens
    const lens1 = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.02, 12), lensMat);
    lens1.rotation.z = Math.PI / 2; lens1.position.set(0.1, 0.15, 0);
    scene.add(lens1);
    // Back eyepiece
    const eye = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.04, 12), black);
    eye.rotation.z = Math.PI / 2; eye.position.set(-0.1, 0.15, 0);
    scene.add(eye);
    // Mounting ring
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.04, 12), new THREE.MeshLambertMaterial({color: 0x2a2a2a}));
    ring.position.y = 0.1; scene.add(ring);
    c.querySelector('.stats').innerHTML = '<span>🔭 scope + lens + ring</span><span class="has-anim">✦ procedural</span>';
  }, { cam: [1.2, 0.7, 1.4], target: [0, 0.15, 0], autoRotateSpeed: 2.5 });
}

// ── VFX Cards (lazy WebGL init — same rationale as spawnProcGalleryCard) ─────
function makeVFXCard(container, vfxType) {
  const spinnerEl = container.querySelector('.spinner');
  const placeholder = document.createElement('div');
  placeholder.style.cssText = 'width:100%;height:200px;display:block;background:#0d1520;position:relative;';
  container.replaceChild(placeholder, spinnerEl);

  let scene, camera, statsText='';

  // Single init — scene lives forever.
  scene  = new THREE.Scene(); scene.background = new THREE.Color(0x0d1520); makeLights(scene);
  camera = new THREE.PerspectiveCamera(50, 1.2, .01, 50);
  camera.position.set(0, 3, 5); camera.lookAt(0, .5, 0);
  const _g = new THREE.Mesh(new THREE.PlaneGeometry(6,6), new THREE.MeshLambertMaterial({color:0x0a1525}));
  _g.rotation.x = -Math.PI/2; scene.add(_g);
  buildVFXScene();
  container.querySelector('.stats').textContent = statsText;

  // Wrap the existing VFX builder logic in a function so we can call it during init
  function buildVFXScene() {
  if(vfxType==='chips'){
    const P=14,pool=[],geo=new THREE.SphereGeometry(.07,5,4),mat=new THREE.MeshLambertMaterial({color:0xc8a47a});
    for(let i=0;i<P;i++){const m=new THREE.Mesh(geo,mat.clone());m.visible=false;scene.add(m);pool.push({mesh:m,vx:0,vy:0,vz:0,life:0,maxLife:1});}
    let timer=0;scene.userData.update=dt=>{timer-=dt;if(timer<=0){timer=1.2;for(const p of pool){const a=Math.random()*Math.PI*2,sp=2+Math.random()*2;p.mesh.position.set(0,.3,0);p.mesh.visible=true;p.vx=Math.cos(a)*sp*.8;p.vy=2+Math.random()*2;p.vz=Math.sin(a)*sp*.8;p.life=0;p.maxLife=.4+Math.random()*.3;}}for(const p of pool){if(!p.mesh.visible)continue;p.life+=dt;p.vy-=9.8*dt;p.mesh.position.x+=p.vx*dt;p.mesh.position.y+=p.vy*dt;p.mesh.position.z+=p.vz*dt;p.mesh.scale.setScalar(Math.max(.001,1-p.life/p.maxLife));if(p.life>=p.maxLife)p.mesh.visible=false;}};
    statsText=`🪵 ${P} particles · loop 1.2s`;
  } else if(vfxType==='blood'){
    const P=18,pool=[],geo=new THREE.SphereGeometry(.065,5,4),mat=new THREE.MeshLambertMaterial({color:0xcc2233});
    for(let i=0;i<P;i++){const m=new THREE.Mesh(geo,mat.clone());m.visible=false;scene.add(m);pool.push({mesh:m,vx:0,vy:0,vz:0,life:0,maxLife:1});}
    let timer=0;scene.userData.update=dt=>{timer-=dt;if(timer<=0){timer=1.0;for(const p of pool){const a=Math.random()*Math.PI*2,sp=1.5+Math.random()*2.5;p.mesh.position.set(0,.8,0);p.mesh.visible=true;p.vx=Math.cos(a)*sp*.9;p.vy=1+Math.random()*3;p.vz=Math.sin(a)*sp*.9;p.life=0;p.maxLife=.35+Math.random()*.25;}}for(const p of pool){if(!p.mesh.visible)continue;p.life+=dt;p.vy-=9.8*dt;p.mesh.position.x+=p.vx*dt;p.mesh.position.y=Math.max(0,p.mesh.position.y+p.vy*dt);p.mesh.position.z+=p.vz*dt;p.mesh.scale.setScalar(Math.max(.001,1-p.life/p.maxLife));if(p.life>=p.maxLife)p.mesh.visible=false;}};
    statsText='🩸 18 particles · loop 1.0s';
  } else if(vfxType==='sparkle'){
    const P=20,pool=[],geo=new THREE.SphereGeometry(.06,5,4),mat=new THREE.MeshBasicMaterial({color:0xffd700});
    for(let i=0;i<P;i++){const m=new THREE.Mesh(geo,mat.clone());m.visible=false;scene.add(m);pool.push({mesh:m,vx:0,vy:0,vz:0,life:0,maxLife:1});}
    let timer=0;scene.userData.update=dt=>{timer-=dt;if(timer<=0){timer=.85;for(const p of pool){const a=Math.random()*Math.PI*2,sp=.8+Math.random()*1.5;p.mesh.position.set(0,.1,0);p.mesh.visible=true;p.vx=Math.cos(a)*sp*.5;p.vy=1.5+Math.random()*2;p.vz=Math.sin(a)*sp*.5;p.life=0;p.maxLife=.5+Math.random()*.35;}}for(const p of pool){if(!p.mesh.visible)continue;p.life+=dt;p.vy-=2*dt;p.mesh.position.x+=p.vx*dt;p.mesh.position.y+=p.vy*dt;p.mesh.position.z+=p.vz*dt;p.mesh.scale.setScalar(Math.max(.001,1-p.life/p.maxLife));if(p.life>=p.maxLife)p.mesh.visible=false;}};
    statsText='✨ 20 particles · loop 0.85s';
  } else if(vfxType==='fire'){
    const fg=new THREE.Group();scene.add(fg);
    const layers=[{r:.38,color:0xff7700,y:0,speed:2.3,amp:.08},{r:.28,color:0xff4400,y:.2,speed:3.1,amp:.06},{r:.18,color:0xffcc00,y:.4,speed:4.2,amp:.04}];
    const lms=layers.map(l=>{const m=new THREE.Mesh(new THREE.SphereGeometry(l.r,12,10),new THREE.MeshBasicMaterial({color:l.color,transparent:true,opacity:.85}));m.position.y=l.y;m.scale.set(1,1.4,1);fg.add(m);return Object.assign(m,l);});
    const ep=[],eg=new THREE.SphereGeometry(.035,4,3);
    for(let i=0;i<14;i++){const m=new THREE.Mesh(eg,new THREE.MeshBasicMaterial({color:0xffaa00}));m.visible=false;scene.add(m);ep.push({mesh:m,life:0,maxLife:1,vx:0,vy:0,vz:0});}
    let t=0,et=0;scene.userData.update=dt=>{t+=dt;et-=dt;for(const l of lms){const f=1+Math.sin(t*l.speed+l.y*10)*l.amp;l.scale.x=f;l.scale.z=f*.85;l.scale.y=1.4+Math.sin(t*l.speed*.7)*.12;l.material.opacity=.75+Math.sin(t*l.speed*1.3)*.12;}if(et<=0){et=.08+Math.random()*.1;const e=ep.find(e=>!e.mesh.visible);if(e){e.mesh.visible=true;e.mesh.position.set((Math.random()-.5)*.3,.3,(Math.random()-.5)*.3);e.vx=(Math.random()-.5)*.5;e.vy=1+Math.random()*1.5;e.vz=(Math.random()-.5)*.5;e.life=0;e.maxLife=.4+Math.random()*.5;}}for(const e of ep){if(!e.mesh.visible)continue;e.life+=dt;e.vx*=.95;e.vz*=.95;e.mesh.position.x+=e.vx*dt;e.mesh.position.y+=e.vy*dt;e.mesh.position.z+=e.vz*dt;e.mesh.scale.setScalar(Math.max(.001,1-e.life/e.maxLife));if(e.life>=e.maxLife)e.mesh.visible=false;}};
    statsText='🔥 3 layers + 14 embers · live';
  } else if(vfxType==='muzzle_flash'){
    // Bright yellow-orange burst at rifle muzzle. Loop 0.6s = in-game fire rate.
    const flash=new THREE.Mesh(new THREE.SphereGeometry(.22,12,10),new THREE.MeshBasicMaterial({color:0xffd97a,transparent:true,opacity:0}));flash.position.y=.5;scene.add(flash);
    const sparks=[];const sg=new THREE.SphereGeometry(.045,5,4);
    for(let i=0;i<8;i++){const m=new THREE.Mesh(sg,new THREE.MeshBasicMaterial({color:0xff9a3a,transparent:true,opacity:0}));m.visible=false;scene.add(m);sparks.push({mesh:m,vx:0,vy:0,vz:0,life:0,maxLife:.22});}
    let timer=0;scene.userData.update=dt=>{timer-=dt;if(timer<=0){timer=.6;flash.material.opacity=1;flash.scale.setScalar(1);for(const s of sparks){const a=Math.random()*Math.PI*2,sp=2.5+Math.random()*1.5;s.mesh.position.set(0,.5,0);s.mesh.visible=true;s.mesh.material.opacity=1;s.vx=Math.cos(a)*sp;s.vy=(Math.random()-.3)*1.5;s.vz=Math.sin(a)*sp;s.life=0;}}flash.material.opacity=Math.max(0,flash.material.opacity-dt*7);flash.scale.setScalar(1+(1-flash.material.opacity)*.4);for(const s of sparks){if(!s.mesh.visible)continue;s.life+=dt;s.mesh.position.x+=s.vx*dt;s.mesh.position.y+=s.vy*dt;s.mesh.position.z+=s.vz*dt;s.vy-=4*dt;s.mesh.material.opacity=Math.max(0,1-s.life/s.maxLife);if(s.life>=s.maxLife)s.mesh.visible=false;}};
    statsText='🔫 1 flash + 8 sparks · loop 0.6s';
  } else if(vfxType==='pow_burst'){
    // Yellow star with 6 elongated bars radiating — comic-book POW! impact.
    const grp=new THREE.Group();grp.position.y=.6;scene.add(grp);
    const bg=new THREE.BoxGeometry(.5,.08,.08);const bm=new THREE.MeshBasicMaterial({color:0xffd97a,transparent:true,opacity:0});
    const bars=[];for(let i=0;i<6;i++){const b=new THREE.Mesh(bg,bm.clone());b.rotation.z=i*Math.PI/3;grp.add(b);bars.push(b);}
    const core=new THREE.Mesh(new THREE.SphereGeometry(.12,10,8),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0}));grp.add(core);
    let timer=0,age=0;scene.userData.update=dt=>{timer-=dt;age+=dt;if(timer<=0){timer=.5;age=0;for(const b of bars)b.material.opacity=1;core.material.opacity=1;grp.scale.setScalar(.7);}const k=Math.min(age/.3,1);grp.scale.setScalar(.7+k*.6);for(const b of bars)b.material.opacity=Math.max(0,1-age/.32);core.material.opacity=Math.max(0,1-age/.18);};
    statsText='💥 6-bar star + core · loop 0.5s';
  } else if(vfxType==='bullet_streak'){
    // White elongated capsule trail, bullet path. Loop 1s.
    const cap=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,1.6,8),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:0}));cap.rotation.z=Math.PI/2;cap.position.y=.5;scene.add(cap);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.06,8,6),new THREE.MeshBasicMaterial({color:0xfff4d6,transparent:true,opacity:0}));head.position.set(.8,.5,0);scene.add(head);
    let timer=0,age=0;scene.userData.update=dt=>{timer-=dt;age+=dt;if(timer<=0){timer=1.0;age=0;cap.material.opacity=1;head.material.opacity=1;cap.scale.x=.05;}cap.scale.x=Math.min(1,age/.08);cap.material.opacity=Math.max(0,1-(age-.08)/.25);head.material.opacity=Math.max(0,1-(age-.05)/.18);};
    statsText='💨 1.6m streak · loop 1.0s';
  } else if(vfxType==='damage_flash'){
    // Red ring of 12 particles expanding outward — player hit cue. Loop 1.2s.
    const P=12,pool=[];const dg=new THREE.SphereGeometry(.06,5,4);
    for(let i=0;i<P;i++){const m=new THREE.Mesh(dg,new THREE.MeshBasicMaterial({color:0xff3344,transparent:true,opacity:0}));m.visible=false;scene.add(m);pool.push({mesh:m,vx:0,vz:0,life:0,maxLife:.6});}
    const ring=new THREE.Mesh(new THREE.RingGeometry(.1,.16,24),new THREE.MeshBasicMaterial({color:0xff3344,transparent:true,opacity:0,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.05;scene.add(ring);
    let timer=0,age=0;scene.userData.update=dt=>{timer-=dt;age+=dt;if(timer<=0){timer=1.2;age=0;ring.material.opacity=.9;ring.scale.setScalar(1);for(let i=0;i<P;i++){const a=i/P*Math.PI*2;pool[i].mesh.position.set(0,.5,0);pool[i].mesh.visible=true;pool[i].mesh.material.opacity=1;pool[i].vx=Math.cos(a)*2;pool[i].vz=Math.sin(a)*2;pool[i].life=0;}}ring.material.opacity=Math.max(0,.9-age/.4);ring.scale.setScalar(1+age*4);for(const p of pool){if(!p.mesh.visible)continue;p.life+=dt;p.mesh.position.x+=p.vx*dt;p.mesh.position.z+=p.vz*dt;p.vx*=.94;p.vz*=.94;p.mesh.material.opacity=Math.max(0,1-p.life/p.maxLife);if(p.life>=p.maxLife)p.mesh.visible=false;}};
    statsText='🩸 12 ring + shock · loop 1.2s';
  } else if(vfxType==='shell_eject'){
    // Brass rifle shell ejected sideways with gravity + spin. Loop 0.6s.
    const shell=new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,.1,8),new THREE.MeshLambertMaterial({color:0xc9a557}));shell.visible=false;scene.add(shell);
    let timer=0;const state={vx:0,vy:0,vz:0,rx:0,rz:0,life:0,maxLife:.6};
    scene.userData.update=dt=>{timer-=dt;if(timer<=0){timer=.6;shell.visible=true;shell.position.set(0,.5,0);state.vx=1.6+Math.random()*.6;state.vy=2;state.vz=(Math.random()-.5)*.4;state.rx=Math.random()*8;state.rz=Math.random()*8;state.life=0;}if(!shell.visible)return;state.life+=dt;state.vy-=8*dt;shell.position.x+=state.vx*dt;shell.position.y+=state.vy*dt;shell.position.z+=state.vz*dt;shell.rotation.x+=state.rx*dt;shell.rotation.z+=state.rz*dt;if(shell.position.y<=.05){shell.position.y=.05;state.vy=Math.abs(state.vy)*.3;state.vx*=.6;}if(state.life>=state.maxLife)shell.visible=false;};
    statsText='🟤 brass shell · loop 0.6s';
  }
  } // end of buildVFXScene

  registerCard({
    placeholder,
    scene, camera,
    bgColor: 0x0d1520,
    update: (dt) => { try { scene.userData.update?.(dt); } catch {} },
  });
}

// ── Layer.ai model catalogs (base_model_id values verified against Layer MCP) ──
// Each entry carries eta + cost so the iter-panel can show estimates inline,
// and Claude (when processing) knows the right polling cadence.

const MODELS_3D = [
  { value: 'auto:fast',             label: '⚡ Auto · Fast iteration',                 eta: '~1-2m',   cost: '~20 CU',     tip: 'Claude picks Tripo (fast)' },
  { value: 'auto:quality',          label: '💎 Auto · Best quality',                   eta: '~2-4m',   cost: '~21-30 CU',  tip: 'Claude picks Hunyuan/Rodin' },
  { value: 'hunyuan-3d-v3.1-pro',   label: 'Hunyuan 3D v3.1 Pro (Tencent)',            eta: '2-4m',    cost: '21 CU/gen',  tip: 'default heavy' },
  { value: 'rodin',                 label: 'Rodin v2 (Hyper3D · avatars)',             eta: '1-2m',    cost: '30 CU/gen',  tip: 'best for characters' },
  { value: 'tripo-3.0',             label: 'Tripo v3.0',                                eta: '1-2m',    cost: '20 CU/gen',  tip: 'fastest 3D' },
];
const MODELS_IMG = [
  { value: 'auto:fast',               label: '⚡ Auto · Fast iteration',                eta: '~15-30s', cost: '~1-2 CU',    tip: 'Claude picks Nano Banana / FLUX' },
  { value: 'auto:quality',            label: '💎 Auto · Best quality',                  eta: '~1-4m',   cost: '~4-6 CU',    tip: 'Claude picks GPT Image 2 / Nano Banana Pro' },
  { value: 'gpt-image-2',             label: 'GPT Image 2 (OpenAI · latest)',           eta: '2-4m',    cost: '6 CU/MP',    tip: 'native transparency · slow' },
  { value: 'gpt-image-1.5',           label: 'GPT Image 1.5 (OpenAI · faster)',         eta: '41s-1m',  cost: '3.55 CU/MP', tip: 'native transparency' },
  { value: 'gemini-3-pro-image',      label: '🍌 Nano Banana Pro (Gemini 3 Pro)',       eta: '39s-1m',  cost: '4 CU/gen',   tip: 'no alpha — pair w/ rembg' },
  { value: 'gemini-3.1-flash-image',  label: '🍌 Nano Banana 2 (Gemini 3.1 Flash)',     eta: '37s-1m',  cost: '2 CU/gen',   tip: 'no alpha — pair w/ rembg' },
  { value: 'gemini-2.5-flash-image',  label: '🍌 Nano Banana (Gemini 2.5 Flash)',       eta: '14-22s',  cost: '1.5 CU/gen', tip: 'fastest Gemini' },
  { value: 'imagen-4',                label: 'Imagen 4 (Google)',                        eta: '15-29s',  cost: '1.6 CU/gen', tip: 'photoreal' },
  { value: 'flux-2-klein-9b',         label: 'FLUX.2 klein 9B (BFL)',                    eta: '6-15s',   cost: '1.2 CU/MP',  tip: 'fastest · stylized' },
];

const buildModelOptions = list =>
  list.map(m =>
    `<option value="${m.value}" data-eta="${m.eta}" data-cost="${m.cost}" data-tip="${m.tip || ''}">${m.label}</option>`
  ).join('');

// ── Iteration panel HTML builder ──────────────────────────────────────────────
function buildIterPanelHTML(modelList, placeholder, opts = {}) {
  const refSelect = opts.includeRef
    ? `<select class="iter-ref" title="Use a concept image as image-to-3D reference">` +
        `<option value="">— text-only (no concept ref) —</option>` +
      `</select>`
    : '';
  return (
    `<div class="iter-panel">` +
      `<div class="iter-header">` +
        `<span class="iter-label">Redesign this asset</span>` +
        `<button class="iter-expand" title="Expand prompt area">⤢</button>` +
      `</div>` +
      `<textarea class="iter-prompt" placeholder="${placeholder}"></textarea>` +
      `<select class="iter-model" title="Layer.ai model">` +
        buildModelOptions(modelList) +
      `</select>` +
      `<div class="model-meta"></div>` +
      refSelect +
      `<div class="iter-actions">` +
        `<button class="gen-btn primary btn-queue">⚙️ Generate</button>` +
        `<button class="gen-btn secondary btn-copy">📋 Copy</button>` +
      `</div>` +
      `<div class="gen-status"></div>` +
      `<div class="last-gen"></div>` +
    `</div>`
  );
}

// ── Card factory ──────────────────────────────────────────────────────────────
function makeCard3D(parent, name, size, badgeClass, badgeLabel, assetType) {
  const card = document.createElement('div');
  card.className='card3d'; card.dataset.asset=name; card.dataset.type=assetType||'3d';

  const iterPanel = (assetType === 'glb')
    ? buildIterPanelHTML(MODELS_3D, 'Ex: same character but warmer coat, red scarf, keep proportions.', { includeRef: true })
    : '';

  // Fullscreen + history buttons only for GLB cards
  const fsBtn   = (assetType === 'glb') ? `<button class="fs-btn" title="View fullscreen with full zoom/orbit controls">🔍</button>` : '';
  const histBtn = (assetType === 'glb') ? `<button class="hist-btn" title="Generation history for this asset">📜</button>` : '';

  card.innerHTML =
    fsBtn + histBtn +
    `<div class="spinner"><div><div class="ring"></div><div style="font-size:11px;color:var(--muted);margin-top:4px;">${name}</div></div></div>` +
    `<div class="info">` +
      `<div class="cname" title="${name}">${name}</div>` +
      `<div class="stats"></div>` +
      `<div style="margin-top:4px;display:flex;gap:6px;align-items:center;">` +
        `<span class="badge ${badgeClass}">${badgeLabel}</span>` +
        `<span style="font-size:11px;color:var(--muted);">${size}</span>` +
      `</div>` +
    `</div>` +
    iterPanel;

  parent.appendChild(card);

  if (assetType === 'glb') {
    attachIterPanel(card, name, 'glb');
    card.querySelector('.fs-btn')?.addEventListener('click', e => { e.stopPropagation(); openFsGLB(name); });
    card.querySelector('.hist-btn')?.addEventListener('click', e => { e.stopPropagation(); openHistoryDrawer(card, name); });
    renderLastGen(card, name);
  }

  return card;
}

// ── Image Cards ───────────────────────────────────────────────────────────────
function makeImageCard(parent, asset, kind = 'image') {
  const card = document.createElement('div');
  const kindCls = kind === 'concept' ? ' is-concept' : (kind === 'ref' ? ' is-ref' : '');
  card.className = 'card-img' + kindCls;
  card.dataset.asset = asset.name;
  card.dataset.kind  = kind;
  const placeholder = kind === 'concept'
    ? 'Ex: clean orthographic concept, T-pose, no shadows, plain white background.'
    : kind === 'ref'
    ? 'Ex: trace this style, simplify to flat colors, kawaii proportions, clean line.'
    : 'Ex: same style but darker background, more contrast.';

  // Refs can also be regenerated (you can ask Claude to remix an upload)
  // Concepts and images regenerate too. All use IMAGE models.
  card.innerHTML =
    `<button class="fs-btn" title="View fullscreen with zoom/pan">🔍</button>` +
    `<button class="hist-btn" title="Generation history for this asset">📜</button>` +
    `<img src="/assets/${asset.name}?t=${Date.now()}" alt="${asset.name}">` +
    `<div class="info">` +
      `<div class="cname">${asset.name}</div>` +
      `<div class="stats">${asset.size}</div>` +
    `</div>` +
    buildIterPanelHTML(MODELS_IMG, placeholder, { includeRef: true });

  parent.appendChild(card);
  attachIterPanel(card, asset.name, kind);
  attachDragReplaceTarget(card, asset.name);
  card.querySelector('.fs-btn').addEventListener('click', e => { e.stopPropagation(); openFsImage(asset.name); });
  card.querySelector('.hist-btn').addEventListener('click', e => { e.stopPropagation(); openHistoryDrawer(card, asset.name); });
  renderLastGen(card, asset.name);
  return card;
}

// ── Inline iteration panel wiring ─────────────────────────────────────────────
function attachIterPanel(card, assetName, assetType) {
  const panel    = card.querySelector('.iter-panel');
  if (!panel) return;
  const textarea = panel.querySelector('.iter-prompt');
  const modelSel = panel.querySelector('.iter-model');
  const refSel   = panel.querySelector('.iter-ref'); // GLB cards only
  const expandBtn= panel.querySelector('.iter-expand');
  const queueBtn = panel.querySelector('.btn-queue');
  const copyBtn  = panel.querySelector('.btn-copy');
  const statusEl = panel.querySelector('.gen-status');

  // Expand toggle: click ⤢ → enlarge textarea, click again → collapse
  expandBtn.addEventListener('click', () => {
    const expanded = textarea.classList.toggle('expanded');
    textarea.style.height = '';
    expandBtn.textContent = expanded ? '⤡' : '⤢';
    expandBtn.title = expanded ? 'Collapse prompt area' : 'Expand prompt area';
  });

  // Ref dropdown visual feedback (purple highlight when a concept is picked)
  if (refSel) {
    refSel.addEventListener('change', () => refSel.classList.toggle('has-ref', !!refSel.value));
  }

  // Live ETA + cost chip — updates whenever model selection changes
  const updateMetaChip = () => {
    const meta = panel.querySelector('.model-meta');
    if (!meta) return;
    const opt = modelSel.selectedOptions[0];
    if (!opt) return;
    const eta  = opt.dataset.eta  || '—';
    const cost = opt.dataset.cost || '—';
    const tip  = opt.dataset.tip  || '';
    meta.innerHTML =
      `<span class="meta-eta">⏱ ${eta}</span>` +
      `<span class="meta-cost">💰 ${cost}</span>` +
      (tip ? `<span class="meta-tip">${tip}</span>` : '');
  };
  modelSel.addEventListener('change', updateMetaChip);
  updateMetaChip(); // initial render

  queueBtn.addEventListener('click', async () => {
    const prompt = textarea.value.trim();
    if (!prompt) { textarea.focus(); textarea.style.borderColor='rgba(248,113,113,.6)'; setTimeout(()=>textarea.style.borderColor='',800); return; }
    const model      = modelSel.value;
    const refConcept = refSel?.value || null;
    queueBtn.disabled = true; queueBtn.textContent = '⏳ Queuing…';
    try {
      const res  = await fetch('/api/queue', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ assetName, prompt, type: assetType, model, refConcept }),
      });
      const item = await res.json();
      const modelTag = model === 'auto' ? '' : ` · model: ${model}`;
      const refTag   = refConcept ? ` · 🎨 ref: ${refConcept}` : '';
      setStatus(statusEl, 'pending', `⏳ Queued (#${item.id.slice(0,8)})${modelTag}${refTag} — tell Claude "check queue" in chat`);
      queueBtn.disabled = false; queueBtn.textContent = '⚙️ Generate';
      updateQueuePanel();
    } catch {
      setStatus(statusEl, 'error', '❌ Server not reachable');
      queueBtn.disabled = false; queueBtn.textContent = '⚙️ Generate';
    }
  });

  copyBtn.addEventListener('click', () => {
    const prompt = textarea.value.trim() || '(no prompt yet)';
    const model  = modelSel.value;
    const ref    = refSel?.value || '';
    const refLine= ref ? `\nRefConcept: ${ref}` : '';
    const text   = `[Asset Request]\nAsset: ${assetName}\nType: ${assetType}\nModel: ${model}${refLine}\nPrompt: ${prompt}`;
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = '✅ Copied!';
      setTimeout(() => { copyBtn.textContent = '📋 Copy'; }, 1500);
    });
  });
}

// ── History tracking ──────────────────────────────────────────────────────────
let HISTORY_BY_ASSET = new Map(); // name → array of entries (newest first)

async function fetchHistory() {
  try {
    const all = await fetch('/api/history').then(r => r.json());
    HISTORY_BY_ASSET.clear();
    for (const e of all) {
      if (!HISTORY_BY_ASSET.has(e.assetName)) HISTORY_BY_ASSET.set(e.assetName, []);
      HISTORY_BY_ASSET.get(e.assetName).push(e);
    }
    // Sort each list newest-first
    for (const list of HISTORY_BY_ASSET.values()) list.sort((a,b) => (b.completedAt||'').localeCompare(a.completedAt||''));
  } catch {}
}

function ago(iso) {
  if (!iso) return '';
  const ms = Date.now() - new Date(iso).getTime();
  const s = Math.floor(ms / 1000);
  if (s < 60)  return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}

function renderLastGen(card, name) {
  const lg = card.querySelector('.last-gen');
  if (!lg) return;
  const entries = HISTORY_BY_ASSET.get(name) || [];
  if (!entries.length) { lg.classList.remove('show'); lg.innerHTML = ''; return; }
  const e = entries[0];
  const refLine  = e.refConcept ? `<span class="lg-ref">🎨 ${e.refConcept}</span> · ` : '';
  const promptText = (e.prompt || '').slice(0, 80) + ((e.prompt||'').length > 80 ? '…' : '');
  lg.innerHTML =
    `Last gen <span class="lg-when">${ago(e.completedAt)}</span> · ${refLine}<span class="lg-model">${e.model}</span>` +
    (e.note ? ` · <span style="color:var(--green);">${e.note}</span>` : '') +
    `<span class="lg-prompt" title="${(e.prompt||'').replace(/"/g,'&quot;')}">"${promptText}"</span>`;
  lg.classList.add('show');

  // Mark the history button with a small pulse if there's history
  const histBtn = card.querySelector('.hist-btn');
  if (histBtn && !histBtn.querySelector('.pulse')) {
    const dot = document.createElement('span'); dot.className = 'pulse'; histBtn.appendChild(dot);
  }
}

function refreshAllLastGenLines() {
  document.querySelectorAll('.card3d[data-asset], .card-img[data-asset]').forEach(card => {
    renderLastGen(card, card.dataset.asset);
  });
}

// ── Asset swap / version navigation helpers ─────────────────────────────────
// listAssignableAssets: collects every existing file on disk that matches the
// requested kind (glb/image/audio). Used by:
//   - empty-slot dropdown (PM picks a file to fill the empty slot)
//   - filled-slot version navigator (PM swaps the active asset for another)
// Sources walked: every slot's fillAsset, orphans, images, audios, sections.
function listAssignableAssets(kind) {
  // Prefer DATA.allAssets (full disk inventory from server) when available —
  // this catches variants that exist on disk but aren't the resolved fillAsset
  // for any slot (e.g. mom_chibi.glb when mom_stylized_rigged.glb is the live
  // pick for char_mom). Fall back to walking slots/orphans/etc for older
  // servers that don't send allAssets.
  if (Array.isArray(DATA.allAssets)) {
    return DATA.allAssets
      .filter(a => a.kind === kind)
      .map(a => a.name)
      .sort();
  }
  const out = new Set();
  const exts = kind === 'glb'   ? /\.glb$/i
            : kind === 'image' ? /\.(webp|png|jpg|jpeg)$/i
            : kind === 'audio' ? /\.(mp3|ogg|wav)$/i
            : null;
  if (!exts) return [];
  const push = (n) => { if (n && exts.test(n)) out.add(n); };
  for (const s of (DATA.slots || []))    if (s.fillAsset?.name) push(s.fillAsset.name);
  for (const o of (DATA.orphans || []))  push(o.name);
  if (kind === 'image') for (const i of (DATA.images || [])) push(i.name);
  if (kind === 'audio') for (const a of (DATA.audios || [])) push(a.name);
  if (kind === 'glb')   for (const sec of (DATA.sections || [])) for (const a of (sec.assets || [])) push(a.name);
  return [...out].sort();
}

// wireSlotAssign: empty-slot "pick existing" Use-button wiring. The button is
// adjacent to a <select> whose value is the chosen source filename. On click:
// POST /api/slot/<id>/assign → server copies source → slot.fills[0].
function wireSlotAssign(card, slot) {
  const sel = card.querySelector('.slot-assign-select');
  const btn = card.querySelector('.slot-assign-btn');
  if (!sel || !btn) return;
  sel.addEventListener('change', () => { btn.disabled = !sel.value; });
  btn.addEventListener('click', async () => {
    const source = sel.value;
    if (!source) return;
    btn.disabled = true; const orig = btn.textContent; btn.textContent = '…';
    try {
      const res = await fetch(`/api/slot/${encodeURIComponent(slot.id)}/assign`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source }),
      });
      if (!res.ok) { const t = await res.text(); throw new Error(t); }
      btn.textContent = '✅'; card.classList.add('flash-update');
    } catch (e) {
      console.error('[slot-assign] failed:', e);
      btn.textContent = '❌';
      setTimeout(() => { btn.textContent = orig; btn.disabled = !sel.value; }, 1800);
    }
  });
}

// attachVersionNavigator: Krea-style ◀ N/M ▶ overlay on the card preview.
// Lists archived past versions of the live asset (from /api/archive/<name>).
// Position M = live (newest); positions 1..M-1 are archives ordered oldest→newest.
// Each arrow click is an auto-promote: ◀ promotes the immediately-older archive,
// ▶ promotes the immediately-newer one. Server's promote deletes the source
// archive after copying its binary to live, so the total count stays constant
// across rotations (no duplicate entries).
//
// Disabled state: when there are no archives (M == 1), both arrows are disabled
// and the counter shows "1/1". This matches PM's "quando nunca geramos um asset
// novo, desabilite as setinhas" — fresh slots that haven't been re-generated
// show the indicator but can't navigate.
function attachVersionNavigator(card, slot) {
  if (!card || !slot || !slot.fillAsset) return;
  const kind = slot.kind === 'glb' || slot.kind === 'image' ? slot.kind : null;
  if (!kind) return;
  const current = slot.fillAsset.name;

  const overlay = document.createElement('div');
  overlay.className = 'ver-nav-krea';
  overlay.innerHTML =
    `<button class="ver-prev" title="Older version" disabled>‹</button>` +
    `<span class="ver-count" title="Current version / total versions">—</span>` +
    `<button class="ver-next" title="Newer version" disabled>›</button>`;
  card.appendChild(overlay);

  const prev    = overlay.querySelector('.ver-prev');
  const next    = overlay.querySelector('.ver-next');
  const counter = overlay.querySelector('.ver-count');

  // versions[] = [oldest_archive, ..., newest_archive, LIVE_marker]
  // The LIVE marker has no .file (it's the current asset on disk).
  // position is 1-indexed into versions[]; position === versions.length means live.
  let versions = [];
  let position = 1;
  let busy = false;

  const updateArrowState = () => {
    prev.disabled = busy || position <= 1;
    next.disabled = busy || position >= versions.length;
  };

  const refresh = async () => {
    let archives = [];
    try {
      const r = await fetch(`/api/archive/${encodeURIComponent(current)}?t=${Date.now()}`);
      if (r.ok) archives = (await r.json()).versions || [];
    } catch {}
    // Server returns newest-first; reverse so position grows over time
    // (oldest = 1, newest archive = M-1, live = M) — matching Krea's "N/M".
    archives.reverse();
    versions = [...archives.map(v => ({ ...v, kind: 'archive' })), { kind: 'live' }];
    position = versions.length;
    counter.textContent = `${position}/${versions.length}`;
    counter.title = versions.length > 1
      ? `Version ${position} of ${versions.length} (live)`
      : `Only one version — generate or replace this asset to see history`;
    updateArrowState();
  };

  const move = async (dir) => {
    if (busy) return;
    const targetIdx = (position - 1) + dir; // 0-indexed in versions[]
    if (targetIdx < 0 || targetIdx >= versions.length) return;
    const target = versions[targetIdx];
    if (target.kind === 'live') {
      // No-op: arrow lands on the live marker itself, just update display.
      position = targetIdx + 1;
      counter.textContent = `${position}/${versions.length}`;
      updateArrowState();
      return;
    }
    busy = true; updateArrowState();
    const origCount = counter.textContent;
    counter.textContent = '…';
    try {
      const res = await fetch(`/api/archive/${encodeURIComponent(current)}/promote`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file: target.file }),
      });
      if (!res.ok) throw new Error(await res.text());
      card.classList.add('flash-update');
      setTimeout(() => card.classList.remove('flash-update'), 700);
      // Server deletes the promoted archive and adds the prior live as the
      // newest archive — total count unchanged. After refresh, position lands
      // on live (= versions.length) since that's where the just-promoted
      // binary now sits.
      await refresh();
    } catch (e) {
      console.error('[ver-nav] promote failed:', e);
      counter.textContent = '❌';
      setTimeout(() => { counter.textContent = origCount; }, 1500);
    } finally {
      busy = false;
      updateArrowState();
    }
  };

  prev.addEventListener('click', e => { e.stopPropagation(); move(-1); });
  next.addEventListener('click', e => { e.stopPropagation(); move(+1); });

  void refresh();
}


// ── History drawer (per-card overlay listing all generations of that asset) ──
// Renders TWO sections:
//   1. "Stored versions" — binary archives from assets/.history/<name>/, fetched
//      from /api/archive/<name>. Each entry has a "Use this" button that calls
//      POST /api/archive/<name>/promote → copies the archived file back to live.
//      The current live file is implicitly the head (always available).
//   2. "Generations log" — metadata-only entries from .history.json (prompts,
//      models, times). Older entries that pre-date the archive system have no
//      binary stored; show them as informational.
function openHistoryDrawer(card, name) {
  document.querySelectorAll('.hist-drawer.open').forEach(d => d.classList.remove('open'));

  let drawer = card.querySelector('.hist-drawer');
  if (!drawer) {
    drawer = document.createElement('div');
    drawer.className = 'hist-drawer';
    card.appendChild(drawer);
  }
  const entries = HISTORY_BY_ASSET.get(name) || [];
  const metaSection = entries.length === 0
    ? `<div class="hist-empty">No generations logged yet.</div>`
    : entries.map(e => {
        const refLine  = e.refConcept ? `<span class="he-ref">🎨 ${e.refConcept}</span> · ` : '';
        const promptText = (e.prompt || '').replace(/</g,'&lt;');
        return `<div class="hist-entry">
          <div><span class="he-when">${ago(e.completedAt)}</span> · ${refLine}<span class="he-model">${e.model}</span>${e.note ? ' · <span style="color:var(--green);">'+e.note+'</span>' : ''}</div>
          <div class="he-prompt">"${promptText}"</div>
        </div>`;
      }).join('');

  drawer.innerHTML =
    `<h4>📜 History — ${name} <button class="close-x">✕</button></h4>` +
    `<div class="hist-section-label">💾 Stored versions <span class="hist-hint">(click "Use this" to swap into the game)</span></div>` +
    `<div class="hist-versions"><div class="hist-empty">Loading…</div></div>` +
    `<div class="hist-section-label" style="margin-top:14px;">📝 Generations log <span class="hist-hint">(metadata from queue → done events)</span></div>` +
    metaSection;

  drawer.classList.add('open');
  drawer.querySelector('.close-x').addEventListener('click', () => drawer.classList.remove('open'));
  // Async-fetch versioned archive list and populate.
  void renderArchiveVersions(drawer, name);
}

async function renderArchiveVersions(drawer, name) {
  const slot = drawer.querySelector('.hist-versions');
  if (!slot) return;
  try {
    const r = await fetch(`/api/archive/${encodeURIComponent(name)}?t=${Date.now()}`);
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const data = await r.json();
    const versions = data.versions || [];
    if (!versions.length) {
      slot.innerHTML = `<div class="hist-empty">No prior versions stored yet.<br><span style="font-size:10px;">Generated/replaced assets are archived starting now — older runs have no binary saved.</span></div>`;
      return;
    }
    slot.innerHTML = versions.map(v => {
      const when = ago(v.mtime);
      const kb = v.size > 1024 ? `${(v.size/1024).toFixed(1)} KB` : `${v.size} B`;
      const escFile = v.file.replace(/"/g,'&quot;');
      return `<div class="hist-version">
        <div class="hv-meta">
          <span class="hv-when">${when}</span>
          <span class="hv-size">${kb}</span>
          <span class="hv-file" title="${escFile}">${v.file}</span>
        </div>
        <button class="hv-use" data-file="${escFile}">Use this</button>
      </div>`;
    }).join('');
    // Wire promotion buttons.
    slot.querySelectorAll('.hv-use').forEach(btn => {
      btn.addEventListener('click', async () => {
        const file = btn.dataset.file;
        const orig = btn.textContent;
        btn.textContent = '…'; btn.disabled = true;
        try {
          const res = await fetch(`/api/archive/${encodeURIComponent(name)}/promote`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ file }),
          });
          if (!res.ok) throw new Error(await res.text());
          btn.textContent = '✅ live';
          // SSE asset-updated will refresh the card visual. Re-fetch the
          // versions list since promote also archives the previously-live.
          setTimeout(() => renderArchiveVersions(drawer, name), 400);
        } catch (e) {
          console.error('[promote] failed:', e);
          btn.textContent = '❌'; setTimeout(() => { btn.textContent = orig; btn.disabled = false; }, 1500);
        }
      });
    });
  } catch (e) {
    slot.innerHTML = `<div class="hist-empty" style="color:#f88;">Failed to load: ${e.message}</div>`;
  }
}

// Click outside any drawer → close
document.addEventListener('click', e => {
  if (e.target.closest('.hist-drawer') || e.target.closest('.hist-btn')) return;
  document.querySelectorAll('.hist-drawer.open').forEach(d => d.classList.remove('open'));
});

// ── Concept/Ref dropdown population ───────────────────────────────────────────
let CURRENT_REFS = [];  // [{name, kind: 'ref'|'concept'}]

function refreshAllRefDropdowns() {
  const opts = `<option value="">— text-only (no concept ref) —</option>` +
    CURRENT_REFS.map(c => {
      const icon = c.kind === 'ref' ? '📎' : '🎨';
      return `<option value="${c.name}">${icon} ${c.name}</option>`;
    }).join('');
  document.querySelectorAll('.iter-ref').forEach(sel => {
    const prev = sel.value;
    sel.innerHTML = opts;
    if (prev && CURRENT_REFS.some(c => c.name === prev)) sel.value = prev;
    sel.classList.toggle('has-ref', !!sel.value);
  });
}

async function fetchConceptList() {
  // Derive from current DOM (concept + ref cards in #grid-concept)
  const fromDom = Array.from(document.querySelectorAll('.card-img[data-kind="concept"], .card-img[data-kind="ref"]'))
    .map(el => ({ name: el.dataset.asset, kind: el.dataset.kind }));
  CURRENT_REFS = fromDom;
  refreshAllRefDropdowns();
}

// ── Drag-drop "replace" handler — any card with data-asset accepts a drop
//    of a matching file type, which goes straight to disk via /api/replace/:name
//    (no queue, no Layer, instant). Used when you have the FINAL version of
//    an asset already (Figma export, hand-painted UI, etc.).
function attachDragReplaceTarget(card, assetName) {
  if (!card || !assetName) return;
  // Skip empty-slot ghost cards (the asset doesn't exist yet — there's nothing
  // to "replace"). Empty slots use the iter-panel Generate flow instead.
  if (card.classList.contains('card-empty')) return;
  // Audio rows: too small to drag-drop sensibly + they don't show on a grid.
  if (card.classList.contains('audio-row')) return;

  let depth = 0;  // dragenter/leave fire for child elements; depth-counting
                  // avoids flicker when the cursor crosses internal elements
  card.addEventListener('dragenter', e => {
    if (!e.dataTransfer || !Array.from(e.dataTransfer.types).includes('Files')) return;
    e.preventDefault();
    depth++;
    card.classList.add('drag-over');
  });
  card.addEventListener('dragover', e => {
    if (!e.dataTransfer || !Array.from(e.dataTransfer.types).includes('Files')) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
  });
  card.addEventListener('dragleave', e => {
    depth = Math.max(0, depth - 1);
    if (depth === 0) card.classList.remove('drag-over');
  });
  card.addEventListener('drop', async e => {
    e.preventDefault();
    depth = 0;
    card.classList.remove('drag-over');
    const file = e.dataTransfer?.files?.[0];
    if (!file) return;

    // Validate extension matches the slot's expected type
    const expectedExt = (assetName.match(/\.([a-z0-9]+)$/i) || [])[1]?.toLowerCase();
    const fileExt     = (file.name.match(/\.([a-z0-9]+)$/i)  || [])[1]?.toLowerCase();
    if (expectedExt && fileExt && expectedExt !== fileExt) {
      // Allow webp ↔ png/jpg interchangeably for image slots — many designers
      // export as PNG and we'll write it under the slot's webp name as-is
      // (browser handles either; the playable build pipeline re-encodes if needed)
      const imageExts = ['webp','png','jpg','jpeg'];
      const bothImage = imageExts.includes(expectedExt) && imageExts.includes(fileExt);
      if (!bothImage) {
        alert(`Type mismatch: this slot expects .${expectedExt}, you dropped .${fileExt}`);
        return;
      }
    }
    try {
      const base64 = await fileToBase64(file);
      const res = await fetch(`/api/replace/${encodeURIComponent(assetName)}`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ base64, mimeType: file.type }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      card.classList.add('drag-replace-success');
      setTimeout(() => card.classList.remove('drag-replace-success'), 900);
      // SSE asset-updated will flash + refresh the visual; no manual reload needed
    } catch (err) {
      console.error('[replace] failed:', err);
      alert(`Replace failed: ${err.message}`);
    }
  });
}

// ── Ref uploader (drag-drop + click-to-browse) ────────────────────────────────
function buildRefUploader(host) {
  host.innerHTML = `
    <span class="up-icon">📎</span>
    <div class="up-title">Upload reference image</div>
    <div class="up-hint">Drag &amp; drop a Figma export, photo, sketch, or anything to use as 3D base.<br>
    Saved as <code>ref_&lt;name&gt;.&lt;ext&gt;</code> · appears below + in every GLB card's <code>🎨 Ref</code> dropdown.</div>
    <div class="up-status"></div>
    <input type="file" accept="image/*" multiple style="display:none">
  `;
  const input  = host.querySelector('input');
  const status = host.querySelector('.up-status');

  host.addEventListener('click', e => { if (e.target.tagName !== 'INPUT') input.click(); });
  input.addEventListener('change', e => uploadFiles(e.target.files));

  ['dragover','dragenter'].forEach(ev =>
    host.addEventListener(ev, e => { e.preventDefault(); host.classList.add('dragover'); }));
  ['dragleave','dragend'].forEach(ev =>
    host.addEventListener(ev, e => { e.preventDefault(); host.classList.remove('dragover'); }));
  host.addEventListener('drop', e => {
    e.preventDefault();
    host.classList.remove('dragover');
    uploadFiles(e.dataTransfer.files);
  });

  async function uploadFiles(files) {
    if (!files || !files.length) return;
    for (const file of files) {
      if (!file.type.startsWith('image/')) {
        status.innerHTML = `<span style="color:var(--red);">❌ <code>${file.name}</code> is not an image</span>`;
        continue;
      }
      status.innerHTML = `<span style="color:var(--muted);">📤 Uploading <code>${file.name}</code> (${(file.size/1024).toFixed(1)} KB)…</span>`;
      try {
        const base64 = await fileToBase64(file);
        const res = await fetch('/api/upload', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ filename: file.name, base64, mimeType: file.type }),
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const result = await res.json();
        status.innerHTML = `<span style="color:var(--green);">✅ Saved as <code>${result.name}</code> — appears below + in all 🎨 Ref dropdowns</span>`;
      } catch (err) {
        status.innerHTML = `<span style="color:var(--red);">❌ Upload failed: ${err.message}</span>`;
      }
    }
    input.value = '';
  }
}

function fileToBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      const s = r.result;
      const c = s.indexOf(',');
      res(c >= 0 ? s.slice(c + 1) : s);
    };
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

// ── Fullscreen / zoom modal ───────────────────────────────────────────────────
const fsModal  = document.getElementById('fs-modal');
const fsTitle  = document.getElementById('fs-title');
const fsMeta   = document.getElementById('fs-meta');
const fsImgWrap= document.getElementById('fs-img-wrap');
const fsImg    = document.getElementById('fs-img');
const fsCanvas = document.getElementById('fs-canvas');
const fsZoom   = document.getElementById('fs-zoom');
const fsZlvl   = document.getElementById('fs-zlvl');
const fsAnimBar= document.getElementById('fs-anim-bar');

let fsState = null; // { kind, zoom, panX, panY, threeCtx? }

function openFsImage(name) {
  fsModal.classList.add('open');
  fsTitle.firstChild.nodeValue = name + ' ';
  fsMeta.textContent = '· image · scroll to zoom · drag to pan';
  fsImgWrap.style.display = 'flex';
  fsCanvas.style.display = 'none';
  fsZoom.style.display = 'flex';
  fsImg.src = `/assets/${name}?t=${Date.now()}`;
  fsImg.onload = () => {
    fsState = { kind: 'image', zoom: 1, panX: 0, panY: 0, naturalW: fsImg.naturalWidth, naturalH: fsImg.naturalHeight };
    fsFit();
    fsMeta.textContent = `· ${fsImg.naturalWidth}×${fsImg.naturalHeight}px · scroll to zoom · drag to pan`;
  };
  // Asset side-panel for images too — same redesign + history + drop UX
  populateFsAssetPanel(name, /\.(webp|png|jpg|jpeg)$/i.test(name) ? 'image' : 'image');
}

function fsApplyImageTransform() {
  if (!fsState || fsState.kind !== 'image') return;
  fsImg.style.transform = `translate(${fsState.panX}px, ${fsState.panY}px) scale(${fsState.zoom})`;
  fsZlvl.textContent = `${Math.round(fsState.zoom * 100)}%`;
}

function fsFit() {
  if (!fsState || fsState.kind !== 'image') return;
  const stage = fsImgWrap.getBoundingClientRect();
  const k = Math.min(stage.width / fsState.naturalW, stage.height / fsState.naturalH) * 0.95;
  fsState.zoom = k; fsState.panX = 0; fsState.panY = 0;
  fsApplyImageTransform();
}
function fsActual() {
  if (!fsState || fsState.kind !== 'image') return;
  fsState.zoom = 1; fsState.panX = 0; fsState.panY = 0;
  fsApplyImageTransform();
}

/**
 * Build the right-side asset panel inside the fullscreen modal. Surfaces:
 *   - Asset name + meta (size, kind)
 *   - Slot label + note + criticality + Game-uses toggle (if in a slot)
 *   - Iter-panel (Redesign this asset + model picker + Generate / Copy)
 *   - Last-gen line + history list (click row → open historical version)
 *   - Drag-and-drop zone (drop a file here to replace the on-disk asset)
 * Wired up to the same backend endpoints as the gallery cards — the studio's
 * card surface and the fullscreen surface stay in sync via SSE.
 */
function populateFsAssetPanel(name, assetType) {
  const panel = document.getElementById('fs-asset-panel');
  if (!panel) return;
  // Hide other panels (mutually exclusive — pose calibrator + bone-offset tuner share the right side)
  const posePanel = document.getElementById('fs-pose-panel');
  if (posePanel) { posePanel.style.display = 'none'; posePanel.innerHTML = ''; }
  panel.style.display = 'block';
  panel.innerHTML = '';

  // Find the slot (if any) that owns this asset
  const slot = (CONFIG.slots || []).find(s => (s.fills || []).includes(name));
  // Asset metadata can live in slots (as fillAsset) or in DATA.orphans —
  // there's no flat DATA.assets list. Look in both.
  let assetMeta = null;
  for (const s of (DATA.slots || [])) {
    if (s.fillAsset && s.fillAsset.name === name) { assetMeta = s.fillAsset; break; }
  }
  if (!assetMeta) assetMeta = (DATA.orphans || []).find(a => a.name === name);
  const sizeStr = assetMeta ? humanBytes(assetMeta.bytes || assetMeta.size) : '';

  const sec = document.createElement('div');
  // ── Header: name + size + slot decoration ─────────────────────────────
  let html =
    `<div class="fs-asset-name">${name}</div>` +
    `<div class="fs-asset-meta">` +
      `<span>${assetType === 'glb' ? '🎲 GLB' : assetType.toUpperCase()}</span>` +
      (sizeStr ? `<span>${sizeStr}</span>` : '') +
      (slot ? `<span style="color:${slot.criticality === 'blocker' ? '#ff7a7a' : slot.criticality === 'important' ? '#ffd97a' : '#888'};">${slot.criticality || ''}</span>` : '') +
    `</div>`;
  if (slot?.label && slot.label !== name) html += `<div class="fs-asset-meta" style="margin-top:4px;">${slot.label}</div>`;
  if (slot?.note)  html += `<div class="fs-asset-note">${slot.note}</div>`;

  // Iter-panel for regen
  const modelList = (assetType === 'glb' || assetType === 'pose-calibrator' || assetType === 'bone-offset-tuner') ? MODELS_3D : MODELS_IMG;
  const placeholderText = (assetType === 'glb')
    ? 'Ex: same character but warmer coat, red scarf, keep proportions.'
    : 'Ex: redesign with cleaner edges, brighter palette.';
  html += `<h4>🪄 Redesign this asset</h4>`;
  html += buildIterPanelHTML(modelList, placeholderText, { includeRef: assetType === 'glb' });

  // Drag-drop zone
  html += `<div class="fs-drop-zone" data-fs-drop>📥 Drop a ${assetType === 'glb' ? '.glb' : 'image'} file here to replace</div>`;

  // History list
  html += `<h4>📜 History</h4>`;
  html += `<div class="fs-asset-history"></div>`;

  panel.innerHTML = html;
  panel.appendChild(sec);

  // Wire iter-panel up — the helper expects a "card" element with `.iter-panel`,
  // and our panel does have one (just rendered into it). Same APIs work.
  attachIterPanel(panel, name, assetType);
  renderLastGen(panel, name);

  // Drag-drop replace handler
  const drop = panel.querySelector('[data-fs-drop]');
  if (drop) {
    const onDragOver = (e) => { e.preventDefault(); drop.classList.add('drag-over'); };
    const onDragLeave = () => drop.classList.remove('drag-over');
    const onDrop = async (e) => {
      e.preventDefault(); drop.classList.remove('drag-over');
      const file = e.dataTransfer?.files?.[0];
      if (!file) return;
      drop.textContent = `Uploading ${file.name}…`;
      try {
        const base64 = await fileToBase64(file);
        const r = await fetch(`/api/replace/${encodeURIComponent(name)}`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: name, base64, mimeType: file.type }),
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        drop.textContent = `✅ Replaced — ${file.name}`;
        setTimeout(() => { drop.textContent = `📥 Drop a file here to replace`; }, 2000);
      } catch (err) { drop.textContent = `❌ ${err.message}`; }
    };
    drop.addEventListener('dragover', onDragOver);
    drop.addEventListener('dragleave', onDragLeave);
    drop.addEventListener('drop', onDrop);
  }

  // Render history list
  renderFsHistory(panel, name);
}

function renderFsHistory(panel, name) {
  const list = panel.querySelector('.fs-asset-history');
  if (!list) return;
  const entries = HISTORY_BY_ASSET.get(name) || [];
  if (!entries.length) {
    list.innerHTML = '<div style="color:#666;font-size:10px;font-style:italic;padding:6px 0;">No generations yet.</div>';
    return;
  }
  list.innerHTML = entries.slice(0, 20).map(e => {
    const ts = e.completedAt ? new Date(e.completedAt) : null;
    const tsStr = ts ? `${ts.toLocaleDateString()} ${ts.toLocaleTimeString().slice(0,5)}` : '';
    const thumb = e.thumbnail || '';
    return `<div class="fs-asset-history-row" data-h-id="${e.id || ''}">${
      thumb ? `<img src="${thumb}" alt="">` : `<div style="width:48px;height:48px;background:#222;border-radius:3px;flex-shrink:0;display:flex;align-items:center;justify-content:center;color:#444;font-size:18px;">🎲</div>`
    }<div class="h-meta"><div class="h-prompt">${(e.prompt || '(no prompt)').slice(0, 80)}</div><div class="h-time">${tsStr} · ${e.model || ''}</div></div></div>`;
  }).join('');
}

function humanBytes(n) {
  if (!n && n !== 0) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n/1024).toFixed(0)} KB`;
  return `${(n/1024/1024).toFixed(1)} MB`;
}

function openFsGLB(name) {
  fsModal.classList.add('open');
  fsTitle.firstChild.nodeValue = name + ' ';
  fsMeta.textContent = '· 3D · scroll to zoom · drag to orbit · right-drag to pan';
  fsImgWrap.style.display = 'none';
  fsCanvas.style.display = 'block';
  fsZoom.style.display = 'none';
  // Build the asset side-panel (iter-panel + history + drag-drop + slot info)
  populateFsAssetPanel(name, 'glb');

  // Fresh Three.js scene with full controls
  const renderer = new THREE.WebGLRenderer({ canvas: fsCanvas, antialias: true });
  renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const scene  = new THREE.Scene(); scene.background = new THREE.Color(0x0d1520); makeLights(scene);
  scene.add(new THREE.GridHelper(10, 20, 0x1a2a3a, 0x1a2a3a));
  const camera = new THREE.PerspectiveCamera(45, fsCanvas.clientWidth/fsCanvas.clientHeight, 0.01, 200);
  camera.position.set(2, 2, 4);
  const controls = new OrbitControls(camera, fsCanvas);
  controls.enableDamping = true; controls.dampingFactor = 0.08;

  let stop = false;
  // Mirror the active animation from the source card (if any) so what you
  // see in the card is what you see in fullscreen. Falls back to first clip.
  const sourceCtx = glbRenderers.get(name);
  let fsMixer = null;
  fsState = { kind: 'glb', renderer, scene, camera, controls, stop: () => stop = true, get mixer() { return fsMixer; } };

  // Re-load GLB into our temp scene with our own mixer so we can play anims here
  (async () => {
    const loader = makeGLTFLoader();
    try {
      const gltf = await new Promise((res, rej) =>
        loader.load(`/assets/${name}?t=${Date.now()}`, res, null, rej)
      );
      // Center + scale (same logic as card)
      const box1 = new THREE.Box3().setFromObject(gltf.scene);
      const c = box1.getCenter(new THREE.Vector3());
      const sz = box1.getSize(new THREE.Vector3());
      const k = 2 / Math.max(sz.x, sz.y, sz.z);
      gltf.scene.scale.setScalar(k);
      gltf.scene.position.copy(c).negate().multiplyScalar(k);
      const box2 = new THREE.Box3().setFromObject(gltf.scene);
      gltf.scene.position.y -= box2.min.y;
      scene.add(gltf.scene);
      const box3 = new THREE.Box3().setFromObject(gltf.scene);
      const c3 = box3.getCenter(new THREE.Vector3());
      const s3 = box3.getSize(new THREE.Vector3());
      const dist = (Math.max(s3.x,s3.y,s3.z)/2 / Math.tan(camera.fov*Math.PI/360)) * 1.5;
      camera.position.set(c3.x+dist*.6, c3.y+s3.y*.3+dist*.4, c3.z+dist);
      controls.target.copy(c3); controls.update();

      if (gltf.animations && gltf.animations.length > 0) {
        fsMixer = new THREE.AnimationMixer(gltf.scene);
        const actions = gltf.animations.map(clip => fsMixer.clipAction(clip));
        const startIdx = sourceCtx?.activeAnim >= 0 ? sourceCtx.activeAnim : 0;
        actions[startIdx]?.play();
        fsMeta.textContent = `· 3D · ${gltf.animations.length} anim · scroll zoom · drag orbit`;

        // ── Build the fullscreen animation chip bar ──────────────────────────
        // One chip per clip + a "pause" chip. Clicking crossfades smoothly.
        // Mirrors the active selection back to the source card so closing the
        // modal and looking at the card shows the same clip you were watching.
        let activeIdx = startIdx;
        fsAnimBar.innerHTML =
          `<span class="anim-label">Animation</span>` +
          gltf.animations.map((c, i) => {
            const label = (c.name || `clip ${i}`).slice(0, 22);
            const title = `${c.name || `clip ${i}`} (${c.duration.toFixed(1)}s)`;
            return `<button class="anim-chip${i===startIdx?' active':''}" data-i="${i}" title="${title.replace(/"/g,'&quot;')}">${label}</button>`;
          }).join('') +
          `<button class="anim-chip pause" data-pause title="Pause all animations">⏸ pause</button>`;
        fsAnimBar.style.display = 'flex';

        // Click handler — crossfade between actions for smooth transitions
        fsAnimBar.onclick = (e) => {
          const btn = e.target.closest('.anim-chip');
          if (!btn) return;
          fsAnimBar.querySelectorAll('.anim-chip').forEach(c => c.classList.remove('active'));
          btn.classList.add('active');
          if (btn.dataset.pause !== undefined) {
            actions.forEach(a => a.fadeOut?.(0.2));
            setTimeout(() => actions.forEach(a => a.stop()), 220);
            activeIdx = -1;
            if (sourceCtx) sourceCtx.activeAnim = -1;
            return;
          }
          const idx = parseInt(btn.dataset.i, 10);
          if (idx === activeIdx) return;
          const next = actions[idx];
          if (!next) return;
          // Smooth 0.25s crossfade from currently-playing clip to the new one
          if (activeIdx >= 0 && actions[activeIdx]) {
            next.reset();
            next.setEffectiveWeight(1);
            next.play();
            actions[activeIdx].crossFadeTo(next, 0.25, false);
          } else {
            next.reset().play();
          }
          activeIdx = idx;
          // Mirror selection back to the source card so the chip there updates
          if (sourceCtx) {
            sourceCtx.activeAnim = idx;
            const cardBar = sourceCtx.container?.querySelector('.anim-bar');
            if (cardBar) {
              cardBar.querySelectorAll('.anim-chip').forEach(c => c.classList.remove('active'));
              cardBar.querySelector(`[data-i="${idx}"]`)?.classList.add('active');
              // Also crossFade the card's own mixer so what you see in the card
              // when you close fs matches what you were watching.
              const cardActions = sourceCtx.actions;
              if (cardActions && cardActions[idx]) {
                cardActions.forEach(a => a.stop());
                cardActions[idx].reset().play();
              }
            }
          }
        };

        // Keyboard shortcuts: ← / → switch clips, Space toggles pause
        fsState.onKey = (e) => {
          if (!fsAnimBar || fsAnimBar.style.display === 'none') return;
          const chips = Array.from(fsAnimBar.querySelectorAll('.anim-chip:not(.pause)'));
          if (!chips.length) return;
          if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
            e.preventDefault();
            const cur = chips.findIndex(c => c.classList.contains('active'));
            const dir = e.key === 'ArrowRight' ? 1 : -1;
            const nxt = (cur + dir + chips.length) % chips.length;
            chips[nxt].click();
          } else if (e.key === ' ' || e.code === 'Space') {
            e.preventDefault();
            const pauseBtn = fsAnimBar.querySelector('.anim-chip.pause');
            const wasPaused = pauseBtn?.classList.contains('active');
            if (wasPaused) chips[Math.max(0, activeIdx)]?.click();
            else pauseBtn?.click();
          }
        };
        window.addEventListener('keydown', fsState.onKey);
      } else {
        fsAnimBar.style.display = 'none';
      }
    } catch (err) { console.error('FS GLB load failed:', err); }
  })();

  function onResize() {
    if (stop) return;
    renderer.setSize(fsCanvas.clientWidth, fsCanvas.clientHeight, false);
    camera.aspect = fsCanvas.clientWidth / fsCanvas.clientHeight;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', onResize);
  fsState.cleanup = () => { window.removeEventListener('resize', onResize); renderer.dispose(); };
  setTimeout(onResize, 50);

  let lastT = performance.now();
  (function loop(now) {
    if (stop) return;
    requestAnimationFrame(loop);
    const dt = Math.min(((now||performance.now()) - lastT) / 1000, 0.1);
    lastT = now || performance.now();
    fsMixer?.update(dt);
    controls.update();
    renderer.render(scene, camera);
  })();
}

function closeFs() {
  if (fsState?.kind === 'glb' || fsState?.kind === 'pose' || fsState?.kind === 'bone-offset' || fsState?.kind === 'rig-tuner') {
    fsState.stop();
    fsState.cleanup?.();
    if (fsState.onKey) window.removeEventListener('keydown', fsState.onKey);
  }
  fsModal.classList.remove('open');
  fsImg.src = ''; fsImg.style.transform = '';
  // Clear the anim-bar so it doesn't flash old chips when reopening another GLB
  if (fsAnimBar) { fsAnimBar.innerHTML = ''; fsAnimBar.style.display = 'none'; fsAnimBar.onclick = null; }
  // Hide pose panel (its content is rebuilt fresh on every open)
  const posePanel = document.getElementById('fs-pose-panel');
  if (posePanel) { posePanel.style.display = 'none'; posePanel.innerHTML = ''; }
  // Same for the asset panel
  const assetPanel = document.getElementById('fs-asset-panel');
  if (assetPanel) { assetPanel.style.display = 'none'; assetPanel.innerHTML = ''; }
  fsState = null;
}

// Modal controls
document.getElementById('fs-close').addEventListener('click', closeFs);
document.getElementById('fs-fit').addEventListener('click', fsFit);
document.getElementById('fs-actual').addEventListener('click', fsActual);
document.getElementById('fs-zin').addEventListener('click', () => { if (fsState?.kind === 'image') { fsState.zoom = Math.min(fsState.zoom * 1.25, 30); fsApplyImageTransform(); } });
document.getElementById('fs-zout').addEventListener('click', () => { if (fsState?.kind === 'image') { fsState.zoom = Math.max(fsState.zoom / 1.25, 0.05); fsApplyImageTransform(); } });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && fsModal.classList.contains('open')) closeFs(); });

// Image zoom (wheel) + pan (drag)
fsImgWrap.addEventListener('wheel', e => {
  if (!fsState || fsState.kind !== 'image') return;
  e.preventDefault();
  const factor = e.deltaY < 0 ? 1.15 : 1 / 1.15;
  fsState.zoom = Math.max(0.05, Math.min(30, fsState.zoom * factor));
  fsApplyImageTransform();
}, { passive: false });

let fsDrag = null;
fsImgWrap.addEventListener('mousedown', e => {
  if (!fsState || fsState.kind !== 'image') return;
  fsDrag = { sx: e.clientX, sy: e.clientY, px: fsState.panX, py: fsState.panY };
  fsImgWrap.classList.add('dragging');
});
window.addEventListener('mousemove', e => {
  if (!fsDrag) return;
  fsState.panX = fsDrag.px + (e.clientX - fsDrag.sx);
  fsState.panY = fsDrag.py + (e.clientY - fsDrag.sy);
  fsApplyImageTransform();
});
window.addEventListener('mouseup', () => { fsDrag = null; fsImgWrap.classList.remove('dragging'); });

// ── Concept creator form ──────────────────────────────────────────────────────
function buildConceptCreator(host) {
  host.innerHTML = `
    <div class="cc-title">✨ Create new concept</div>
    <div class="cc-row">
      <input type="text" class="cc-name" placeholder="Concept name (e.g. zombie_warrior)">
      <textarea class="cc-prompt" placeholder="Ex: clean orthographic concept of a zombie warrior, T-pose front view, plain white background, no shadows, kawaii style consistent with mom and daughters."></textarea>
    </div>
    <div class="cc-row2">
      <select class="cc-model" title="Layer.ai model">
        ${buildModelOptions(MODELS_IMG)}
      </select>
      <button class="cc-create">⚙️ Generate concept</button>
    </div>
    <div class="cc-status"></div>
  `;
  const nameEl   = host.querySelector('.cc-name');
  const promptEl = host.querySelector('.cc-prompt');
  const modelEl  = host.querySelector('.cc-model');
  const btn      = host.querySelector('.cc-create');
  const statusEl = host.querySelector('.cc-status');

  // Default for concepts → "Auto · Best quality" (concepts are upstream of 3D
  // generation, so quality matters more than iteration speed here)
  modelEl.value = 'auto:quality';

  btn.addEventListener('click', async () => {
    let name = nameEl.value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g,'_').replace(/^_+|_+$/g,'');
    const prompt = promptEl.value.trim();
    if (!name)   { nameEl.focus();   statusEl.textContent = 'Pick a name first.'; return; }
    if (!prompt) { promptEl.focus(); statusEl.textContent = 'Write a prompt.';    return; }
    const fname = `concept_${name}.webp`;
    const model = modelEl.value;
    btn.disabled = true; btn.textContent = '⏳ Queuing…';
    try {
      const res  = await fetch('/api/queue', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ assetName: fname, prompt, type: 'concept', model }),
      });
      const item = await res.json();
      statusEl.innerHTML = `<span style="color:var(--purple);">⏳ Queued <code>${fname}</code> (#${item.id.slice(0,8)}) — tell Claude "check queue" in chat. Card will auto-appear when ready.</span>`;
      nameEl.value = ''; promptEl.value = '';
      btn.disabled = false; btn.textContent = '⚙️ Generate concept';
      updateQueuePanel();
    } catch {
      statusEl.innerHTML = '<span style="color:var(--red);">❌ Server not reachable</span>';
      btn.disabled = false; btn.textContent = '⚙️ Generate concept';
    }
  });
}

function setStatus(el, type, msg) {
  el.className = `gen-status ${type}`;
  el.textContent = msg;
}

// ── Audio Rows ────────────────────────────────────────────────────────────────
let currentAudio = null;
function makeAudioRow(parent, asset) {
  const row   = document.createElement('div'); row.className='audio-row';
  const btn   = document.createElement('button'); btn.className='play-btn'; btn.innerHTML='▶';
  const name  = document.createElement('div'); name.className='aname'; name.textContent=asset.name;
  const size  = document.createElement('div'); size.className='asize'; size.textContent=asset.size;
  const audio = document.createElement('audio');
  audio.src   = `/assets/${asset.name}`;
  audio.addEventListener('ended', ()=>{btn.innerHTML='▶';btn.classList.remove('playing');});
  btn.addEventListener('click', ()=>{
    if(currentAudio&&currentAudio!==audio){currentAudio.pause();currentAudio.currentTime=0;document.querySelectorAll('.play-btn.playing').forEach(b=>{b.innerHTML='▶';b.classList.remove('playing');});}
    if(audio.paused){audio.play();btn.innerHTML='⏸';btn.classList.add('playing');currentAudio=audio;}
    else{audio.pause();btn.innerHTML='▶';btn.classList.remove('playing');currentAudio=null;}
  });
  row.append(btn,name,size,audio); parent.appendChild(row);
}

// ── Queue sidebar ─────────────────────────────────────────────────────────────
async function updateQueuePanel() {
  try {
    const q      = await fetch('/api/queue').then(r => r.json());
    const list   = document.getElementById('queue-list');
    const badge  = document.getElementById('q-badge');
    const pending = q.filter(i => i.status === 'pending' || i.status === 'generating');
    badge.textContent = pending.length || '';
    badge.classList.toggle('show', pending.length > 0);

    if (q.length === 0) {
      list.innerHTML = '<div style="padding:16px;font-size:12px;color:var(--muted);">No requests yet.<br><br>Write a prompt in any asset card and click ⚙️ Generate.</div>';
      return;
    }
    list.innerHTML = q.slice().reverse().map(item => {
      const modelLine = item.model && item.model !== 'auto'
        ? `<div style="font-size:10px;color:var(--blue);margin-top:2px;">⚡ ${item.model}</div>`
        : (item.model === 'auto' ? `<div style="font-size:10px;color:var(--muted);margin-top:2px;">🤖 auto-pick</div>` : '');
      return `
      <div class="q-item" data-id="${item.id}">
        <div class="qi-name">${item.assetName}</div>
        <div class="qi-prompt">${item.prompt}</div>
        ${modelLine}
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:5px;">
          <span class="qi-status ${item.status}">${item.status.toUpperCase()}</span>
          <button onclick="deleteQueueItem('${item.id}')" style="background:none;border:none;color:var(--muted);cursor:pointer;font-size:13px;padding:2px 5px;">✕</button>
        </div>
        ${item.note ? `<div style="margin-top:4px;font-size:10px;color:var(--muted);">${item.note}</div>` : ''}
        <div class="qi-meta">${new Date(item.createdAt).toLocaleTimeString()}</div>
      </div>`;
    }).join('');
  } catch {}
}

window.deleteQueueItem = async id => {
  await fetch(`/api/queue/${id}`, { method: 'DELETE' });
  updateQueuePanel();
};

// Queue toggle button
document.getElementById('queue-toggle').addEventListener('click', () => {
  document.getElementById('queue-panel').classList.toggle('open');
  updateQueuePanel();
});

// ── SSE: live asset refresh + queue sync ──────────────────────────────────────
// Cards that need to react to file changes beyond the standard card-image
// refresh (e.g. the Rig Tuner re-reading tune.json to update its preview) can
// subscribe via `window.__sseBus.addEventListener('asset-updated', handler)`.
// We dispatch a CustomEvent whose .data is the raw JSON string (mirroring the
// MessageEvent shape SSE consumers already expect, so the handler code is
// uniform whether it listens to EventSource directly or this internal bus).
if (typeof window !== 'undefined' && !window.__sseBus) {
  window.__sseBus = new EventTarget();
}
function connectSSE() {
  const es = new EventSource('/api/events');
  es.addEventListener('connected', () => console.log('[SSE] connected'));
  es.addEventListener('asset-updated', e => {
    const { name } = JSON.parse(e.data);
    console.log('[SSE] asset-updated:', name);
    refreshAssetCard(name);
    if (window.__sseBus) {
      // Use CustomEvent's standard .detail property — assigning .data on the
      // event object directly is non-standard and was silently swallowed in
      // some browsers when the CustomEvent prototype's accessors interfered.
      window.__sseBus.dispatchEvent(new CustomEvent('asset-updated', { detail: { name } }));
    }
  });
  es.addEventListener('queue-updated',  () => updateQueuePanel());
  es.addEventListener('queue-deleted',  () => updateQueuePanel());
  es.addEventListener('queue-snapshot', () => updateQueuePanel());
  es.addEventListener('history-appended', e => {
    const entry = JSON.parse(e.data);
    if (!HISTORY_BY_ASSET.has(entry.assetName)) HISTORY_BY_ASSET.set(entry.assetName, []);
    HISTORY_BY_ASSET.get(entry.assetName).unshift(entry);  // newest first
    // Update the affected card's last-gen line + flash
    document.querySelectorAll(`[data-asset="${entry.assetName}"]`).forEach(card => {
      renderLastGen(card, entry.assetName);
      card.classList.add('flash-update');
      setTimeout(() => card.classList.remove('flash-update'), 700);
    });
  });
  es.onerror = () => { console.warn('[SSE] disconnected, reconnecting in 3s…'); setTimeout(connectSSE, 3000); };
}

function refreshAssetCard(name) {
  // GLB card refresh — only if the card's WebGL context is currently alive
  // (i.e., card is in viewport and init() has completed). When the card is
  // offscreen (post-dispose, scene/camera/controls = null), skip the reload —
  // the next time the card scrolls into view, init() will load the fresh
  // file from disk anyway because of the cache-busting `?t=Date.now()`.
  const r = glbRenderers.get(name);
  if (r) {
    if (r.scene && r.camera && r.controls) {
      loadGLBIntoScene(name, r.scene, r.camera, r.controls, r.container);
      r.container.classList.add('flash-update');
      setTimeout(() => r.container.classList.remove('flash-update'), 700);
    }
    // Even if disposed, mark the asset as "dirty" so when init() runs next
    // time it forces a fresh load (already does via cache-bust on URL).
    return;
  }
  // Existing image/concept card refresh
  const imgCard = document.querySelector(`.card-img[data-asset="${name}"]`);
  if (imgCard) {
    const img = imgCard.querySelector('img');
    if (img) img.src = `/assets/${name}?t=${Date.now()}`;
    imgCard.classList.add('flash-update');
    setTimeout(() => imgCard.classList.remove('flash-update'), 700);
    return;
  }
  // New concept_* or ref_* file (no card yet) → spawn one in the concept grid
  if (/^(concept|ref)_.*\.(webp|png|jpg|jpeg)$/i.test(name)) {
    const grid = document.getElementById('grid-concept');
    if (!grid) return;
    const kind = name.startsWith('ref_') ? 'ref' : 'concept';
    const card = makeImageCard(grid, { name, size: '— new —' }, kind);
    card.classList.add('flash-update');
    setTimeout(() => card.classList.remove('flash-update'), 700);
    fetchConceptList();
  }
}

// ── Built-in factory registries ───────────────────────────────────────────────
// These map config `factory` IDs to client-side functions that build a card.
// Adding a new built-in here is a 5-line change: implement the make<Foo>
// function elsewhere in this file, then register it below. Per-game custom
// factories will eventually arrive via an extensions script (Phase 2).

const BUILTIN_PROC_RIGS = {
  humanoid_walk_idle_carry_rifle: makeProcMomCard,
  // Environment + items — mirror the actual procedural builders in src/main.ts
  cabin:        makeProcCabin,
  bed:          makeProcBed,
  fireplace:    makeProcFireplace,
  tree:         makeProcTree,
  fence:        makeProcFence,
  wood_plank:   makeProcWoodPlank,
  medkit:       makeProcMedkit,
  rifle_barrel: makeProcRifleBarrel,
  rifle_stock:  makeProcRifleStock,
  rifle_scope:  makeProcRifleScope,
};

const BUILTIN_VFX_FACTORIES = ['chips', 'blood', 'sparkle', 'fire',
  'muzzle_flash', 'pow_burst', 'bullet_streak', 'damage_flash', 'shell_eject'];
// (the actual VFX functions live inside makeVFXCard's switch — referenced by id)

// ── Render dynamic sections from config ───────────────────────────────────────
function makeSectionEl(title, gridClass, gridId, note) {
  const sec = document.createElement('div'); sec.className = 'section';
  const t   = document.createElement('div'); t.className = 'section-title'; t.textContent = title;
  sec.appendChild(t);
  if (note) {
    const n = document.createElement('div'); n.className = 'note'; n.innerHTML = note;
    sec.appendChild(n);
  }
  const grid = document.createElement('div'); grid.className = gridClass; grid.id = gridId;
  sec.appendChild(grid);
  return { sec, grid };
}

const dynamicHost = document.getElementById('dynamic-sections');

// ── Slot data prep ────────────────────────────────────────────────────────────
const SLOT_CATEGORY_ORDER = ['characters', 'environment', 'items', 'ui', 'audio', 'vfx'];
const SLOT_CATEGORY_LABEL = {
  characters:  '🧑 Characters',
  environment: '🏚 Environment',
  items:       '🎯 Items',
  ui:          '🖼 UI',
  audio:       '🔊 Audio',
  vfx:         '✨ VFX',
};
const CRITICALITY_LABEL = { blocker:'🔥 BLOCKER', important:'⚡ IMPORTANT', optional:'✦ OPTIONAL' };

const slotsByCategory = {};
for (const s of (DATA.slots || [])) {
  if (!slotsByCategory[s.category]) slotsByCategory[s.category] = [];
  slotsByCategory[s.category].push(s);
}
const usingSlotsMode = (DATA.slots && DATA.slots.length > 0);

// Pre-compute health stats (used by Slots Overview header)
let totalSlots = 0, polishedCount = 0, placeholderCount = 0, emptyCount = 0;
for (const s of (DATA.slots || [])) {
  totalSlots++;
  if (s.status === 'polished')    polishedCount++;
  if (s.status === 'placeholder') placeholderCount++;
  if (s.status === 'empty')       emptyCount++;
}

// Index slot per asset filename so we can decorate gallery cards later
const slotByAsset = new Map();
for (const s of (DATA.slots || [])) {
  if (s.fillAsset?.name) slotByAsset.set(s.fillAsset.name, s);
}

// ── Slots Overview (compact chips) ────────────────────────────────────────────
function buildSlotsOverview() {
  if (!usingSlotsMode) return;
  const sec = document.createElement('div');
  sec.className = 'section';
  sec.innerHTML = `<div class="section-title">🎯 Game Slots</div>`;

  // Health summary bar
  const polPct = totalSlots ? (polishedCount   / totalSlots * 100).toFixed(1) : 0;
  const plaPct = totalSlots ? (placeholderCount/ totalSlots * 100).toFixed(1) : 0;
  const empPct = totalSlots ? (emptyCount      / totalSlots * 100).toFixed(1) : 0;
  const health = document.createElement('div');
  health.className = 'slot-health';
  health.innerHTML =
    `<div class="stat polished"><span class="num">${polishedCount}</span> 🟢 polished</div>` +
    `<div class="stat placeholder"><span class="num">${placeholderCount}</span> 🟡 placeholder</div>` +
    `<div class="stat empty"><span class="num">${emptyCount}</span> 🔴 empty</div>` +
    `<div class="stat total"><span class="num">${totalSlots}</span> total slots</div>` +
    `<div class="progress" title="Game readiness: ${polishedCount} polished, ${placeholderCount} placeholder, ${emptyCount} empty">` +
      `<span class="pol" style="width:${polPct}%;"></span>` +
      `<span class="pla" style="width:${plaPct}%;"></span>` +
      `<span class="emp" style="width:${empPct}%;"></span>` +
    `</div>`;
  sec.appendChild(health);

  const overview = document.createElement('div');
  overview.className = 'slots-overview';
  for (const catId of SLOT_CATEGORY_ORDER) {
    const cs = slotsByCategory[catId];
    if (!cs || !cs.length) continue;
    const row = document.createElement('div');
    row.className = 'slot-cat-row';
    const chips = cs.map(s => {
      const targetAsset = s.fillAsset?.name
                       || (s.using === 'proc' || s.using === 'fallback' || s.using === 'vfx'
                           ? `${s.using}:${s.fallback?.id || ''}`
                           : (s.fills && s.fills[0]) || s.id);
      const critBadge = s.criticality === 'blocker' ? '<span class="crit-badge blocker" title="blocker">!</span>' : '';
      const tip = `${s.label || s.id}${s.note ? ' — ' + s.note.replace(/"/g,'&quot;') : ''}`;
      return `<div class="slot-chip status-${s.status}" data-slot-id="${s.id}" data-target="${targetAsset}" title="${tip}">` +
               `<span class="dot"></span>${critBadge}` +
               `<span class="chip-name">${s.id}</span>` +
               `<span class="chip-asset">→ ${targetAsset}</span>` +
             `</div>`;
    }).join('');
    row.innerHTML = `<span class="slot-cat-label">${SLOT_CATEGORY_LABEL[catId] || catId}</span><div class="slot-cat-chips">${chips}</div>`;
    overview.appendChild(row);
  }
  sec.appendChild(overview);

  // Click on a chip → smooth-scroll to + flash the matching gallery card
  overview.addEventListener('click', e => {
    const chip = e.target.closest('.slot-chip');
    if (!chip) return;
    const target = chip.dataset.target || '';
    let card = null;
    if (target.startsWith('proc:')) {
      card = document.querySelector(`[data-asset="${target.slice(5)}"]`);
    } else if (target.startsWith('vfx:') || target.startsWith('fallback:')) {
      const id = target.split(':')[1];
      // VFX cards use the human label as data-asset; match the factory id via dataset.type=vfx
      card = Array.from(document.querySelectorAll('.card3d[data-type="vfx"]'))
                  .find(c => c.dataset.asset.toLowerCase().includes(id));
    } else {
      card = document.querySelector(`[data-asset="${target}"]`);
    }
    if (card) {
      card.scrollIntoView({ block: 'center', behavior: 'smooth' });
      card.classList.add('slot-target-highlight');
      setTimeout(() => card.classList.remove('slot-target-highlight'), 1700);
    } else {
      // No card to scroll to (empty slot with no on-disk asset). Highlight the
      // chip itself with a subtle pulse instead.
      chip.classList.add('slot-target-highlight');
      setTimeout(() => chip.classList.remove('slot-target-highlight'), 1500);
    }
  });

  dynamicHost.appendChild(sec);
}
buildSlotsOverview();

// ── Gallery render: full cards for every asset on disk, organized by slot category
//    (or by legacy `categories[]` config when slots aren't defined). Filled slots
//    flow into their category section; orphan assets fall into "📦 Other".
let totalGLB = 0;
function applySlotDecoration(card, slot) {
  if (!card || !slot) return;
  card.dataset.slotStatus = slot.status;
  card.dataset.slotId     = slot.id;
  const info = card.querySelector('.info');
  if (info && slot.label) {
    const sl = document.createElement('div');
    sl.className = 'slot-label';
    sl.textContent = slot.label;
    info.appendChild(sl);
  }
  if (info && slot.note) {
    const sn = document.createElement('div');
    sn.className = 'slot-note';
    sn.textContent = slot.note;
    info.appendChild(sn);
  }
  // Source indicator: shown on every slot that has ANY source (fill or
  // fallback). When BOTH exist, chips are interactive (click to swap).
  // When only one exists, it's a read-only status indicator.
  if (info && (slot.fillAsset || slot.fallback)) attachSourceIndicator(info, slot);
  // Version navigator: ◀/▶ + dropdown to swap the live asset for any other
  // same-kind file on disk OR any archived past version. Filled GLB/image
  // slots only — pose/rig-tuner cards have their own internal navigation,
  // and audio rows don't need the visual preview swap.
  if (slot.fillAsset && (slot.kind === 'glb' || slot.kind === 'image')) {
    attachVersionNavigator(card, slot);
  }
}

function attachSourceIndicator(info, slot) {
  const hasFb   = !!slot.fallback;
  const fbKind  = slot.fallback?.kind === 'vfx' ? 'vfx' : 'proc';
  const fbName  = slot.fallback?.id || '';
  const fbIcon  = fbKind === 'vfx' ? '✨' : '🎲';
  const fbLabel = fbKind === 'vfx' ? `${fbIcon} vfx:${fbName}` : `${fbIcon} proc:${fbName}`;
  const isAsset = slot.using === 'asset';
  // Build the full set of "asset variants" from slot.fills[] AND mark which
  // exist on disk. The active one is determined by slot.fillAsset.name (which
  // server's computeSlotStatus resolves from activeFill or fills[0]).
  const allFills    = slot.fills || [];
  const activeFill  = slot.fillAsset?.name || null;
  // We can only KNOW which variants exist on disk by checking what's in the
  // global DATA — but DATA.slots[].fillAsset only reports the resolved one.
  // Use listAssignableAssets to get every file matching this kind, then
  // intersect with fills[] to find existing variants.
  const sameKind   = listAssignableAssets(slot.kind || 'glb');
  const existing   = new Set(sameKind);
  const variants   = allFills.map(f => ({ name: f, exists: existing.has(f) }));
  const hasMultipleExistingVariants = variants.filter(v => v.exists).length >= 2;
  const interactive = hasMultipleExistingVariants || (activeFill && hasFb);

  const toggle = document.createElement('div');
  toggle.className = 'source-toggle';

  let html = `<span class="src-label">Game uses:</span>`;
  // Render each variant as its own chip. The active one is highlighted; others
  // are clickable (when there are multiple existing) and trigger activeFill swap.
  for (const v of variants) {
    if (!v.exists) continue; // missing variants don't render — they belong to the empty-state path
    const isActive = (v.name === activeFill && isAsset);
    const clickable = hasMultipleExistingVariants;
    html += `<button class="src-chip glb ${clickable ? '' : 'readonly'} ${isActive ? 'active' : ''}" ` +
            `data-src="asset" data-fill="${v.name}" ` +
            (clickable ? '' : 'disabled ') +
            `title="${clickable ? 'Click to make this variant the live asset' : 'On-disk asset'}">📦 ${v.name}</button>`;
  }
  if (hasFb) {
    // runtimeSupport='asset' means the game runtime (main.ts) has NO procedural
    // implementation for this slot — the proc fallback exists only as a STUDIO
    // PREVIEW. Disable the chip and explain in the tooltip, so the PM doesn't
    // expect the proc choice to affect the game.
    const runtimeSupport = slot.runtimeSupport || 'both'; // default: both (backward compat)
    const runtimeBlocksProc = runtimeSupport === 'asset' && (fbKind === 'proc' || fbKind === 'vfx');
    const cls = (activeFill && !runtimeBlocksProc) ? fbKind : `${fbKind} readonly`;
    const disabled = !activeFill || runtimeBlocksProc;
    const tip = runtimeBlocksProc
      ? `Game runtime has no procedural fallback for this slot — preview-only in studio. Pick a GLB variant for the game.`
      : (activeFill ? `Use the procedural ${fbKind} fallback` : `Procedural ${fbKind} fallback (only source)`);
    html += `<button class="src-chip ${cls} ${(!isAsset && !runtimeBlocksProc) ? 'active' : ''}" data-src="${fbKind}" ${disabled ? 'disabled' : ''} title="${tip.replace(/"/g, '&quot;')}">${fbLabel}</button>`;
  }
  toggle.innerHTML = html;
  info.appendChild(toggle);

  if (!interactive) return;
  toggle.addEventListener('click', async e => {
    const btn = e.target.closest('.src-chip');
    if (!btn || btn.classList.contains('active') || btn.disabled) return;
    const src = btn.dataset.src;
    const fill = btn.dataset.fill;
    toggle.querySelectorAll('.src-chip').forEach(c => c.disabled = true);
    try {
      let res;
      if (src === 'asset' && fill && fill !== activeFill) {
        // Pick a different variant from fills[] as the live one.
        res = await fetch(`/api/slot/${encodeURIComponent(slot.id)}/active`, {
          method:  'PUT',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ fill }),
        });
        if (res.ok) {
          // Also flip usedInGame back to 'asset' if it was on the fallback.
          if (!isAsset) {
            await fetch(`/api/slot/${encodeURIComponent(slot.id)}`, {
              method: 'PATCH', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ usedInGame: 'asset' }),
            });
          }
        }
      } else {
        // Swap usedInGame (asset ↔ proc/vfx fallback). No fill change.
        res = await fetch(`/api/slot/${encodeURIComponent(slot.id)}`, {
          method:  'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ usedInGame: src }),
        });
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      location.reload();
    } catch (err) {
      console.error('[slot] swap failed:', err);
      toggle.querySelectorAll('.src-chip').forEach(c => c.disabled = false);
    }
  });
}

if (usingSlotsMode) {
  const galleryByCat = {};
  for (const s of (DATA.slots || [])) {
    // ALL slots render in the gallery — polished as real cards, placeholder
    // via their fallback factory, empty as red ghost cards with a "Generate
    // to fill" CTA. The Slots Overview at top stays as the at-a-glance view.
    if (!galleryByCat[s.category]) galleryByCat[s.category] = [];
    galleryByCat[s.category].push({ slot: s });
  }
  for (const a of (DATA.orphans || [])) {
    if (!galleryByCat['_orphan']) galleryByCat['_orphan'] = [];
    galleryByCat['_orphan'].push({ asset: a, slot: null });
  }
  for (const catId of [...SLOT_CATEGORY_ORDER, '_orphan']) {
    const items = galleryByCat[catId];
    if (!items || !items.length) continue;
    const label = catId === '_orphan' ? '📦 Other / Orphan' : SLOT_CATEGORY_LABEL[catId];
    const isImage = catId === 'ui';
    const isAudio = catId === 'audio';
    const gridClass = isAudio ? 'audio-list' : isImage ? 'grid-img' : 'grid3d';
    const { sec, grid } = makeSectionEl(label, gridClass, `gallery-${catId}`);
    dynamicHost.appendChild(sec);

    for (const item of items) {
      // Orphan asset (no slot)
      if (!item.slot) {
        const a = item.asset;
        if (a.name.endsWith('.glb')) {
          const card = makeCard3D(grid, a.name, a.size, 'badge-glb', 'GLB', 'glb');
          makeGLBCard(card, a); totalGLB++;
        } else if (/\.(webp|png|jpg|jpeg)$/i.test(a.name)) {
          makeImageCard(grid, a, 'image');
        } else if (/\.(mp3|ogg)$/i.test(a.name)) {
          makeAudioRow(grid, a);
        }
        continue;
      }

      const slot = item.slot;

      // POSE CALIBRATOR: special slot that loads a rigged char + a prop and
      // exposes per-axis tuning sliders. No status semantics — always renders.
      if (slot.kind === 'pose-calibrator') {
        const card = makeCard3D(grid, slot.label || slot.id, 'pose calibrator', 'badge-glb', 'CAL', 'pose-calibrator');
        applySlotDecoration(card, slot);
        makePoseCalibratorCard(card, slot);
        continue;
      }
      if (slot.kind === 'bone-offset-tuner') {
        const card = makeCard3D(grid, slot.label || slot.id, 'bone offsets', 'badge-glb', 'BONE', 'bone-offset-tuner');
        applySlotDecoration(card, slot);
        makeBoneOffsetTunerCard(card, slot);
        continue;
      }
      if (slot.kind === 'rig-tuner') {
        const card = makeCard3D(grid, slot.label || slot.id, 'rig tuner', 'badge-glb', 'RIG', 'rig-tuner');
        applySlotDecoration(card, slot);
        makeRigTunerCard(card, slot);
        continue;
      }

      // POLISHED: real asset on disk → render the asset card
      if (slot.status === 'polished' && slot.fillAsset) {
        const a = slot.fillAsset;
        let card;
        if (a.name.endsWith('.glb')) {
          card = makeCard3D(grid, a.name, a.size, 'badge-glb', 'GLB', 'glb');
          makeGLBCard(card, a); totalGLB++;
        } else if (/\.(webp|png|jpg|jpeg)$/i.test(a.name)) {
          card = makeImageCard(grid, a, 'image');
        } else if (/\.(mp3|ogg)$/i.test(a.name)) {
          makeAudioRow(grid, a);
          continue; // audio row doesn't take decoration
        }
        applySlotDecoration(card, slot);
        continue;
      }

      // PLACEHOLDER: render the proc/vfx fallback factory in the gallery.
      // This puts the procedural mom rig inside Characters, vfx_chips inside VFX, etc.
      if (slot.status === 'placeholder' && slot.fallback) {
        const fb = slot.fallback;
        if ((fb.kind === 'proc' || fb.kind === 'fallback') && BUILTIN_PROC_RIGS[fb.id]) {
          const factory = BUILTIN_PROC_RIGS[fb.id];
          const card = makeCard3D(grid, slot.id, 'proc fallback', 'badge-proc', 'PROC', 'proc');
          applySlotDecoration(card, slot);
          factory(card);
        } else if ((fb.kind === 'vfx' || fb.kind === 'fallback') && BUILTIN_VFX_FACTORIES.includes(fb.id)) {
          const card = makeCard3D(grid, slot.label || slot.id, 'vfx fallback', 'badge-vfx', 'VFX', 'vfx');
          applySlotDecoration(card, slot);
          makeVFXCard(card, fb.id);
        } else {
          console.warn('[slot] unknown fallback for', slot.id, fb);
        }
        continue;
      }

      // EMPTY: render a red ghost card with iter-panel pre-filled with a
      // contextual prompt so the PM can click Generate immediately.
      if (slot.status === 'empty') {
        const fillName = (slot.fills && slot.fills[0]) || `${slot.id}.???`;
        const ghostIcon = slot.kind === 'glb'   ? '🎲'
                       : slot.kind === 'image' ? '🖼'
                       : slot.kind === 'audio' ? '🔊'
                       : '⊘';
        const card = document.createElement('div');
        card.className = 'card-empty';
        card.dataset.slotStatus = 'empty';
        card.dataset.slotId     = slot.id;
        card.dataset.asset      = fillName;
        const critBadge = slot.criticality
          ? `<div class="slot-crit ${slot.criticality}">${CRITICALITY_LABEL[slot.criticality] || slot.criticality}</div>`
          : '';
        const modelList = (slot.kind === 'glb') ? MODELS_3D : MODELS_IMG;
        const placeholderText = `Generate ${slot.label || fillName}. Style: cute kawaii cartoon mobile-game art, low-poly chibi, snowy winter palette consistent with mom and zombie.`;
        // Candidate list for the "pick existing" dropdown — files matching
        // this slot's kind that the PM might want to assign instead of
        // generating a fresh one. The server's POST /api/slot/:id/assign
        // copies the chosen file into the slot's canonical fillName.
        const candidates = listAssignableAssets(slot.kind);
        const assignBlock = candidates.length > 0
          ? `<div class="slot-assign" title="Copy an existing asset to fill this slot (instead of generating a new one)">` +
              `<select class="slot-assign-select">` +
                `<option value="">— or pick existing ${slot.kind || 'asset'} —</option>` +
                candidates.map(n => `<option value="${n}">${n}</option>`).join('') +
              `</select>` +
              `<button class="slot-assign-btn" disabled>Use</button>` +
            `</div>`
          : '';
        card.innerHTML =
          `<div class="slot-badge empty">EMPTY</div>` + critBadge +
          `<div class="ghost">` +
            `<div class="gx">${ghostIcon}</div>` +
            `<div class="gh">${slot.kind || 'asset'} slot</div>` +
            `<div class="gp">to fill: ${fillName}</div>` +
          `</div>` +
          `<div class="info">` +
            `<div class="cname">${fillName}</div>` +
            (slot.label ? `<div class="slot-label">${slot.label}</div>` : '') +
            (slot.note  ? `<div class="slot-note">${slot.note}</div>`   : '') +
          `</div>` +
          assignBlock +
          buildIterPanelHTML(modelList, placeholderText, { includeRef: slot.kind === 'glb' });
        grid.appendChild(card);
        attachIterPanel(card, fillName, slot.kind === 'glb' ? 'glb' : slot.kind);
        wireSlotAssign(card, slot);
        // Pre-fill the prompt so PMs see a sensible starting point
        const ta = card.querySelector('.iter-prompt');
        if (ta) ta.value = `Generate ${slot.label || fillName} for the Last Stand playable. ${slot.note || ''}`.trim();
        continue;
      }
    }
  }
} else {
  // Legacy categories[] mode (no slots defined in config)
  for (const cat of (DATA.sections || [])) {
    if (!cat.assets || !cat.assets.length) continue;
    const { sec, grid } = makeSectionEl(cat.label, 'grid3d', `grid-${cat.id}`);
    dynamicHost.appendChild(sec);
    for (const a of cat.assets) {
      makeGLBCard(makeCard3D(grid, a.name, a.size, 'badge-glb', 'GLB', 'glb'), a);
      totalGLB++;
    }
  }
}

// ── Procedural rigs section (only in legacy mode — slots mode embeds them
//    inline in their category) ─────────────────────────────────────────────
if (!usingSlotsMode) {
  for (const rig of (CONFIG.procRigs || [])) {
    const factory = BUILTIN_PROC_RIGS[rig.factory];
    if (!factory) { console.warn(`[config] unknown procRig factory "${rig.factory}" — skipping ${rig.id}`); continue; }
    const { sec, grid } = makeSectionEl(rig.label || '🎭 Procedural Rig', 'grid3d', `grid-proc-${rig.id}`, rig.note);
    dynamicHost.appendChild(sec);
    factory(makeCard3D(grid, rig.id, 'built-in', 'badge-proc', 'PROC', 'proc'));
  }
}

// ── VFX showcase (only in legacy mode — slots mode embeds VFX fallbacks
//    inline in their slot's category) ────────────────────────────────────
if (!usingSlotsMode) {
  const vfxEntries = (CONFIG.vfx || []).filter(v => BUILTIN_VFX_FACTORIES.includes(v.factory));
  if (vfxEntries.length) {
    const vfxSec  = document.getElementById('sec-vfx');
    const vfxGrid = document.getElementById('grid-vfx');
    vfxSec.style.display = '';
    for (const v of vfxEntries) {
      makeVFXCard(makeCard3D(vfxGrid, v.label, 'procedural', 'badge-vfx', 'VFX', 'vfx'), v.factory);
    }
  }
}

// 4. Refs & Concepts (always-on section — upload zone + AI creator + grid)
const conceptGrid = document.getElementById('grid-concept');
buildRefUploader(document.getElementById('ref-uploader'));
buildConceptCreator(document.getElementById('concept-creator'));
for (const a of (DATA.refs     || [])) makeImageCard(conceptGrid, a, 'ref');
for (const a of (DATA.concepts || [])) makeImageCard(conceptGrid, a, 'concept');

// 5. Legacy UI images + audio sections — only render when NOT in slots mode.
//    In slots mode, UI/audio assets already appear in the gallery sections
//    (UI category and Audio category) so the legacy generic sections at the
//    bottom of the page are hidden to avoid duplication.
const imgGrid = document.getElementById('grid-img');
const audList = document.getElementById('audio-list');
if (!usingSlotsMode) {
  for (const a of DATA.images) makeImageCard(imgGrid, a, 'image');
  for (const a of DATA.audios) makeAudioRow(audList, a);
} else {
  imgGrid?.parentElement?.style?.setProperty('display','none');
  audList?.parentElement?.style?.setProperty('display','none');
}

// Populate ref dropdowns now that all cards exist
fetchConceptList();

// Fetch history and decorate cards with their last-gen line
fetchHistory().then(refreshAllLastGenLines);

// ── Orphan banner: surface assets that exist on disk but aren't in any slot ──
if ((DATA.orphans || []).length > 0) {
  const banner = document.getElementById('orphan-banner');
  banner.classList.remove('hidden');
  const list = DATA.orphans.map(o => `<span class="ob-list">${o.name}</span>`).join(' ');
  banner.innerHTML =
    `<span class="ob-icon">🔔</span>` +
    `<div><strong>${DATA.orphans.length} unclaimed asset${DATA.orphans.length>1?'s':''}</strong> on disk — not referenced by any slot. ` +
    `Add ${DATA.orphans.length>1?'them':'it'} to <code>asset-studio.config.json</code> if ${DATA.orphans.length>1?'they belong':'it belongs'} in the game, or delete if leftover. ${list}</div>`;
}

// ── All-assets gallery: flat alphabetical list with status dots ──────────────
function buildAssetGallery() {
  const grid = document.getElementById('ag-grid');
  if (!grid) return;
  // Build a status map per filename from slots
  const statusByFile = new Map();
  for (const s of (DATA.slots || [])) {
    for (const f of (s.fills || [])) statusByFile.set(f, s.status);
  }
  // Collect every asset (slots fills + images + audios + refs + concepts + orphans + unclaimed)
  const all = new Map();  // name → {name, size, status}
  const add = (a, st) => { if (!all.has(a.name)) all.set(a.name, { ...a, status: st }); };
  for (const s of (DATA.slots || []))   if (s.fillAsset) add(s.fillAsset, s.status);
  for (const a of (DATA.images || []))  add(a, statusByFile.get(a.name) || 'unclaimed');
  for (const a of (DATA.audios || []))  add(a, statusByFile.get(a.name) || 'unclaimed');
  for (const a of (DATA.refs || []))    add(a, 'ref');
  for (const a of (DATA.concepts || [])) add(a, 'concept');
  for (const a of (DATA.orphans || [])) add(a, 'unclaimed');

  const sorted = Array.from(all.values()).sort((a,b) => a.name.localeCompare(b.name));
  grid.innerHTML = sorted.map(a =>
    `<div class="ag-tile">
       <div class="ag-name" title="${a.name}">${a.name}</div>
       <div class="ag-meta"><span class="ag-status ${a.status}"></span>${a.size} · ${a.status}</div>
     </div>`
  ).join('');
}
buildAssetGallery();

document.getElementById('gallery-toggle')?.addEventListener('click', e => {
  const btn = e.currentTarget;
  const gal = document.getElementById('all-assets-gallery');
  btn.classList.toggle('open');
  gal.classList.toggle('open');
});

// Meta line — slot health summary in slots mode, asset count otherwise
const refCount     = (DATA.refs || []).length;
const conceptCount = (DATA.concepts || []).length;
let metaText;
if (usingSlotsMode) {
  metaText =
    `🎯 ${totalSlots} slots · ` +
    `🟢 ${polishedCount} polished · ` +
    `🟡 ${placeholderCount} placeholder · ` +
    `🔴 ${emptyCount} empty` +
    (refCount     ? ` · ${refCount} ref`         : '') +
    (conceptCount ? ` · ${conceptCount} concept` : '');
} else {
  const vfxEntries = (CONFIG.vfx || []).filter(v => BUILTIN_VFX_FACTORIES.includes(v.factory));
  const parts = [
    totalGLB         ? `${totalGLB} GLB`              : null,
    CONFIG.procRigs?.length ? `${CONFIG.procRigs.length} proc rig` : null,
    vfxEntries.length       ? `${vfxEntries.length} VFX`            : null,
    refCount         ? `${refCount} ref`              : null,
    conceptCount     ? `${conceptCount} concept`      : null,
    DATA.images.length      ? `${DATA.images.length} UI`            : null,
    DATA.audios.length      ? `${DATA.audios.length} audio`         : null,
  ].filter(Boolean);
  metaText = `${parts.join(' · ')} — write a prompt in any card to iterate`;
}
document.getElementById('meta-line').textContent = metaText;

// ── Global search ───────────────────────────────────────────────────────────
// Filters every gallery card by free-text match against:
//   - the asset filename (data-asset attribute)
//   - the slot id (data-slot-id attribute)
//   - the visible card text (label, note, stats)
// Hides non-matching cards via display:none. Counter shows X / Y matches.
// Empty query restores everything.
(function setupGlobalSearch() {
  const inp   = document.getElementById('global-search');
  const count = document.getElementById('search-count');
  if (!inp) return;
  const matchSelectors = '.card3d, .card-img, .card-empty, .card-audio';
  const sectionSelector = '.section, [id^="gallery-"], #sec-refs-concepts';

  const apply = () => {
    const q = inp.value.toLowerCase().trim();
    const cards = document.querySelectorAll(matchSelectors);
    let shown = 0;
    // Build a focused haystack — only the asset's IDENTITY fields, not the
    // entire card's textContent (which leaks dropdown options like
    // "concept_mom_tpose.webp" appearing in every card's Ref picker).
    const textOf = (el, sel) => {
      const node = el.querySelector(sel);
      return node ? (node.textContent || '') : '';
    };
    for (const c of cards) {
      const haystack = [
        c.dataset.asset || '',
        c.dataset.slotId || '',
        textOf(c, '.cname'),
        textOf(c, '.slot-label'),
        textOf(c, '.slot-note'),
        textOf(c, '.badge'),
      ].join(' ').toLowerCase();
      const visible = !q || haystack.includes(q);
      c.style.display = visible ? '' : 'none';
      if (visible) shown++;
    }
    if (count) count.textContent = q ? `${shown} / ${cards.length}` : '';
    // Hide whole sections that have zero visible cards (de-clutter)
    for (const sec of document.querySelectorAll(sectionSelector)) {
      const visibleInside = sec.querySelectorAll(`${matchSelectors}`);
      let any = false;
      for (const c of visibleInside) {
        if (c.style.display !== 'none') { any = true; break; }
      }
      sec.style.display = (q && !any) ? 'none' : '';
    }
  };

  let debounce = null;
  inp.addEventListener('input', () => {
    if (debounce) clearTimeout(debounce);
    debounce = setTimeout(apply, 80);
  });
  // Esc clears the search
  inp.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { inp.value = ''; apply(); inp.blur(); }
  });
  // Ctrl+K / Cmd+K focuses the search bar (universal modern shortcut)
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
      e.preventDefault(); inp.focus(); inp.select();
    }
  });
  // Re-apply after SSE refresh / initial render — slots may have been added
  inp.addEventListener('focus', apply);
})();

// Start SSE and initial queue load
connectSSE();
updateQueuePanel();

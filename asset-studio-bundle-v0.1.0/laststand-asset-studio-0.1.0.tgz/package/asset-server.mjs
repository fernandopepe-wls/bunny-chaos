#!/usr/bin/env node
/**
 * asset-server.mjs — Last Stand Asset Iteration Server
 *
 * Serves the asset viewer at http://localhost:3010
 * with live asset loading (no base64), generation queue, and SSE updates.
 *
 * Usage: node tools/asset-server.mjs
 *
 * Endpoints:
 *   GET  /                    → viewer HTML
 *   GET  /assets/:name        → serve file from assets/
 *   GET  /api/queue           → list pending/done requests
 *   POST /api/queue           → add generation request  {assetName, prompt, type}
 *   PATCH /api/queue/:id      → update request status   {status, note?}
 *   DELETE /api/queue/:id     → remove request
 *   GET  /api/events          → SSE stream (card refreshes, queue updates)
 *   GET  /api/client.js       → serve asset-viewer-live.js
 */

import http     from 'node:http';
import fs       from 'node:fs';
import path     from 'node:path';
import crypto   from 'node:crypto';
import { exec } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const __dir    = path.dirname(fileURLToPath(import.meta.url));

// Resolve the three.js package root regardless of where npm installs it
// (inside this package, hoisted to the consumer's node_modules, pnpm symlinks).
// Used by the /vendor/three/* route to serve Three.js + addons locally.
const _require = createRequire(import.meta.url);
let THREE_ROOT = '';
try {
  // Modern three blocks `three/package.json` via "exports". Resolve a
  // guaranteed subpath (the main module) and walk up until we hit the package
  // root — the dir containing package.json.
  let dir = path.dirname(_require.resolve('three'));
  while (dir !== path.dirname(dir)) {
    if (fs.existsSync(path.join(dir, 'package.json'))) { THREE_ROOT = dir; break; }
    dir = path.dirname(dir);
  }
} catch {
  console.warn('[boot] could not resolve `three` — /vendor/three/* will 404. Run `npm install three` in this project to enable the studio UI.');
}

// ── CLI flags + project resolution (template-friendly) ───────────────────────
function arg(name, fallback) {
  // Support both --name value and --name=value.
  const eq = process.argv.find((a) => a.startsWith(`--${name}=`));
  if (eq) return eq.slice(name.length + 3);
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : fallback;
}
// Default project root = cwd (where `npm run asset-studio` was launched), so a
// consumer just adds the script and runs it without extra flags. Fall back to
// the legacy "one level above the script" only if cwd isn't reasonable.
const PROJECT_ROOT = path.resolve(arg('project', process.cwd()));
const CONFIG_PATH  = path.resolve(arg('config',  path.join(PROJECT_ROOT, 'asset-studio.config.json')));
// Initial config peek so ASSETS can honor config-supplied `assetsDir`. CLI
// `--assets=…` still wins over the config value.
function peekConfigField(name) {
  if (!fs.existsSync(CONFIG_PATH)) return undefined;
  try {
    const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    return cfg[name];
  } catch { return undefined; }
}
const ASSETS = path.resolve(
  arg('assets', peekConfigField('assetsDir')
    ? path.resolve(path.dirname(CONFIG_PATH), peekConfigField('assetsDir'))
    : path.join(PROJECT_ROOT, 'assets')),
);
// Per-project studio state lives at <project>/.asset-studio/ so it doesn't
// pollute the package dir when this studio is consumed by multiple games.
const STATE_DIR = path.join(PROJECT_ROOT, '.asset-studio');
if (!fs.existsSync(STATE_DIR)) fs.mkdirSync(STATE_DIR, { recursive: true });
const QUEUE_F   = path.join(STATE_DIR, 'queue.json');
const PORT      = parseInt(arg('port', '3010'), 10);

// One-time migration: relocate legacy state files that used to live next to
// asset-server.mjs (inside the studio dir). Pre-PR-2 worktrees may still have
// `.queue.json` / `.history.json` co-located with the script.
for (const [oldName, newPath] of [
  ['.queue.json',   QUEUE_F],
  ['.history.json', path.join(STATE_DIR, 'history.json')],
]) {
  const oldPath = path.join(__dir, oldName);
  if (fs.existsSync(oldPath) && !fs.existsSync(newPath)) {
    try { fs.renameSync(oldPath, newPath); console.log(`[migrate] ${oldName} → ${path.relative(PROJECT_ROOT, newPath)}`); }
    catch (e) { console.warn(`[migrate] ${oldName} move failed:`, e.message); }
  }
}

// ── Config loader (graceful defaults if file missing) ─────────────────────────
function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    console.warn(`[config] no ${path.relative(PROJECT_ROOT, CONFIG_PATH)} — using defaults`);
    return { title: path.basename(PROJECT_ROOT), subtitle: 'Asset Studio', categories: [], procRigs: [], vfx: [], slots: [], assetsDir: null, lintTargets: ['src/main.ts'] };
  }
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    const cfg = JSON.parse(raw);
    return {
      title:      cfg.title    || path.basename(PROJECT_ROOT),
      subtitle:   cfg.subtitle || 'Asset Studio',
      slots:       Array.isArray(cfg.slots)        ? cfg.slots        : [],
      categories:  Array.isArray(cfg.categories)   ? cfg.categories   : [],
      procRigs:    Array.isArray(cfg.procRigs)     ? cfg.procRigs     : [],
      vfx:         Array.isArray(cfg.vfx)          ? cfg.vfx          : [],
      // assetsDir: read at boot for ASSETS resolution; kept here for tooling.
      assetsDir:   typeof cfg.assetsDir === 'string' ? cfg.assetsDir : null,
      // lintTargets: files the drift-lint scans for asset-name string literals.
      // Falls back to legacy src/main.ts so existing configs keep working.
      lintTargets: Array.isArray(cfg.lintTargets) && cfg.lintTargets.length
        ? cfg.lintTargets
        : ['src/main.ts'],
    };
  } catch (e) {
    console.error(`[config] failed to parse ${CONFIG_PATH}:`, e.message);
    return { title: path.basename(PROJECT_ROOT), subtitle: 'Asset Studio', categories: [], procRigs: [], vfx: [], slots: [], assetsDir: null, lintTargets: ['src/main.ts'] };
  }
}
// ── Drift lint: compare slot config vs main.ts hardcoded loadGLB literals ───
// The game (src/main.ts) currently uses string-literal asset names in its
// loadGLB*() calls. Until the runtime is migrated to read from a slot manifest,
// the studio's view of "what's live" can drift from what the game actually
// loads. This lint scans main.ts at startup and prints a warning per slot whose
// resolved live filename doesn't appear in any loadGLB call. Catches:
//   - fills[] ordering bugs (like the mom_chibi.glb / mom_stylized_rigged.glb case)
//   - activeFill pointing at a variant the game can't load yet
//   - GLBs added to assets/ + slot but never wired into the game
function lintSlotDrift(cfg) {
  // Drift-lint scans one or more game-source files for asset-name string
  // literals. Targets come from the config's `lintTargets` array (resolved
  // relative to PROJECT_ROOT). A missing file is silently skipped so consumers
  // can list multiple candidate paths without all needing to exist.
  const targets = (cfg.lintTargets || ['src/main.ts'])
    .map((p) => path.resolve(PROJECT_ROOT, p))
    .filter((p) => fs.existsSync(p));
  if (targets.length === 0) return;
  // Extract referenced asset filenames. Matches two patterns:
  //   1. load{GLB*,Audio,Texture}("name.ext")  — playable convention
  //   2. any quoted string ending in a known asset extension — catches the
  //      Capacitor flavor where assets are URL constants like
  //      `const MOM_GLB_URL = '/assets/mom.glb'`. We take the basename so
  //      `/assets/foo.glb` matches the slot's `foo.glb` fill.
  const loadCallRe = /load(?:GLB[A-Za-z]*|Audio|Texture)\(\s*["']([^"']+)["']/g;
  const assetLiteralRe = /["']([^"']*?([A-Za-z0-9_.-]+\.(?:glb|gltf|webp|png|jpg|jpeg|mp3|ogg|wav)))["']/gi;
  const referenced = new Set();
  for (const fp of targets) {
    const src = fs.readFileSync(fp, 'utf8');
    let m;
    while ((m = loadCallRe.exec(src)) !== null) referenced.add(m[1]);
    while ((m = assetLiteralRe.exec(src)) !== null) referenced.add(m[2]); // basename group
  }
  // Build current asset set so we can compute the live filename per slot.
  const assetSet = new Set(
    fs.existsSync(ASSETS)
      ? fs.readdirSync(ASSETS).filter(f => /\.(glb|webp|png|jpg|mp3|ogg)$/i.test(f))
      : []
  );
  for (const slot of (cfg.slots || [])) {
    if (slot.kind !== 'glb' && slot.kind !== 'image' && slot.kind !== 'audio') continue;
    const { fillName } = computeSlotStatus(slot, assetSet);
    if (!fillName) continue; // empty / placeholder slots don't drift
    if (!referenced.has(fillName)) {
      // Only warn if SOME fill[] entry IS referenced — that means the game is
      // loading a different variant than the studio thinks is live.
      const referencedVariant = (slot.fills || []).find(f => referenced.has(f));
      if (referencedVariant) {
        console.warn(`[lint] slot "${slot.id}" resolves to ${fillName} but game source loads ${referencedVariant} — studio and game disagree. Fix: set slot.activeFill="${referencedVariant}" or reorder fills[] to put it first.`);
      } else {
        console.warn(`[lint] slot "${slot.id}" resolves to ${fillName} but no lintTarget references any of its fills[] — game won't load this slot's asset.`);
      }
    }
  }
}

// CONFIG is re-read from disk every time `getConfig()` is called when the
// file mtime has changed. Previously a single startup load meant edits to
// asset-studio.config.json (e.g. fills[] reorder, activeFill swap) silently
// went stale until the PM restarted Node — and didn't, leading to "I changed
// the config but the studio still shows the old asset" reports. The mtime
// check is a single fs.statSync per call, so cost is negligible.
let _configCache = loadConfig();
let _configMtime = fs.existsSync(CONFIG_PATH) ? fs.statSync(CONFIG_PATH).mtimeMs : 0;
function getConfig() {
  if (!fs.existsSync(CONFIG_PATH)) return _configCache;
  const mtime = fs.statSync(CONFIG_PATH).mtimeMs;
  if (mtime !== _configMtime) {
    console.log(`[config] reloading ${path.relative(PROJECT_ROOT, CONFIG_PATH)} (mtime changed)`);
    _configCache = loadConfig();
    _configMtime = mtime;
  }
  return _configCache;
}
// Backwards-compat shim: read-only proxy so existing CONFIG.x references work.
// Setters route through getConfig() so any direct mutation lands on the fresh copy.
const CONFIG = new Proxy({}, {
  get(_, key) { return getConfig()[key]; },
  set(_, key, value) { _configCache[key] = value; return true; },
  ownKeys() { return Reflect.ownKeys(getConfig()); },
  getOwnPropertyDescriptor(_, key) { return Object.getOwnPropertyDescriptor(getConfig(), key); },
});

// ── Slot status computation ───────────────────────────────────────────────────
// Status is DERIVED, not stored. Re-runs every page render so the studio always
// reflects current disk state. Sources of truth:
//   1. The slot's `fills` array (filenames the asset COULD be)
//   2. Whether those filenames currently exist in `assets/`
//   3. The slot's `usedInGame` field — declares which fill the GAME actually uses
//      ('asset' = use fills[0], 'proc' / 'vfx' = use fallback). Defaults to 'asset'.
function computeSlotStatus(slot, assetSet) {
  // Resolution priority:
  //   1. slot.activeFill (PM's explicit pick via studio) — wins if file exists.
  //      Lets the PM choose any variant from fills[] as the "live" one without
  //      reordering the array.
  //   2. fills[].find existing — first existing entry by config order.
  // This split means fills[] is the SET of acceptable variants, and activeFill
  // is the SELECTED one. Without activeFill, behaviour is unchanged (first wins).
  let fillName = null;
  if (slot.activeFill && assetSet.has(slot.activeFill) && (slot.fills || []).includes(slot.activeFill)) {
    fillName = slot.activeFill;
  } else {
    fillName = (slot.fills || []).find(f => assetSet.has(f)) || null;
  }
  const used = slot.usedInGame || (fillName ? 'asset' : (slot.fallback ? 'fallback' : 'none'));

  if (used === 'asset' && fillName)        return { status: 'polished',    using: 'asset',  fillName };
  if (used === 'asset' && !fillName)       return { status: 'empty',       using: 'asset',  fillName: null };
  if ((used === 'proc' || used === 'vfx' || used === 'fallback') && slot.fallback)
                                            return { status: 'placeholder', using: used,    fillName: fillName || null };
  return { status: 'empty', using: 'none', fillName: null };
}

// ── Queue persistence ─────────────────────────────────────────────────────────
function readQueue()       { try { return JSON.parse(fs.readFileSync(QUEUE_F,'utf8')); } catch { return []; } }
function writeQueue(q)     { fs.writeFileSync(QUEUE_F, JSON.stringify(q, null, 2)); }

// ── History persistence (append-only log of completed generations) ────────────
const HISTORY_F = path.join(STATE_DIR, 'history.json');
function readHistory()        { try { return JSON.parse(fs.readFileSync(HISTORY_F,'utf8')); } catch { return []; } }
function writeHistory(h)      { fs.writeFileSync(HISTORY_F, JSON.stringify(h, null, 2)); }
function appendHistory(entry) {
  const h = readHistory();
  h.push(entry);
  writeHistory(h);
  return entry;
}

// ── SSE clients ───────────────────────────────────────────────────────────────
const sseClients = new Set();

function sseWrite(event, data) {
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) {
    try { res.write(msg); } catch { sseClients.delete(res); }
  }
}

// ── File watcher: notify viewer when an asset file changes ────────────────────
const watchers = new Map();
// Debounce per-file SSE emits — fs.watch on Windows fires duplicate events
// (rename + change for the same write) and even spurious events for unrelated
// files when the directory is touched. 250ms window collapses noisy bursts.
const lastEmit = new Map();
function emitAssetUpdated(name) {
  const now = Date.now();
  const prev = lastEmit.get(name) || 0;
  if (now - prev < 250) return;  // suppress duplicate within window
  lastEmit.set(name, now);
  console.log(`[watch] ${name} changed → notifying clients`);
  sseWrite('asset-updated', { name, ts: now });
}

function watchAsset(name) {
  // Skip dot-prefixed entries (e.g. `.history/` archive directory). These are
  // internal storage and should not fire asset-updated events to the studio.
  if (name.startsWith('.')) return;
  const fp = path.join(ASSETS, name);
  if (watchers.has(name) || !fs.existsSync(fp)) return;
  const w = fs.watch(fp, () => emitAssetUpdated(name));
  watchers.set(name, w);
}

// ── Versioned archive ────────────────────────────────────────────────────────
// Each time an asset is about to be overwritten on disk, we copy the existing
// file to assets/.history/<assetName>/<ISO-timestamp><ext> so the PM can switch
// back to any prior version via the history drawer. Layout:
//   assets/<name>.glb                    (live; the one the build inlines)
//   assets/.history/<name>.glb/2026-05-10T14-30-00Z.glb  (prior versions)
// The .history folder is excluded from readdirSync filters (only .glb/.webp/etc
// extensions match) and from watchAsset (dot-prefix check above), so it stays
// invisible to the studio UI except via the explicit /api/archive endpoints.
const ARCHIVE_DIR = path.join(ASSETS, '.history');
function archiveExisting(name) {
  const livePath = path.join(ASSETS, name);
  if (!fs.existsSync(livePath)) return null; // nothing to archive
  const ext = path.extname(name);
  const ts  = new Date().toISOString().replace(/[:.]/g, '-');
  const dir = path.join(ARCHIVE_DIR, name);
  fs.mkdirSync(dir, { recursive: true });
  const archivePath = path.join(dir, `${ts}${ext}`);
  fs.copyFileSync(livePath, archivePath);
  return path.relative(ASSETS, archivePath).replace(/\\/g, '/');
}
function listArchive(name) {
  const dir = path.join(ARCHIVE_DIR, name);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true })
    .filter(e => e.isFile())
    .map(e => {
      const fp = path.join(dir, e.name);
      const stat = fs.statSync(fp);
      const stamp = e.name.replace(/\.[^.]+$/, '').replace(/-/g, c => (c === '-' ? ':' : c));
      // Note: we replace dashes in the file basename back to colons for the
      // timestamp; this is best-effort (the ISO uses dashes in the date too).
      return { file: e.name, size: stat.size, mtime: stat.mtime.toISOString() };
    })
    .sort((a, b) => b.mtime.localeCompare(a.mtime));
}

// Watch all existing assets + the directory for new files. A brand-new
// consumer may not have created the assets dir yet — create it on the fly so
// the studio boots cleanly into an empty state.
if (!fs.existsSync(ASSETS)) {
  console.log(`[boot] creating empty assets dir at ${path.relative(PROJECT_ROOT, ASSETS)}`);
  fs.mkdirSync(ASSETS, { recursive: true });
}
for (const f of fs.readdirSync(ASSETS)) watchAsset(f);

fs.watch(ASSETS, (event, filename) => {
  if (filename) {
    watchAsset(filename);
    emitAssetUpdated(filename);
  }
});

// ── MIME types ────────────────────────────────────────────────────────────────
const MIMES = {
  '.glb': 'model/gltf-binary', '.webp': 'image/webp', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
  '.js':  'application/javascript', '.json': 'application/json',
  '.html':'text/html; charset=utf-8', '.css': 'text/css',
};

// ── HTML template ─────────────────────────────────────────────────────────────
function buildHTML() {
  const assets = fs.readdirSync(ASSETS).filter(f => /\.(glb|webp|png|jpg|mp3|ogg)$/i.test(f));
  const fmt = n => n < 1024 ? `${n} B` : n < 1048576 ? `${(n/1024).toFixed(1)} KB` : `${(n/1048576).toFixed(2)} MB`;

  const MIME_MAP = {
    '.glb': 'model/gltf-binary', '.webp':'image/webp', '.png':'image/png',
    '.jpg':'image/jpeg', '.mp3':'audio/mpeg', '.ogg':'audio/ogg',
  };

  const categorize = names => names.map(f => {
    const stat = fs.statSync(path.join(ASSETS, f));
    return { name: f, size: fmt(stat.size), bytes: stat.size, mime: MIME_MAP[path.extname(f).toLowerCase()] };
  });

  const assetSet = new Set(assets);
  const claimedBySlots = new Set();

  // ── Resolve slots (new primary categorization model) ─────────────────────
  const slots = (CONFIG.slots || []).map(slot => {
    const { status, using, fillName } = computeSlotStatus(slot, assetSet);
    if (fillName) claimedBySlots.add(fillName);
    const stat   = fillName ? fs.statSync(path.join(ASSETS, fillName)) : null;
    const fillAsset = fillName ? {
      name: fillName, size: fmt(stat.size), bytes: stat.size,
      mime: MIME_MAP[path.extname(fillName).toLowerCase()],
    } : null;
    return { ...slot, status, using, fillAsset };
  });

  // ── Backwards compat: legacy categories[] when no slots[] declared ───────
  const claimedByCategories = new Set();
  const sections = (CONFIG.categories || []).map(cat => {
    const matched = (cat.items || []).filter(n => assetSet.has(n));
    matched.forEach(n => claimedByCategories.add(n));
    return { id: cat.id, label: cat.label, type: cat.type || 'glb', assets: categorize(matched) };
  });
  // Implicit catch-all GLBs (only when using legacy categories mode)
  if (slots.length === 0) {
    const orphanGLBs = assets.filter(f => /\.glb$/i.test(f) && !claimedByCategories.has(f));
    if (orphanGLBs.length) {
      sections.push({ id: 'other_glb', label: '📦 Other GLB', type: 'glb', assets: categorize(orphanGLBs) });
    }
  }

  // ── Orphan detection: assets on disk not claimed by any slot's fills.
  //     Refs/concepts/audios excluded (they have their own sections).
  //     Only fires when slots are defined.
  const orphanAssets = slots.length === 0 ? [] :
    assets.filter(f => !claimedBySlots.has(f) && !/^(concept|ref)_/.test(f));

  const refs       = categorize(assets.filter(f => /^ref_.*\.(webp|png|jpg|jpeg)$/i.test(f)));
  const concepts   = categorize(assets.filter(f => /^concept_.*\.(webp|png|jpg|jpeg)$/i.test(f)));
  const images     = categorize(assets.filter(f => /\.(webp|png|jpg|jpeg)$/i.test(f) && !/^(concept|ref)_/i.test(f)));
  const audios     = categorize(assets.filter(f => /\.(mp3|ogg)$/i.test(f)));
  const orphans    = categorize(orphanAssets);

  // allAssets: every file on disk matching a supported extension. The client
  // needs this to determine which variants in a slot's `fills[]` actually exist
  // (the per-slot fillAsset is only the RESOLVED variant — variants claimed by
  // fills[] but not chosen as live are otherwise invisible to the client). Used
  // by `listAssignableAssets()` and the variant-picker chip render.
  const allAssets = assets.map(name => ({ name, kind:
    /\.glb$/i.test(name) ? 'glb' :
    /\.(webp|png|jpg|jpeg)$/i.test(name) ? 'image' :
    /\.(mp3|ogg|wav)$/i.test(name) ? 'audio' : 'other',
  }));

  const initData = JSON.stringify({
    config: { title: CONFIG.title, subtitle: CONFIG.subtitle, procRigs: CONFIG.procRigs, vfx: CONFIG.vfx },
    slots, sections, orphans, refs, concepts, images, audios, allAssets, mode: 'live'
  });

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${CONFIG.title} — ${CONFIG.subtitle}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --bg:#080d18;--surface:#111827;--surface2:#1a2436;
  --border:rgba(255,255,255,0.08);--accent:#ffd97a;
  --text:#e8ecf4;--muted:#8899aa;
  --green:#4ade80;--red:#f87171;--blue:#60a5fa;--purple:#c084fc;
}
html,body{background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,sans-serif;min-height:100%;}
body{padding:24px 20px 80px;}

header{max-width:1300px;margin:0 auto 24px;border-bottom:1px solid var(--border);padding-bottom:14px;
  display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;}
header h1{font-size:20px;font-weight:700;color:var(--accent);}header h1 span{color:var(--text);}
.hbadge{font-size:11px;padding:3px 9px;border-radius:20px;font-weight:700;letter-spacing:1px;}
.live-badge{background:rgba(74,222,128,.15);color:var(--green);border:1px solid rgba(74,222,128,.3);}
.meta{font-size:12px;color:var(--muted);margin-top:3px;}

.section{max-width:1300px;margin:0 auto 36px;}
.section-title{font-size:12px;font-weight:700;letter-spacing:2px;text-transform:uppercase;
  color:var(--muted);margin-bottom:12px;display:flex;align-items:center;gap:8px;}
.section-title::after{content:"";flex:1;height:1px;background:var(--border);}

/* ── 3D Cards ── */
.grid3d{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;}
/* pose calibrator card uses standard size — controls live in the fullscreen modal */
.card3d.pose-calibrator .gl-placeholder{height:200px;}

/* Pose Calibrator overlay panel inside fs-modal */
#fs-pose-panel{position:absolute;top:60px;right:18px;width:300px;max-height:calc(100vh - 200px);overflow-y:auto;
  background:rgba(0,0,0,0.78);border:1px solid rgba(168,85,247,0.4);border-radius:10px;
  padding:12px 14px;color:#fff;font:11px/1.4 system-ui,sans-serif;
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  z-index:5;box-shadow:0 4px 20px rgba(0,0,0,0.5);}
#fs-pose-panel h4{margin:8px 0 4px 0;font-size:10px;color:#a78bfa;font-weight:700;letter-spacing:1px;text-transform:uppercase;}
#fs-pose-panel h4:first-child{margin-top:0;}
.fs-pose-row{display:flex;align-items:center;gap:6px;padding:2px 0;}
.fs-pose-row label{flex:0 0 22px;font-size:10px;color:#888;}
.fs-pose-row .pose-axis-x{color:#ff5555;}
.fs-pose-row .pose-axis-y{color:#55ff55;}
.fs-pose-row .pose-axis-z{color:#5599ff;}
.fs-pose-row button{width:24px;height:22px;background:rgba(255,255,255,0.06);color:#fff;border:1px solid rgba(255,255,255,0.12);border-radius:4px;cursor:pointer;font-family:inherit;padding:0;font-size:14px;}
.fs-pose-row button:hover{background:rgba(168,85,247,0.3);border-color:#a78bfa;}
.fs-pose-row .pose-val{flex:1;text-align:center;color:#ff9a3a;font-variant-numeric:tabular-nums;font-family:monospace;font-size:11px;cursor:text;padding:2px 0;border-radius:3px;}
.fs-pose-row .pose-val:hover{background:rgba(255,255,255,0.05);}
.fs-pose-row .pose-val:focus{outline:1px solid #a78bfa;background:rgba(0,0,0,0.5);}
#fs-pose-panel .pose-bone-select{width:100%;background:rgba(20,16,40,0.8);color:#fff;border:1px solid rgba(168,85,247,0.3);border-radius:5px;padding:5px 8px;font:inherit;font-size:11px;}
#fs-pose-panel .pose-anim-bar{display:flex;gap:4px;flex-wrap:wrap;}
#fs-pose-panel .pose-anim-bar button{background:rgba(255,255,255,0.06);color:#fff;border:1px solid rgba(255,255,255,0.12);border-radius:11px;padding:3px 9px;font-size:10px;cursor:pointer;font-family:inherit;}
#fs-pose-panel .pose-anim-bar button.active{background:#ff9a3a;color:#1a1000;border-color:#ff9a3a;font-weight:700;}
#fs-pose-panel .gizmo-btn,
#fs-pose-panel .gizmo-space-btn{flex:1;background:rgba(255,255,255,0.06);color:#fff;border:1px solid rgba(255,255,255,0.12);border-radius:5px;padding:5px 8px;cursor:pointer;font:inherit;font-size:10px;transition:background .12s;}
#fs-pose-panel .gizmo-btn:hover,
#fs-pose-panel .gizmo-space-btn:hover{background:rgba(168,85,247,0.2);border-color:#a78bfa;}
#fs-pose-panel .gizmo-btn.active{background:#a78bfa;color:#1a1000;border-color:#a78bfa;font-weight:700;}
#fs-pose-panel .gizmo-space-btn.active{background:rgba(85,153,255,0.6);color:#fff;border-color:#5599ff;font-weight:700;}

/* Rig Tuner panel — tabs + dropdowns inside fs-pose-panel */
#fs-pose-panel .rt-char,
#fs-pose-panel .rt-prop,
#fs-pose-panel .rt-attach-bone,
#fs-pose-panel .rt-offset-bone,
#fs-pose-panel .rt-bone-filter{width:100%;background:rgba(20,16,40,0.8);color:#fff;border:1px solid rgba(168,85,247,0.3);border-radius:5px;padding:5px 8px;font:inherit;font-size:11px;margin-bottom:2px;box-sizing:border-box;}
#fs-pose-panel .rt-bone-filter{background:rgba(40,30,60,0.8);color:#ffd97a;}
#fs-pose-panel .rt-bone-filter::placeholder{color:#888;}
#fs-pose-panel .rt-bone-filter:focus{outline:none;border-color:#a78bfa;background:rgba(40,30,60,0.95);}
#fs-pose-panel .rt-tab{flex:1;background:rgba(255,255,255,0.06);color:#aaa;border:none;border-bottom:2px solid transparent;padding:6px 4px;cursor:pointer;font:inherit;font-size:11px;transition:background .12s;}
#fs-pose-panel .rt-tab:hover{background:rgba(255,255,255,0.1);color:#fff;}
#fs-pose-panel .rt-tab.active{color:#a78bfa;border-bottom-color:#a78bfa;background:rgba(168,85,247,0.08);font-weight:700;}
#fs-pose-panel .rt-save{flex:1;background:rgba(167,139,250,0.25);color:#fff;border:1px solid rgba(167,139,250,0.5);border-radius:6px;padding:8px 10px;cursor:pointer;font:inherit;font-size:11px;font-weight:700;}
#fs-pose-panel .rt-save:hover{background:rgba(167,139,250,0.4);}
#fs-pose-panel .rt-save:disabled{opacity:0.6;cursor:default;}
#fs-pose-panel .rt-bind-toggle{width:100%;background:rgba(255,255,255,0.04);color:#aaa;border:1px solid rgba(255,255,255,0.12);border-radius:5px;padding:6px 10px;cursor:pointer;font:inherit;font-size:11px;margin-top:4px;transition:background .12s;}
#fs-pose-panel .rt-bind-toggle:hover{background:rgba(255,255,255,0.1);color:#fff;}
#fs-pose-panel .rt-bind-toggle.active{background:rgba(167,139,250,0.25);color:#a78bfa;border-color:#a78bfa;font-weight:700;}
#fs-pose-panel .rt-gizmo-btn,
#fs-pose-panel .rt-gizmo-space{flex:1;background:rgba(255,255,255,0.06);color:#fff;border:1px solid rgba(255,255,255,0.12);border-radius:5px;padding:5px 6px;cursor:pointer;font:inherit;font-size:10px;transition:background .12s;}
#fs-pose-panel .rt-gizmo-btn:hover,
#fs-pose-panel .rt-gizmo-space:hover{background:rgba(168,85,247,0.2);border-color:#a78bfa;}
#fs-pose-panel .rt-gizmo-btn.active{background:#a78bfa;color:#1a1000;border-color:#a78bfa;font-weight:700;}
#fs-pose-panel .rt-gizmo-btn:disabled{opacity:0.35;cursor:not-allowed;background:rgba(255,255,255,0.02);}
#fs-pose-panel .rt-gizmo-btn:disabled:hover{background:rgba(255,255,255,0.02);border-color:rgba(255,255,255,0.12);}
#fs-pose-panel .rt-gizmo-space.active{background:rgba(85,153,255,0.6);color:#fff;border-color:#5599ff;font-weight:700;}
#fs-pose-panel kbd{background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.15);border-radius:3px;padding:1px 4px;font-family:monospace;font-size:9px;}
#fs-pose-panel .pose-actions{display:flex;gap:6px;margin-top:8px;}
#fs-pose-panel .pose-actions button{flex:1;background:rgba(255,154,58,0.18);color:#fff;border:1px solid rgba(255,154,58,0.4);border-radius:6px;padding:7px 10px;cursor:pointer;font:inherit;font-size:11px;}
#fs-pose-panel .pose-actions button:hover{background:rgba(255,154,58,0.32);}
#fs-pose-panel .pose-actions button.secondary{background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.15);}

/* Asset panel inside fs-modal — slot info + iter-panel + history + drop zone */
#fs-asset-panel{position:absolute;top:60px;right:18px;width:340px;max-height:calc(100vh - 200px);overflow-y:auto;
  background:rgba(0,0,0,0.78);border:1px solid rgba(255,217,122,0.4);border-radius:10px;
  padding:12px 14px;color:#fff;font:11px/1.4 system-ui,sans-serif;
  backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  z-index:5;box-shadow:0 4px 20px rgba(0,0,0,0.5);}
#fs-asset-panel h4{margin:8px 0 4px 0;font-size:10px;color:#ffd97a;font-weight:700;letter-spacing:1px;text-transform:uppercase;}
#fs-asset-panel h4:first-child{margin-top:0;}
#fs-asset-panel .fs-asset-name{font-size:13px;font-weight:700;color:#fff;word-break:break-all;}
#fs-asset-panel .fs-asset-meta{font-size:10px;color:#888;margin-top:2px;display:flex;gap:8px;flex-wrap:wrap;}
#fs-asset-panel .fs-asset-note{font-size:11px;color:#aaa;line-height:1.4;margin-top:6px;font-style:italic;border-left:2px solid rgba(255,217,122,0.3);padding-left:8px;}
#fs-asset-panel .iter-panel{border-top:none;background:transparent;padding:0;margin:8px 0 0;}
#fs-asset-panel .iter-panel .iter-row{margin:4px 0;}
#fs-asset-panel .iter-panel textarea{width:100%;background:rgba(20,16,40,0.8);color:#fff;border:1px solid rgba(255,255,255,0.15);border-radius:5px;padding:6px 8px;font:inherit;font-size:11px;min-height:50px;resize:vertical;box-sizing:border-box;}
#fs-asset-panel .iter-panel select{width:100%;background:rgba(20,16,40,0.8);color:#fff;border:1px solid rgba(255,255,255,0.15);border-radius:5px;padding:5px 8px;font:inherit;font-size:11px;}
#fs-asset-panel .iter-panel .iter-eta{font-size:10px;color:#aaa;margin:3px 0;}
#fs-asset-panel .iter-panel .iter-tip{font-size:9px;color:#666;font-style:italic;}
#fs-asset-panel .iter-panel .iter-buttons{display:flex;gap:6px;margin-top:6px;}
#fs-asset-panel .iter-panel button{flex:1;background:rgba(255,217,122,0.18);color:#fff;border:1px solid rgba(255,217,122,0.4);border-radius:6px;padding:7px 10px;cursor:pointer;font:inherit;font-size:11px;}
#fs-asset-panel .iter-panel button:hover{background:rgba(255,217,122,0.32);}
#fs-asset-panel .iter-panel button.copy-btn{background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.15);}
#fs-asset-panel .iter-panel .last-gen{font-size:10px;color:#888;margin-top:6px;line-height:1.4;}
#fs-asset-panel .source-toggle{font-size:10px;}
#fs-asset-panel .fs-asset-history{margin-top:6px;max-height:280px;overflow-y:auto;border-top:1px solid rgba(255,255,255,0.1);padding-top:6px;}
#fs-asset-panel .fs-asset-history-row{display:flex;gap:6px;align-items:flex-start;padding:4px;border-radius:4px;cursor:pointer;}
#fs-asset-panel .fs-asset-history-row:hover{background:rgba(255,255,255,0.05);}
#fs-asset-panel .fs-asset-history-row img{width:48px;height:48px;object-fit:cover;border-radius:3px;background:#222;flex-shrink:0;}
#fs-asset-panel .fs-asset-history-row .h-meta{flex:1;font-size:10px;line-height:1.3;color:#aaa;min-width:0;}
#fs-asset-panel .fs-asset-history-row .h-meta .h-prompt{color:#ddd;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
#fs-asset-panel .fs-asset-history-row .h-meta .h-time{color:#666;font-size:9px;margin-top:1px;}
#fs-asset-panel .fs-drop-zone{border:1px dashed rgba(255,217,122,0.3);border-radius:6px;padding:8px;text-align:center;font-size:10px;color:#888;margin-top:6px;cursor:pointer;}
#fs-asset-panel .fs-drop-zone.drag-over{border-color:#ffd97a;background:rgba(255,217,122,0.08);color:#fff;}
.pose-controls h4{margin:0 0 4px 0;font-size:11px;color:var(--muted);font-weight:700;letter-spacing:1px;text-transform:uppercase;}
.pose-row{display:flex;align-items:center;gap:6px;padding:3px 0;}
.pose-row label{flex:0 0 28px;font-size:10px;color:var(--muted);}
.pose-row .pose-axis-x{color:#ff5555;}
.pose-row .pose-axis-y{color:#55ff55;}
.pose-row .pose-axis-z{color:#5599ff;}
.pose-row button{width:24px;height:22px;background:rgba(255,255,255,.06);color:#fff;border:1px solid rgba(255,255,255,.12);border-radius:4px;cursor:pointer;font-family:inherit;padding:0;font-size:14px;}
.pose-row button:hover{background:rgba(255,154,58,.2);border-color:#ff9a3a;}
.pose-row .pose-val{flex:1;text-align:center;color:#ff9a3a;font-variant-numeric:tabular-nums;font-family:monospace;font-size:11px;cursor:text;}
.pose-row .pose-val:hover{background:rgba(255,255,255,0.05);border-radius:3px;}
.pose-bone-select{width:100%;background:var(--surface2);color:#fff;border:1px solid var(--border);border-radius:6px;padding:5px 8px;font:inherit;font-size:11px;}
.pose-actions{display:flex;gap:8px;margin-top:6px;}
.pose-actions button{flex:1;background:rgba(255,154,58,0.15);color:#fff;border:1px solid rgba(255,154,58,0.4);border-radius:6px;padding:6px 10px;cursor:pointer;font:inherit;font-size:11px;transition:background .12s;}
.pose-actions button:hover{background:rgba(255,154,58,0.3);}
.pose-actions button.secondary{background:rgba(255,255,255,0.06);border-color:rgba(255,255,255,0.15);}
.card3d{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden;
  display:flex;flex-direction:column;position:relative;transition:border-color .2s;}
.card3d:hover{border-color:rgba(255,217,122,.3);}
.card3d canvas{width:100%;height:200px;display:block;cursor:grab;}
.card3d canvas:active{cursor:grabbing;}
.card3d .info{padding:10px 12px;display:flex;flex-direction:column;gap:4px;}
.card3d .cname{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.card3d .stats{font-size:11px;color:var(--muted);display:flex;gap:8px;flex-wrap:wrap;min-height:16px;}
.badge{font-size:9px;font-weight:700;letter-spacing:1px;padding:2px 6px;border-radius:20px;text-transform:uppercase;}
.badge-glb {background:rgba(59,130,246,.18);color:var(--blue);border:1px solid rgba(59,130,246,.25);}
.badge-proc{background:rgba(168,85,247,.18);color:var(--purple);border:1px solid rgba(168,85,247,.25);}
.badge-vfx {background:rgba(234,179,8,.18);color:#facc15;border:1px solid rgba(234,179,8,.25);}
.no-anim{color:var(--red);}.has-anim{color:var(--green);}.has-rig{color:var(--purple);}
.spinner{height:200px;display:flex;align-items:center;justify-content:center;background:var(--surface2);text-align:center;}
.ring{width:26px;height:26px;border:3px solid rgba(255,255,255,.1);border-top-color:var(--accent);
  border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 7px;}
@keyframes spin{to{transform:rotate(360deg);}}

/* ── Inline iteration panel (always visible on GLB + image cards) ── */
.iter-panel{padding:10px 12px;border-top:1px solid var(--border);background:var(--surface2);}
.iter-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;gap:8px;}
.iter-label{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;
  color:var(--muted);display:flex;align-items:center;gap:5px;}
.iter-label::before{content:"✏️";font-size:11px;}
.iter-expand{background:none;border:1px solid var(--border);color:var(--muted);font-size:12px;
  cursor:pointer;padding:1px 7px;border-radius:5px;font-family:inherit;line-height:1.2;
  transition:all .12s;}
.iter-expand:hover{color:var(--accent);border-color:rgba(255,217,122,.45);background:rgba(255,217,122,.05);}
.iter-prompt{width:100%;background:var(--bg);border:1px solid var(--border);border-radius:7px;
  color:var(--text);font-size:12px;padding:7px 9px;resize:vertical;height:56px;
  min-height:56px;max-height:500px;
  font-family:inherit;outline:none;line-height:1.45;}
.iter-prompt.expanded{height:200px;}
.iter-prompt:focus{border-color:rgba(255,217,122,.5);box-shadow:0 0 0 2px rgba(255,217,122,.08);}
.iter-prompt::placeholder{color:rgba(136,153,170,.55);}
.iter-model{width:100%;margin-top:6px;font-size:11px;background:var(--bg);
  border:1px solid var(--border);color:var(--text);padding:5px 8px;border-radius:6px;
  font-family:inherit;cursor:pointer;outline:none;}
.iter-model:hover{border-color:rgba(255,217,122,.35);}
.iter-model:focus{border-color:rgba(255,217,122,.5);box-shadow:0 0 0 2px rgba(255,217,122,.08);}
.iter-model option{background:var(--surface);color:var(--text);}

/* ── Model ETA + cost meta chip (live, updates on dropdown change) ── */
.model-meta{margin-top:4px;font-size:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;
  padding:4px 8px;background:rgba(255,255,255,.025);border-radius:5px;line-height:1.4;}
.model-meta .meta-eta{color:var(--blue);font-weight:600;font-variant-numeric:tabular-nums;}
.model-meta .meta-cost{color:var(--accent);font-weight:600;}
.model-meta .meta-tip{color:var(--muted);font-size:9px;font-style:italic;flex:1 1 100%;}
.iter-actions{display:flex;gap:6px;margin-top:7px;flex-wrap:wrap;}
.gen-btn{font-size:11px;font-weight:700;padding:5px 12px;border-radius:7px;border:none;cursor:pointer;
  letter-spacing:.5px;transition:transform .1s,opacity .1s;white-space:nowrap;flex:1;min-width:0;}
.gen-btn:hover{transform:scale(1.03);}
.gen-btn.primary{background:var(--accent);color:#1a1000;}
.gen-btn.secondary{background:rgba(255,255,255,.07);color:var(--text);border:1px solid var(--border);flex:0 0 auto;}
.gen-btn:disabled{opacity:.4;cursor:not-allowed;transform:none;}
.gen-status{margin-top:7px;font-size:11px;padding:5px 9px;border-radius:6px;display:none;line-height:1.4;}
.gen-status.pending  {display:block;background:rgba(234,179,8,.1);color:#facc15;border:1px solid rgba(234,179,8,.2);}
.gen-status.generating{display:block;background:rgba(96,165,250,.1);color:var(--blue);border:1px solid rgba(96,165,250,.2);}
.gen-status.done     {display:block;background:rgba(74,222,128,.1);color:var(--green);border:1px solid rgba(74,222,128,.2);}
.gen-status.error    {display:block;background:rgba(248,113,113,.1);color:var(--red);border:1px solid rgba(248,113,113,.2);}

/* ── Queue sidebar ── */
#queue-panel{position:fixed;right:0;top:0;bottom:0;width:300px;background:var(--surface);
  border-left:1px solid var(--border);z-index:100;display:flex;flex-direction:column;
  transform:translateX(100%);transition:transform .25s ease;}
#queue-panel.open{transform:none;}
#queue-toggle{position:fixed;right:16px;bottom:20px;background:var(--accent);color:#1a1000;
  border:none;border-radius:50%;width:48px;height:48px;font-size:20px;cursor:pointer;
  box-shadow:0 4px 16px rgba(0,0,0,.5);z-index:101;transition:transform .15s;}
#queue-toggle:hover{transform:scale(1.1);}
#queue-panel .qheader{padding:16px;border-bottom:1px solid var(--border);display:flex;
  align-items:center;justify-content:space-between;}
#queue-panel .qheader h3{font-size:14px;font-weight:700;}
#queue-panel .close-q{background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;padding:0 4px;}
#queue-list{flex:1;overflow-y:auto;padding:12px;}
.q-item{background:var(--surface2);border:1px solid var(--border);border-radius:8px;
  padding:10px 12px;margin-bottom:8px;font-size:12px;}
.q-item .qi-name{font-weight:700;color:var(--text);margin-bottom:3px;}
.q-item .qi-prompt{color:var(--muted);margin-bottom:5px;line-height:1.4;max-height:40px;overflow:hidden;}
.q-item .qi-status{font-size:10px;font-weight:700;letter-spacing:1px;padding:2px 7px;border-radius:20px;display:inline-block;}
.qi-status.pending  {background:rgba(234,179,8,.15);color:#facc15;}
.qi-status.generating{background:rgba(96,165,250,.15);color:var(--blue);}
.qi-status.done     {background:rgba(74,222,128,.15);color:var(--green);}
.qi-status.error    {background:rgba(248,113,113,.15);color:var(--red);}
.q-item .qi-meta{color:var(--muted);font-size:10px;margin-top:4px;}
.q-badge{display:none;position:absolute;top:-5px;right:-5px;background:var(--red);color:#fff;
  border-radius:50%;width:18px;height:18px;font-size:10px;font-weight:700;align-items:center;
  justify-content:center;pointer-events:none;}
.q-badge.show{display:flex;}
#queue-toggle{position:fixed;}

/* ── Image grid ── */
.grid-img{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;}
.card-img{background:var(--surface);border:1px solid var(--border);border-radius:10px;overflow:hidden;position:relative;}
.card-img img{width:100%;display:block;object-fit:contain;background:rgba(0,0,0,.35);min-height:110px;max-height:170px;}
.card-img .info{padding:7px 10px;font-size:11px;}
.card-img .cname{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.card-img .stats{color:var(--muted);margin-top:2px;}
/* ── Audio ── */
.audio-list{display:flex;flex-direction:column;gap:7px;}
.audio-row{background:var(--surface);border:1px solid var(--border);border-radius:9px;
  padding:9px 12px;display:flex;align-items:center;gap:12px;}
.play-btn{width:30px;height:30px;border-radius:50%;border:none;cursor:pointer;
  background:var(--accent);color:#1a1000;font-size:13px;display:flex;align-items:center;
  justify-content:center;flex:0 0 auto;transition:transform .1s;}
.play-btn:hover{transform:scale(1.1);}.play-btn.playing{background:var(--green);}
.aname{font-size:13px;font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;}
.asize{font-size:11px;color:var(--muted);}

.note{background:rgba(255,217,122,.06);border:1px solid rgba(255,217,122,.16);border-radius:8px;
  padding:9px 13px;font-size:12px;color:#ffd97a;margin-bottom:12px;max-width:800px;line-height:1.5;}
.note strong{color:#ffe9a3;font-weight:700;}

/* ── Concept creator form ── */
#concept-creator{background:var(--surface);border:1px dashed rgba(192,132,252,.35);
  border-radius:10px;padding:14px 16px;margin-bottom:14px;}
.cc-title{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;
  color:var(--purple);margin-bottom:9px;display:flex;align-items:center;gap:6px;}
.cc-row{display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start;}
.cc-name{flex:0 0 200px;background:var(--bg);border:1px solid var(--border);border-radius:6px;
  color:var(--text);font-size:12px;padding:7px 9px;font-family:inherit;outline:none;}
.cc-name:focus{border-color:rgba(192,132,252,.5);box-shadow:0 0 0 2px rgba(192,132,252,.1);}
.cc-prompt{flex:1 1 360px;min-height:38px;background:var(--bg);border:1px solid var(--border);
  border-radius:6px;color:var(--text);font-size:12px;padding:7px 9px;resize:vertical;
  font-family:inherit;outline:none;line-height:1.4;}
.cc-prompt:focus{border-color:rgba(192,132,252,.5);box-shadow:0 0 0 2px rgba(192,132,252,.1);}
.cc-row2{display:flex;gap:8px;margin-top:8px;align-items:center;flex-wrap:wrap;}
.cc-model{flex:1 1 240px;font-size:11px;background:var(--bg);border:1px solid var(--border);
  color:var(--text);padding:6px 8px;border-radius:6px;font-family:inherit;cursor:pointer;outline:none;}
.cc-create{background:var(--purple);color:#1a0030;font-weight:700;font-size:12px;
  padding:7px 16px;border:none;border-radius:7px;cursor:pointer;letter-spacing:.5px;
  transition:transform .1s;white-space:nowrap;}
.cc-create:hover{transform:scale(1.04);}
.cc-create:disabled{opacity:.4;cursor:not-allowed;transform:none;}
.cc-status{margin-top:7px;font-size:11px;color:var(--muted);min-height:14px;}

/* ── GLB Ref dropdown (image-to-3D source) ── */
.iter-ref{width:100%;margin-top:6px;font-size:11px;background:var(--bg);
  border:1px solid var(--border);color:var(--text);padding:5px 8px;border-radius:6px;
  font-family:inherit;cursor:pointer;outline:none;}
.iter-ref:hover{border-color:rgba(192,132,252,.4);}
.iter-ref:focus{border-color:rgba(192,132,252,.5);box-shadow:0 0 0 2px rgba(192,132,252,.1);}
.iter-ref.has-ref{border-color:rgba(192,132,252,.55);background:rgba(192,132,252,.06);}

/* ── Concept / Ref badges on image cards ── */
.card-img{position:relative;}
.card-img.is-concept{border-color:rgba(192,132,252,.3);}
.card-img.is-concept .info::before{content:"🎨 CONCEPT";display:block;font-size:9px;
  font-weight:700;letter-spacing:1.2px;color:var(--purple);margin-bottom:3px;}
.card-img.is-ref{border-color:rgba(96,165,250,.3);}
.card-img.is-ref .info::before{content:"📎 UPLOADED REF";display:block;font-size:9px;
  font-weight:700;letter-spacing:1.2px;color:var(--blue);margin-bottom:3px;}

/* ── Ref upload drop-zone ── */
#ref-uploader{background:var(--surface);border:2px dashed rgba(96,165,250,.35);
  border-radius:10px;padding:18px 16px;margin-bottom:14px;text-align:center;
  transition:border-color .15s, background .15s;cursor:pointer;}
#ref-uploader:hover{border-color:rgba(96,165,250,.6);background:rgba(96,165,250,.04);}
#ref-uploader.dragover{border-color:var(--blue);background:rgba(96,165,250,.12);transform:scale(1.005);}
#ref-uploader .up-icon{font-size:24px;display:block;margin-bottom:5px;}
#ref-uploader .up-title{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;
  color:var(--blue);margin-bottom:5px;}
#ref-uploader .up-hint{font-size:11px;color:var(--muted);line-height:1.5;}
#ref-uploader .up-hint code{background:rgba(255,255,255,.06);padding:1px 5px;border-radius:4px;
  font-size:10px;color:var(--blue);}
#ref-uploader .up-status{margin-top:8px;font-size:11px;min-height:14px;}
#ref-uploader .up-status code{background:rgba(255,255,255,.06);padding:1px 5px;border-radius:4px;font-size:10px;}

/* ── Fullscreen / zoom button on every card ── */
/* Moved to the TOP-RIGHT corner so they don't collide with the Krea-style
   version navigator at top-left. Matches Krea Nodes layout: arrows on the
   left, utility actions on the right. */
.fs-btn{position:absolute;top:8px;right:8px;background:rgba(0,0,0,.55);color:#fff;
  border:1px solid rgba(255,255,255,.15);border-radius:6px;width:28px;height:28px;
  font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;
  z-index:5;opacity:0;transition:opacity .15s, transform .12s;}
.hist-btn{position:absolute;top:8px;right:42px;background:rgba(0,0,0,.55);color:#fff;
  border:1px solid rgba(255,255,255,.15);border-radius:6px;width:28px;height:28px;
  font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;
  z-index:5;opacity:0;transition:opacity .15s, transform .12s;}
.card3d:hover .fs-btn, .card-img:hover .fs-btn,
.card3d:hover .hist-btn, .card-img:hover .hist-btn{opacity:1;}
.fs-btn:hover{transform:scale(1.1);background:var(--accent);color:#1a1000;border-color:var(--accent);}
.hist-btn:hover{transform:scale(1.1);background:var(--purple);color:#fff;border-color:var(--purple);}
.hist-btn .pulse{position:absolute;top:-2px;right:-2px;width:8px;height:8px;border-radius:50%;
  background:var(--purple);box-shadow:0 0 0 2px var(--surface);}

/* ── Slot status (border tint + corner badge) ── */
.card3d, .card-img { position:relative; }
[data-slot-status="empty"]       { border-color:rgba(248,113,113,.45) !important; background:rgba(248,113,113,.03); }
[data-slot-status="placeholder"] { border-color:rgba(255,217,122,.4)  !important; background:rgba(255,217,122,.025); }
[data-slot-status="polished"]    { border-color:rgba(74,222,128,.28)  !important; }

.slot-badge{position:absolute;top:8px;right:8px;font-size:8px;font-weight:800;letter-spacing:1.4px;
  padding:3px 8px;border-radius:11px;z-index:6;text-transform:uppercase;line-height:1;}
.slot-badge.empty       { background:var(--red);                 color:#fff; }
.slot-badge.placeholder { background:rgba(255,217,122,.92);      color:#1a1000; }
.slot-badge.polished    { background:rgba(74,222,128,.18);       color:var(--green); border:1px solid rgba(74,222,128,.4); }

.slot-crit{position:absolute;top:8px;right:90px;font-size:8px;font-weight:700;letter-spacing:1.2px;
  padding:2px 7px;border-radius:10px;z-index:6;text-transform:uppercase;line-height:1;
  background:rgba(0,0,0,.5);color:var(--muted);}
.slot-crit.blocker  { background:rgba(248,113,113,.18);color:#ffb3b3;border:1px solid rgba(248,113,113,.35); }
.slot-crit.important{ background:rgba(96,165,250,.15);color:var(--blue);border:1px solid rgba(96,165,250,.3); }
.slot-crit.optional { background:rgba(255,255,255,.06);color:var(--muted);border:1px solid var(--border); }

.slot-label{font-size:10px;color:var(--muted);font-style:italic;margin-top:2px;line-height:1.4;}
.slot-note{font-size:10px;color:rgba(136,153,170,.7);margin-top:3px;line-height:1.5;
  padding:5px 8px;background:rgba(255,255,255,.025);border-left:2px solid var(--border);border-radius:4px;}

/* ── Source toggle: swap between fillAsset (GLB) and procedural fallback ── */
.source-toggle{margin-top:7px;font-size:10px;display:flex;gap:5px;align-items:center;flex-wrap:wrap;
  padding:6px 8px;background:rgba(255,255,255,.025);border-radius:6px;}
.source-toggle .src-label{color:var(--muted);font-weight:700;letter-spacing:1.2px;
  text-transform:uppercase;font-size:9px;margin-right:2px;}
.src-chip{font-size:10px;padding:3px 9px;border-radius:11px;border:1px solid var(--border);
  background:rgba(255,255,255,.04);color:var(--text);cursor:pointer;font-family:inherit;
  transition:all .12s;line-height:1.3;display:inline-flex;align-items:center;gap:4px;}
.src-chip:hover{background:rgba(255,255,255,.08);transform:translateY(-1px);}
.src-chip.glb.active{background:rgba(74,222,128,.18);border-color:rgba(74,222,128,.5);
  color:var(--green);font-weight:600;}
.src-chip.proc.active{background:rgba(255,217,122,.15);border-color:rgba(255,217,122,.5);
  color:var(--accent);font-weight:600;}
.src-chip.vfx.active{background:rgba(255,217,122,.15);border-color:rgba(255,217,122,.5);
  color:var(--accent);font-weight:600;}
.src-chip:disabled{cursor:default;transform:none;}
/* Readonly = single source, no toggle possible (still active = green/yellow tint) */
.src-chip.readonly{cursor:default;opacity:.85;}
.src-chip.readonly:hover{transform:none;background:rgba(255,255,255,.04);}
.src-chip.readonly.glb.active{background:rgba(74,222,128,.14);}
.src-chip.readonly.proc.active,.src-chip.readonly.vfx.active{background:rgba(255,217,122,.12);}

/* ── Slots Overview compact chip view ── */
.slot-health{display:flex;gap:14px;font-size:12px;color:var(--muted);
  padding:10px 14px;background:rgba(255,255,255,.025);border:1px solid var(--border);
  border-radius:8px;margin-bottom:14px;align-items:center;flex-wrap:wrap;}
.slot-health .stat{display:flex;align-items:center;gap:6px;font-size:11px;}
.slot-health .stat .num{color:var(--text);font-weight:700;font-size:14px;font-variant-numeric:tabular-nums;}
.slot-health .stat.polished .num{color:var(--green);}
.slot-health .stat.placeholder .num{color:#facc15;}
.slot-health .stat.empty .num{color:var(--red);}
.slot-health .stat.total .num{color:var(--text);}
.slot-health .progress{flex:1;height:6px;min-width:120px;background:var(--bg);border-radius:3px;overflow:hidden;display:flex;}
.slot-health .progress span{display:block;height:100%;}
.slot-health .progress .pol{background:var(--green);}
.slot-health .progress .pla{background:#facc15;}
.slot-health .progress .emp{background:var(--red);}

.slots-overview{display:flex;flex-direction:column;gap:8px;}
.slot-cat-row{display:flex;align-items:flex-start;gap:10px;}
.slot-cat-label{font-size:10px;font-weight:700;letter-spacing:1.5px;color:var(--muted);
  flex:0 0 130px;text-transform:uppercase;padding-top:6px;}
.slot-cat-chips{display:flex;flex-wrap:wrap;gap:6px;flex:1;}
.slot-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:14px;
  font-size:11px;background:var(--surface);border:1px solid var(--border);cursor:pointer;
  transition:all .12s ease-out;line-height:1.2;}
.slot-chip:hover{transform:translateY(-1px);background:var(--surface2);}
.slot-chip .dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto;}
.slot-chip.status-polished .dot{background:var(--green);box-shadow:0 0 0 2px rgba(74,222,128,.15);}
.slot-chip.status-placeholder .dot{background:#facc15;box-shadow:0 0 0 2px rgba(234,179,8,.15);}
.slot-chip.status-empty .dot{background:var(--red);box-shadow:0 0 0 2px rgba(248,113,113,.15);}
.slot-chip .chip-name{color:var(--text);font-weight:600;font-size:11px;}
.slot-chip .chip-asset{color:var(--muted);font-size:10px;font-family:monospace;}
.slot-chip.status-empty{border-color:rgba(248,113,113,.4);background:rgba(248,113,113,.04);}
.slot-chip.status-placeholder{border-color:rgba(255,217,122,.3);}
.slot-chip.status-polished{border-color:rgba(74,222,128,.25);}
.slot-chip .crit-badge{font-size:9px;font-weight:900;color:#ffb3b3;background:rgba(248,113,113,.18);
  width:14px;height:14px;display:inline-flex;align-items:center;justify-content:center;border-radius:50%;}
@keyframes slotHighlight{
  0%   { box-shadow:0 0 0 4px rgba(255,217,122,.6), 0 0 24px rgba(255,217,122,.4); transform:translateY(0); }
  100% { box-shadow:0 0 0 0 rgba(255,217,122,0); transform:translateY(0); }
}
.slot-target-highlight{ animation:slotHighlight 1.7s ease-out; }

/* Empty slot ghost card (no asset on disk + no fallback) */
.card-empty{background:rgba(248,113,113,.03);border:2px dashed rgba(248,113,113,.45);
  border-radius:12px;display:flex;flex-direction:column;position:relative;overflow:hidden;}
.card-empty .ghost{height:200px;display:flex;flex-direction:column;align-items:center;justify-content:center;
  background:repeating-linear-gradient(45deg,rgba(248,113,113,.04),rgba(248,113,113,.04) 12px,
    rgba(248,113,113,.08) 12px,rgba(248,113,113,.08) 24px);color:rgba(248,113,113,.5);}
.card-empty .ghost .gx{font-size:48px;line-height:1;margin-bottom:6px;}
.card-empty .ghost .gh{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:rgba(248,113,113,.7);}
.card-empty .ghost .gp{font-size:10px;color:rgba(248,113,113,.5);margin-top:4px;font-style:italic;}
.card-empty .info{padding:10px 12px;}
.card-empty .info .cname{font-size:13px;font-weight:600;}
/* Version navigator — Krea Nodes style. Compact ◀ N/M ▶ pill overlaid on the
   top-left of the preview area, semi-transparent so the asset stays the focus.
   Arrows promote the adjacent archive on click (auto-update, no confirmation).
   Disabled when there's only the live version (no archives yet) — visible
   indicator that history exists but it's empty. */
.card3d, .card-img, .card-empty { position: relative; }
.ver-nav-krea{position:absolute;top:6px;left:6px;display:flex;align-items:center;gap:3px;
  background:rgba(0,0,0,.55);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);
  border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:2px 4px;
  z-index:5;pointer-events:auto;}
.ver-nav-krea .ver-prev,
.ver-nav-krea .ver-next{background:transparent;color:#fff;border:none;
  width:22px;height:22px;display:flex;align-items:center;justify-content:center;
  font:inherit;font-size:16px;line-height:1;cursor:pointer;padding:0;border-radius:11px;
  opacity:.9;}
.ver-nav-krea .ver-prev:hover:not([disabled]),
.ver-nav-krea .ver-next:hover:not([disabled]){background:rgba(255,255,255,.18);opacity:1;}
.ver-nav-krea .ver-prev[disabled],
.ver-nav-krea .ver-next[disabled]{opacity:.25;cursor:not-allowed;}
.ver-nav-krea .ver-count{font-size:11px;font-weight:600;color:#fff;
  padding:0 6px;min-width:34px;text-align:center;letter-spacing:.3px;
  font-variant-numeric:tabular-nums;}

/* "or pick existing" dropdown for empty slots — sits between info and iter-panel.
   Visually distinct from the (red) Generate flow with a blue accent that says
   "this is the non-destructive 'use what you already have' path". */
.card-empty .slot-assign{display:flex;gap:6px;align-items:center;padding:8px 12px;
  border-top:1px solid rgba(96,165,250,.18);background:rgba(96,165,250,.05);}
.card-empty .slot-assign-select{flex:1;background:rgba(20,16,40,0.8);color:#fff;
  border:1px solid rgba(96,165,250,.35);border-radius:5px;padding:5px 8px;
  font:inherit;font-size:11px;min-width:0;}
.card-empty .slot-assign-btn{background:rgba(96,165,250,.18);color:#cfe5ff;
  border:1px solid rgba(96,165,250,.5);border-radius:5px;padding:5px 12px;
  cursor:pointer;font:inherit;font-size:11px;}
.card-empty .slot-assign-btn:hover:not([disabled]){background:rgba(96,165,250,.32);}
.card-empty .slot-assign-btn[disabled]{opacity:.45;cursor:not-allowed;}

/* Orphan banner */
#orphan-banner{max-width:1300px;margin:0 auto 18px;background:rgba(96,165,250,.06);
  border:1px solid rgba(96,165,250,.25);border-radius:8px;padding:10px 14px;font-size:12px;
  color:var(--blue);display:flex;align-items:flex-start;gap:10px;line-height:1.5;}
#orphan-banner .ob-icon{font-size:16px;flex:0 0 auto;}
#orphan-banner .ob-list{color:var(--text);font-family:monospace;font-size:11px;
  background:rgba(0,0,0,.2);padding:2px 6px;border-radius:4px;margin:0 2px;}
#orphan-banner.hidden{display:none;}

/* All-Assets gallery (collapsible) */
.gallery-toggle{background:none;border:1px solid var(--border);color:var(--muted);
  padding:6px 12px;border-radius:7px;font-size:12px;font-family:inherit;cursor:pointer;
  transition:all .12s;display:inline-flex;align-items:center;gap:8px;}
.gallery-toggle:hover{border-color:rgba(255,217,122,.4);color:var(--accent);}
.gallery-toggle .chev{transition:transform .15s;display:inline-block;}
.gallery-toggle.open .chev{transform:rotate(90deg);}
#all-assets-gallery{display:none;margin-top:14px;padding:14px;
  background:rgba(255,255,255,.015);border:1px solid var(--border);border-radius:10px;}
#all-assets-gallery.open{display:block;}
#all-assets-gallery .ag-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;}
#all-assets-gallery .ag-tile{background:var(--surface);border:1px solid var(--border);border-radius:6px;
  padding:8px 10px;font-size:11px;display:flex;flex-direction:column;gap:2px;}
#all-assets-gallery .ag-name{font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px;}
#all-assets-gallery .ag-meta{color:var(--muted);font-size:10px;}
#all-assets-gallery .ag-meta .ag-status{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px;vertical-align:middle;}
.ag-status.empty{background:var(--red);}
.ag-status.placeholder{background:#facc15;}
.ag-status.polished{background:var(--green);}
.ag-status.unclaimed{background:var(--muted);}

/* Animation chip bar (above iter-panel, below canvas) */
.anim-bar{padding:6px 10px;background:rgba(168,85,247,.06);border-top:1px solid var(--border);
  display:flex;gap:4px;flex-wrap:wrap;align-items:center;font-size:10px;}
.anim-bar .anim-label{font-size:9px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;
  color:var(--purple);margin-right:4px;display:flex;align-items:center;gap:4px;}
.anim-bar .anim-label::before{content:"🎬";}
.anim-chip{font-size:10px;font-weight:600;letter-spacing:.4px;padding:3px 8px;
  border:1px solid var(--border);border-radius:11px;background:rgba(255,255,255,.04);
  color:var(--text);cursor:pointer;font-family:inherit;transition:all .12s;}
.anim-chip:hover{border-color:rgba(192,132,252,.5);background:rgba(192,132,252,.1);}
.anim-chip.active{background:var(--purple);color:#1a0030;border-color:var(--purple);}
.anim-chip.auto{background:rgba(255,217,122,.06);border-color:rgba(255,217,122,.3);color:var(--accent);font-style:italic;}
.anim-chip.auto.active{background:var(--accent);color:#1a1000;border-color:var(--accent);font-style:normal;}

/* ── Last-generation summary line in iter-panel ── */
.last-gen{margin-top:6px;font-size:10px;color:var(--muted);line-height:1.45;
  padding:5px 8px;background:rgba(192,132,252,.06);border-left:2px solid rgba(192,132,252,.4);
  border-radius:4px;display:none;}
.last-gen.show{display:block;}
.last-gen .lg-when{color:var(--text);font-weight:600;}
.last-gen .lg-model{color:var(--blue);}
.last-gen .lg-ref{color:var(--purple);}
.last-gen .lg-prompt{color:var(--muted);font-style:italic;display:block;margin-top:2px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}

/* ── History drawer (overlay attached to a card) ── */
.hist-drawer{position:absolute;top:42px;left:8px;right:8px;background:var(--surface);
  border:1px solid rgba(192,132,252,.35);border-radius:8px;padding:10px 12px;
  z-index:10;max-height:340px;overflow-y:auto;box-shadow:0 8px 24px rgba(0,0,0,.4);
  display:none;}
.hist-drawer.open{display:block;}
.hist-drawer h4{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;
  color:var(--purple);margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;}
.hist-drawer .close-x{background:none;border:none;color:var(--muted);font-size:14px;cursor:pointer;}
.hist-entry{font-size:11px;padding:7px 0;border-bottom:1px solid var(--border);line-height:1.5;}
.hist-entry:last-child{border-bottom:none;}
.hist-entry .he-when{color:var(--text);font-weight:600;font-size:10px;}
.hist-entry .he-model{color:var(--blue);font-size:10px;}
.hist-entry .he-ref{color:var(--purple);font-size:10px;}
.hist-entry .he-prompt{color:var(--muted);margin-top:3px;font-style:italic;}
.hist-empty{font-size:11px;color:var(--muted);padding:8px 0;text-align:center;}
.hist-section-label{font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;
  color:var(--text);margin:4px 0 4px;padding:0;}
.hist-section-label .hist-hint{font-weight:400;text-transform:none;letter-spacing:0;
  color:var(--muted);font-size:10px;}
.hist-versions{margin:2px 0 4px;}
.hist-version{display:flex;align-items:center;justify-content:space-between;gap:8px;
  font-size:11px;padding:6px 0;border-bottom:1px dashed rgba(255,255,255,.06);}
.hist-version:last-child{border-bottom:none;}
.hist-version .hv-meta{display:flex;align-items:center;gap:8px;flex:1;min-width:0;}
.hist-version .hv-when{color:var(--text);font-weight:600;font-size:10px;}
.hist-version .hv-size{color:var(--muted);font-size:10px;}
.hist-version .hv-file{color:var(--muted);font-family:monospace;font-size:10px;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.hist-version .hv-use{background:rgba(74,222,128,.15);color:#9aebbf;
  border:1px solid rgba(74,222,128,.4);border-radius:4px;padding:3px 9px;
  cursor:pointer;font:inherit;font-size:10px;}
.hist-version .hv-use:hover:not([disabled]){background:rgba(74,222,128,.28);}
.hist-version .hv-use[disabled]{opacity:.5;cursor:not-allowed;}

/* ── Fullscreen modal (lightbox) ── */
#fs-modal{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:1000;
  display:none;flex-direction:column;animation:fadeIn .15s ease-out;}
#fs-modal.open{display:flex;}
@keyframes fadeIn{from{opacity:0;}to{opacity:1;}}
#fs-header{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;
  border-bottom:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.3);flex:0 0 auto;}
#fs-title{font-size:14px;font-weight:700;color:var(--text);display:flex;align-items:center;gap:10px;}
#fs-meta{font-size:11px;color:var(--muted);font-weight:400;}
#fs-controls{display:flex;gap:6px;align-items:center;}
.fs-ctrl{background:rgba(255,255,255,.08);color:var(--text);border:1px solid rgba(255,255,255,.1);
  border-radius:7px;padding:5px 11px;font-size:12px;cursor:pointer;font-family:inherit;
  transition:background .12s;}
.fs-ctrl:hover{background:rgba(255,255,255,.16);}
.fs-ctrl.close{background:var(--red);color:#fff;border-color:var(--red);}
#fs-stage{flex:1;position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;
  background:radial-gradient(ellipse at center, #0f1a28 0%, #050810 100%);}
#fs-img-wrap{width:100%;height:100%;overflow:hidden;display:flex;align-items:center;justify-content:center;
  cursor:grab;}
#fs-img-wrap.dragging{cursor:grabbing;}
#fs-img{max-width:none;max-height:none;transform-origin:center center;
  transition:transform .05s linear;user-select:none;-webkit-user-drag:none;}
#fs-canvas{width:100%;height:100%;display:block;cursor:grab;}
#fs-canvas:active{cursor:grabbing;}
/* Animation chip bar overlay (3D fullscreen) — switch clips while zoomed in */
#fs-anim-bar{position:absolute;top:14px;left:50%;transform:translateX(-50%);
  background:rgba(0,0,0,.78);border:1px solid rgba(255,255,255,.12);border-radius:22px;
  padding:6px 10px;display:flex;gap:6px;align-items:center;max-width:92vw;overflow-x:auto;
  font-size:12px;color:var(--text);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
  z-index:5;box-shadow:0 4px 18px rgba(0,0,0,.5);scrollbar-width:thin;}
#fs-anim-bar::-webkit-scrollbar{height:6px;}
#fs-anim-bar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.18);border-radius:3px;}
#fs-anim-bar .anim-label{font-size:9px;font-weight:700;letter-spacing:1.2px;
  text-transform:uppercase;color:var(--muted);padding:0 8px 0 4px;flex-shrink:0;
  display:inline-flex;align-items:center;gap:5px;}
#fs-anim-bar .anim-label::before{content:"🎬";font-size:13px;}
#fs-anim-bar .anim-chip{background:rgba(255,255,255,.06);color:var(--text);
  border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:4px 12px;font-size:11px;
  cursor:pointer;font-family:inherit;white-space:nowrap;flex-shrink:0;
  transition:background .12s, border-color .12s, transform .08s;}
#fs-anim-bar .anim-chip:hover{background:rgba(255,255,255,.14);transform:translateY(-1px);}
#fs-anim-bar .anim-chip.active{background:var(--accent);color:#1a1000;border-color:var(--accent);font-weight:700;}
#fs-anim-bar .anim-chip.pause{background:rgba(168,85,247,.1);border-color:rgba(168,85,247,.3);color:var(--purple);}
#fs-anim-bar .anim-chip.pause:hover{background:rgba(168,85,247,.2);}
#fs-anim-bar .anim-chip.pause.active{background:var(--purple);color:#fff;border-color:var(--purple);}

#fs-zoom{position:absolute;bottom:18px;left:50%;transform:translateX(-50%);
  background:rgba(0,0,0,.7);border:1px solid rgba(255,255,255,.1);border-radius:24px;
  padding:6px 14px;display:flex;gap:10px;align-items:center;font-size:12px;color:var(--text);}
#fs-zoom button{background:rgba(255,255,255,.1);border:none;color:#fff;width:24px;height:24px;
  border-radius:50%;font-size:14px;cursor:pointer;font-weight:700;}
#fs-zoom button:hover{background:var(--accent);color:#1a1000;}
#fs-zoom .zlevel{min-width:48px;text-align:center;font-variant-numeric:tabular-nums;}

/* ── Drag-drop replace overlay (any card with data-asset accepts a drop) ── */
.card3d.drag-over, .card-img.drag-over{
  outline:3px dashed var(--accent);outline-offset:-3px;
  background:rgba(255,217,122,.08) !important;
  transform:scale(1.005);transition:transform .12s, background .12s;
}
.card3d.drag-over::after, .card-img.drag-over::after{
  content:"📥 Drop to replace";position:absolute;inset:0;display:flex;
  align-items:center;justify-content:center;background:rgba(255,217,122,.18);
  font-size:14px;font-weight:700;letter-spacing:1px;color:var(--accent);
  z-index:50;pointer-events:none;border-radius:11px;backdrop-filter:blur(2px);
}
.card3d.drag-replace-success, .card-img.drag-replace-success{
  animation:flashUpdate .9s ease-out;
}

/* ── Update flash ── */
@keyframes flashUpdate{0%{box-shadow:0 0 0 0 rgba(74,222,128,.7);}100%{box-shadow:0 0 0 8px rgba(74,222,128,0);}}
.flash-update{animation:flashUpdate .6s ease-out;}
</style>
</head>
<body>

<header>
  <div>
    <h1>🎮 ${CONFIG.title} — <span>${CONFIG.subtitle}</span></h1>
    <div class="meta" id="meta-line">Loading…</div>
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex:1;justify-content:flex-end;">
    <input id="global-search" type="text" placeholder="🔍 Search slots & assets… (slot id, label, note, filename)"
      style="background:rgba(20,16,40,0.8);color:#fff;border:1px solid rgba(255,217,122,0.3);border-radius:8px;padding:8px 12px;font:inherit;font-size:13px;width:380px;max-width:50vw;outline:none;transition:border-color .12s;" />
    <span id="search-count" style="font-size:11px;color:var(--muted);min-width:80px;"></span>
    <span class="hbadge live-badge">● LIVE</span>
    <span class="hbadge" style="background:rgba(96,165,250,.12);color:var(--blue);border:1px solid rgba(96,165,250,.2);">localhost:${PORT}</span>
    <!-- Launch the dev playable in a new tab. Game dev server is hosted by
         start-dev.bat at localhost:8080. Disabled state isn't worth detecting
         live (it'd require a polling fetch with no-cors); the browser opens
         the URL and shows an error page if it's down — clear failure mode. -->
    <a id="launch-playable" class="hbadge" href="http://localhost:8080" target="_blank" rel="noopener"
       style="background:rgba(74,222,128,.15);color:#9aebbf;border:1px solid rgba(74,222,128,.45);text-decoration:none;cursor:pointer;font-weight:600;"
       title="Open the working playable (dev server on :8080) in a new tab">▶ Play</a>
  </div>
</header>

<!-- Orphan banner: appears if any asset on disk isn't claimed by a slot -->
<div id="orphan-banner" class="hidden"></div>

<!-- All sections rendered dynamically. Slots view (preferred) replaces the
     legacy categories view when the config defines slots[]. -->
<div id="dynamic-sections"></div>

<div class="section" id="sec-refs-concepts">
  <div class="section-title">🎨 Refs &amp; Concepts</div>
  <div class="note">2D images that drive 3D generation. <strong>📎 Refs</strong> are uploaded from outside (Figma exports, photos, sketches). <strong>🎨 Concepts</strong> are AI-generated. Both show up in every GLB card's <strong>🎨 Ref</strong> dropdown — Hunyuan/Rodin/Tripo produce way better models with a clear visual reference than from text alone.</div>
  <div id="ref-uploader"></div>
  <div id="concept-creator"></div>
  <div class="grid-img" id="grid-concept"></div>
</div>
<div class="section" id="sec-vfx" style="display:none;">
  <div class="section-title">✨ VFX</div>
  <div class="grid3d" id="grid-vfx"></div>
</div>
<div class="section">
  <div class="section-title">🖼 UI Assets</div>
  <div class="grid-img" id="grid-img"></div>
</div>
<div class="section">
  <div class="section-title">🔊 Audio</div>
  <div class="audio-list" id="audio-list"></div>
</div>

<div class="section">
  <button class="gallery-toggle" id="gallery-toggle"><span class="chev">▶</span> 🗂 All assets gallery <span style="opacity:.5;">(flat list)</span></button>
  <div id="all-assets-gallery"><div class="ag-grid" id="ag-grid"></div></div>
</div>

<!-- Fullscreen / zoom modal -->
<div id="fs-modal">
  <div id="fs-header">
    <div id="fs-title">— <span id="fs-meta"></span></div>
    <div id="fs-controls">
      <button class="fs-ctrl" id="fs-fit">Fit</button>
      <button class="fs-ctrl" id="fs-actual">100%</button>
      <button class="fs-ctrl close" id="fs-close">✕ Close (Esc)</button>
    </div>
  </div>
  <div id="fs-stage">
    <div id="fs-img-wrap" style="display:none;"><img id="fs-img" alt=""></div>
    <canvas id="fs-canvas" style="display:none;"></canvas>
    <div id="fs-anim-bar" style="display:none;"></div>
    <div id="fs-pose-panel" style="display:none;"></div>
    <div id="fs-asset-panel" style="display:none;"></div>
    <div id="fs-zoom"><button id="fs-zout">−</button><span class="zlevel" id="fs-zlvl">100%</span><button id="fs-zin">+</button></div>
  </div>
</div>

<!-- Queue sidebar -->
<button id="queue-toggle" title="Generation Queue">🔧<span id="q-badge" class="q-badge"></span></button>
<div id="queue-panel">
  <div class="qheader">
    <h3>⚙️ Generation Queue</h3>
    <button class="close-q" onclick="document.getElementById('queue-panel').classList.remove('open')">✕</button>
  </div>
  <div id="queue-list"><div style="padding:16px;font-size:12px;color:var(--muted);">No requests yet.<br><br>Click ✏️ on any asset card to start iterating.</div></div>
</div>

<script id="init-data" type="application/json">${initData}</script>

<script type="importmap">
${JSON.stringify({ imports: {
  // Served locally from packages/asset-studio/node_modules/three via the
  // /vendor/three/* route. Avoids CDN dependency so the studio works under
  // strict ad blockers (Opera, Brave) and offline.
  'three': '/vendor/three/build/three.module.js',
  'three/addons/': '/vendor/three/examples/jsm/',
}}, null, 2)}
</script>
<script type="module" src="/api/client.js?t=${Date.now()}"></script>
</body>
</html>`;
}

// ── Request helpers ───────────────────────────────────────────────────────────
function parseBody(req) {
  return new Promise((res, rej) => {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => { try { res(JSON.parse(body || '{}')); } catch { res({}); } });
    req.on('error', rej);
  });
}

function json(res, data, status = 200) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(body);
}

// ── Server ────────────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  const url    = new URL(req.url, `http://localhost:${PORT}`);
  const method = req.method;
  const pname  = url.pathname;

  // CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }

  // ── GET / ─────────────────────────────────────────────────────────────────
  if (method === 'GET' && pname === '/') {
    const html = buildHTML();
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache, no-store, must-revalidate' });
    return res.end(html);
  }

  // ── GET /assets/:name ─────────────────────────────────────────────────────
  if (method === 'GET' && pname.startsWith('/assets/')) {
    const name = path.basename(pname);
    const fp   = path.join(ASSETS, name);
    if (!fs.existsSync(fp)) { res.writeHead(404); return res.end('Not found'); }
    const ext  = path.extname(name).toLowerCase();
    const mime = MIMES[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-cache', 'Access-Control-Allow-Origin': '*' });
    return fs.createReadStream(fp).pipe(res);
  }

  // ── GET /vendor/three/* ─────────────────────────────────────────────────
  // Serve Three.js + addons locally so browsers with strict ad blockers
  // (Opera, Brave, Firefox-strict) work without CDN access. Importmap on the
  // page routes `three` and `three/addons/` here. We resolve `three` via
  // createRequire so it works whether npm hoists it to the consumer's top
  // node_modules or keeps it inside the package dir.
  if (method === 'GET' && pname.startsWith('/vendor/three/')) {
    const rel = pname.slice('/vendor/three/'.length);
    const fp = path.join(THREE_ROOT, rel);
    if (!path.resolve(fp).startsWith(THREE_ROOT + path.sep)) { res.writeHead(403); return res.end('forbidden'); }
    if (!fs.existsSync(fp)) { res.writeHead(404); return res.end('vendor file not found'); }
    res.writeHead(200, { 'Content-Type': 'application/javascript', 'Cache-Control': 'public, max-age=86400' });
    return fs.createReadStream(fp).pipe(res);
  }

  // ── GET /api/client.js ───────────────────────────────────────────────────
  if (method === 'GET' && pname === '/api/client.js') {
    const fp = path.join(__dir, 'asset-viewer-live.js');
    if (!fs.existsSync(fp)) { res.writeHead(404); return res.end('client not found'); }
    res.writeHead(200, { 'Content-Type': 'application/javascript', 'Cache-Control': 'no-cache' });
    return fs.createReadStream(fp).pipe(res);
  }

  // ── GET /api/queue ────────────────────────────────────────────────────────
  if (method === 'GET' && pname === '/api/queue') {
    return json(res, readQueue());
  }

  // ── POST /api/queue ───────────────────────────────────────────────────────
  if (method === 'POST' && pname === '/api/queue') {
    const body = await parseBody(req);
    if (!body.assetName || !body.prompt) return json(res, { error: 'assetName + prompt required' }, 400);
    const item = {
      id:         crypto.randomUUID(),
      assetName:  body.assetName,
      prompt:     body.prompt,
      type:       body.type  || 'auto',
      model:      body.model || 'auto',
      refConcept: body.refConcept || null,
      status:     'pending',
      createdAt:  new Date().toISOString(),
      note:       '',
    };
    const q = readQueue();
    q.push(item);
    writeQueue(q);
    sseWrite('queue-updated', item);
    const refTag = item.refConcept ? ` ref=${item.refConcept}` : '';
    console.log(`[queue] NEW  ${item.id.slice(0,8)} ${item.assetName} [${item.model}]${refTag} — "${item.prompt.slice(0,50)}"`);
    return json(res, item, 201);
  }

  // ── POST /api/replace/:assetName (drag-drop direct replace, bypasses queue) ─
  // Used when a designer hands you the FINAL version of an existing asset
  // (UI image, GLB, audio) and you just want to drop it in place. Preserves the
  // original filename — the on-disk asset gets overwritten and SSE refreshes
  // the card. No Layer call, no queue, no CU spent.
  if (method === 'POST' && pname.startsWith('/api/replace/')) {
    const assetName = decodeURIComponent(pname.slice('/api/replace/'.length));
    if (!/^[a-z0-9_.-]+\.(glb|webp|png|jpg|jpeg|mp3|ogg|wav)$/i.test(assetName)) {
      return json(res, { error: 'invalid asset name (allowed: glb, webp/png/jpg, mp3/ogg/wav)' }, 400);
    }
    const body = await parseBody(req);
    if (!body.base64) return json(res, { error: 'base64 required' }, 400);
    const buffer = Buffer.from(body.base64, 'base64');
    const fp = path.join(ASSETS, assetName);
    // Archive the prior version (if any) BEFORE overwriting so the PM can
    // switch back via the history drawer's per-entry restore button.
    const archived = archiveExisting(assetName);
    fs.writeFileSync(fp, buffer);
    watchAsset(assetName);
    sseWrite('asset-updated', { name: assetName, ts: Date.now() });
    console.log(`[replace] ${assetName} (${buffer.length} bytes, direct upload)${archived ? ' — prior archived: ' + archived : ''}`);
    return json(res, { name: assetName, size: buffer.length, replaced: true, archived }, 200);
  }

  // ── POST /api/slot/:slotId/assign ─────────────────────────────────────────
  // Copy an existing asset to fill an empty slot. Body: { source: 'existing.glb' }
  // Server resolves the slot's canonical fill name (slot.fills[0]) and copies
  // assets/<source> → assets/<fillName>. The asset watcher then fires
  // asset-updated which re-renders the studio. The source file stays intact.
  if (method === 'POST' && pname.startsWith('/api/slot/') && pname.endsWith('/assign')) {
    const slotId = decodeURIComponent(pname.slice('/api/slot/'.length, -'/assign'.length));
    const slot = (CONFIG.slots || []).find(s => s.id === slotId);
    if (!slot)                       return json(res, { error: `unknown slot: ${slotId}` }, 404);
    if (!slot.fills || !slot.fills.length) return json(res, { error: `slot ${slotId} has no fills[]` }, 400);
    const body = await parseBody(req);
    const source = body?.source;
    if (!source || !/^[a-z0-9_.-]+\.[a-z0-9]+$/i.test(source)) {
      return json(res, { error: 'invalid source name' }, 400);
    }
    const srcPath = path.join(ASSETS, source);
    if (!fs.existsSync(srcPath)) return json(res, { error: `source not found: ${source}` }, 404);
    const fillName = slot.fills[0];
    const dstPath = path.join(ASSETS, fillName);
    // Archive whatever (if anything) is currently at the fill path — same
    // safety pattern as /api/replace so the PM can roll back.
    const archived = archiveExisting(fillName);
    fs.copyFileSync(srcPath, dstPath);
    watchAsset(fillName);
    sseWrite('asset-updated', { name: fillName, ts: Date.now() });
    console.log(`[slot] assigned ${source} → ${fillName} (slot=${slotId})${archived ? ' — prior archived: ' + archived : ''}`);
    return json(res, { slot: slotId, source, fillName, archived }, 200);
  }

  // ── GET /api/archive/:name ────────────────────────────────────────────────
  // List prior versions of an asset stored in assets/.history/<name>/.
  if (method === 'GET' && pname.startsWith('/api/archive/') && !pname.endsWith('/promote')) {
    // /api/archive/<name>            → list
    // /api/archive/<name>/<file>     → download a specific archived file
    const rest = decodeURIComponent(pname.slice('/api/archive/'.length));
    const parts = rest.split('/');
    const assetName = parts[0];
    if (!/^[a-z0-9_.-]+\.[a-z0-9]+$/i.test(assetName)) return json(res, { error: 'invalid asset name' }, 400);
    if (parts.length === 1) {
      return json(res, { name: assetName, versions: listArchive(assetName) }, 200);
    }
    const file = parts[1];
    if (!/^[a-zA-Z0-9_:.-]+\.[a-z0-9]+$/i.test(file)) return json(res, { error: 'invalid archive file' }, 400);
    const fp = path.join(ARCHIVE_DIR, assetName, file);
    if (!fs.existsSync(fp)) return json(res, { error: 'archive entry not found' }, 404);
    const mime = MIMES[path.extname(file).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'no-store' });
    fs.createReadStream(fp).pipe(res);
    return;
  }

  // ── POST /api/archive/:name/promote ───────────────────────────────────────
  // Restore an archived version as the live asset. Body: { file: '<archiveBasename>' }
  // The current live asset is itself archived first (so promote is reversible)
  // and the source archive entry is then DELETED — the binary content lives
  // on as the new "live" file. This keeps the total snapshot count constant
  // across promotes: each promote is a rotation, not an accumulation. Without
  // delete-source, navigating ◀ would grow the version list indefinitely with
  // duplicates and the Krea-style "N/M" counter would be incoherent.
  if (method === 'POST' && pname.startsWith('/api/archive/') && pname.endsWith('/promote')) {
    const assetName = decodeURIComponent(pname.slice('/api/archive/'.length, -'/promote'.length));
    if (!/^[a-z0-9_.-]+\.[a-z0-9]+$/i.test(assetName)) return json(res, { error: 'invalid asset name' }, 400);
    const body = await parseBody(req);
    const file = body?.file;
    if (!file || !/^[a-zA-Z0-9_:.-]+\.[a-z0-9]+$/i.test(file)) {
      return json(res, { error: 'invalid archive file' }, 400);
    }
    const archivedSrc = path.join(ARCHIVE_DIR, assetName, file);
    if (!fs.existsSync(archivedSrc)) return json(res, { error: 'archive entry not found' }, 404);
    const livePath = path.join(ASSETS, assetName);
    // Snapshot the current live (so promote is reversible) before copying.
    const archived = archiveExisting(assetName);
    fs.copyFileSync(archivedSrc, livePath);
    // Delete the source archive — its content is now the live file. The just-
    // archived prior live takes its place in the version list. Same total count.
    try { fs.unlinkSync(archivedSrc); } catch (e) { console.warn('[archive] unlink failed:', e?.message); }
    watchAsset(assetName);
    sseWrite('asset-updated', { name: assetName, ts: Date.now() });
    console.log(`[archive] promoted ${file} → ${assetName}${archived ? ' (prior archived: ' + archived + ')' : ''}`);
    return json(res, { name: assetName, promoted: file, archived }, 200);
  }

  // ── PUT /api/tune/:assetName ──────────────────────────────────────────────
  // Unified rig tuning JSON: bone offsets + per-prop attachment poses.
  // Lands at assets/<charStem>.tune.json. Game's loadCharacterTune() reads it
  // and applies BOTH boneOffsets AND props each frame.
  if (method === 'PUT' && pname.startsWith('/api/tune/')) {
    const assetName = decodeURIComponent(pname.slice('/api/tune/'.length));
    if (!/^[a-z0-9_.-]+\.glb$/i.test(assetName)) {
      return json(res, { error: 'expected a .glb asset name' }, 400);
    }
    const body = await parseBody(req);
    if (!body || typeof body !== 'object') return json(res, { error: 'JSON body required' }, 400);
    const stem = assetName.replace(/\.glb$/i, '');
    const filename = `${stem}.tune.json`;
    fs.writeFileSync(path.join(ASSETS, filename), JSON.stringify(body, null, 2));
    watchAsset(filename);
    sseWrite('asset-updated', { name: filename, ts: Date.now() });
    const boneCount = Object.keys(body.boneOffsets || {}).length;
    const propCount = Object.keys(body.props || {}).length;
    console.log(`[tune] saved ${filename} (${boneCount} bones, ${propCount} props)`);
    return json(res, { name: filename, boneCount, propCount }, 200);
  }
  if (method === 'GET' && pname.startsWith('/api/tune/')) {
    const assetName = decodeURIComponent(pname.slice('/api/tune/'.length));
    const stem = assetName.replace(/\.glb$/i, '');
    const fp = path.join(ASSETS, `${stem}.tune.json`);
    if (!fs.existsSync(fp)) return json(res, { boneOffsets: {}, props: {} }, 200);
    try { return json(res, JSON.parse(fs.readFileSync(fp, 'utf8')), 200); }
    catch (e) { return json(res, { boneOffsets: {}, props: {}, error: e.message }, 200); }
  }

  // ── PUT /api/bone-offsets/:assetName ──────────────────────────────────────
  // Persists the bone offset overlay JSON for a rigged character GLB. The
  // file lands in assets/<assetStem>.bone-offsets.json so the game's runtime
  // loadBoneOffsets() can fetch it via /assets/<name>. Body: { boneOffsets: {...} }
  if (method === 'PUT' && pname.startsWith('/api/bone-offsets/')) {
    const assetName = decodeURIComponent(pname.slice('/api/bone-offsets/'.length));
    if (!/^[a-z0-9_.-]+\.glb$/i.test(assetName)) {
      return json(res, { error: 'expected a .glb asset name' }, 400);
    }
    const body = await parseBody(req);
    if (!body || typeof body !== 'object') return json(res, { error: 'JSON body required' }, 400);
    const stem = assetName.replace(/\.glb$/i, '');
    const filename = `${stem}.bone-offsets.json`;
    const fp = path.join(ASSETS, filename);
    fs.writeFileSync(fp, JSON.stringify(body, null, 2));
    watchAsset(filename);
    sseWrite('asset-updated', { name: filename, ts: Date.now() });
    console.log(`[bone-offsets] saved ${filename} (${Object.keys(body.boneOffsets || {}).length} bones)`);
    return json(res, { name: filename, count: Object.keys(body.boneOffsets || {}).length }, 200);
  }

  // ── GET /api/bone-offsets/:assetName ──────────────────────────────────────
  // Reads the saved overlay JSON. Returns { boneOffsets: {} } if not yet created.
  if (method === 'GET' && pname.startsWith('/api/bone-offsets/')) {
    const assetName = decodeURIComponent(pname.slice('/api/bone-offsets/'.length));
    const stem = assetName.replace(/\.glb$/i, '');
    const fp = path.join(ASSETS, `${stem}.bone-offsets.json`);
    if (!fs.existsSync(fp)) return json(res, { boneOffsets: {} }, 200);
    try { return json(res, JSON.parse(fs.readFileSync(fp, 'utf8')), 200); }
    catch (e) { return json(res, { boneOffsets: {}, error: e.message }, 200); }
  }

  // ── POST /api/upload (external ref images) ────────────────────────────────
  if (method === 'POST' && pname === '/api/upload') {
    const body = await parseBody(req);
    if (!body.filename || !body.base64) return json(res, { error: 'filename + base64 required' }, 400);

    // Sanitize: lowercase alphanumeric + underscores, keep valid extension
    const orig = path.basename(body.filename);
    let ext    = path.extname(orig).toLowerCase();
    let stem   = orig.slice(0, orig.length - ext.length).toLowerCase()
                     .replace(/[^a-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
    if (!stem) stem = 'upload';
    if (!/^\.(webp|png|jpg|jpeg)$/.test(ext)) ext = '.png';
    if (!stem.startsWith('ref_')) stem = 'ref_' + stem;

    // Avoid clobbering existing files
    let finalName = stem + ext;
    let n = 2;
    while (fs.existsSync(path.join(ASSETS, finalName))) {
      finalName = `${stem}_${n}${ext}`;
      n++;
    }

    const buffer = Buffer.from(body.base64, 'base64');
    fs.writeFileSync(path.join(ASSETS, finalName), buffer);
    watchAsset(finalName);
    sseWrite('asset-updated', { name: finalName, ts: Date.now() });
    console.log(`[upload] ${finalName} (${buffer.length} bytes)`);
    return json(res, { name: finalName, size: buffer.length }, 201);
  }

  // ── PATCH /api/queue/:id ──────────────────────────────────────────────────
  if (method === 'PATCH' && pname.startsWith('/api/queue/')) {
    const id   = pname.split('/')[3];
    const body = await parseBody(req);
    const q    = readQueue();
    const idx  = q.findIndex(r => r.id === id);
    if (idx === -1) return json(res, { error: 'not found' }, 404);
    const prev = q[idx].status;
    Object.assign(q[idx], body, { updatedAt: new Date().toISOString() });
    writeQueue(q);
    sseWrite('queue-updated', q[idx]);
    console.log(`[queue] UPDT ${id.slice(0,8)} → ${q[idx].status}`);

    // Auto-append to history when an item transitions to `done`
    if (q[idx].status === 'done' && prev !== 'done') {
      const entry = {
        id:          q[idx].id,
        assetName:   q[idx].assetName,
        prompt:      q[idx].prompt,
        model:       q[idx].model,
        refConcept:  q[idx].refConcept || null,
        type:        q[idx].type,
        note:        q[idx].note || '',
        createdAt:   q[idx].createdAt,
        completedAt: q[idx].updatedAt,
      };
      appendHistory(entry);
      sseWrite('history-appended', entry);
      console.log(`[history] + ${entry.assetName} via ${entry.model}${entry.refConcept ? ' ref='+entry.refConcept : ''}`);

      // Auto-promote: when a generated asset matches a slot's `fills[0]`, AND
      // that slot is currently using a fallback (proc/vfx), swap it to use
      // the new asset. This makes "Generate to fill" land in-game immediately
      // without the PM needing to manually click the source toggle.
      const ownerSlot = (CONFIG.slots || []).find(s => (s.fills || []).includes(q[idx].assetName));
      if (ownerSlot && ownerSlot.usedInGame && ownerSlot.usedInGame !== 'asset' && ownerSlot.fallback) {
        ownerSlot.usedInGame = 'asset';
        try {
          const existing = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
          if (Array.isArray(existing.slots)) {
            const i = existing.slots.findIndex(s => s.id === ownerSlot.id);
            if (i !== -1) {
              existing.slots[i].usedInGame = 'asset';
              fs.writeFileSync(CONFIG_PATH, JSON.stringify(existing, null, 2));
              console.log(`[slot] ${ownerSlot.id} auto-promoted to usedInGame=asset (filled by ${q[idx].assetName})`);
              sseWrite('slot-updated', { id: ownerSlot.id, usedInGame: 'asset', autoPromoted: true });
            }
          }
        } catch (e) {
          console.error('[slot] auto-promote failed:', e.message);
        }
      }
    }
    return json(res, q[idx]);
  }

  // ── PATCH /api/slot/:id (swap usedInGame between 'asset' / 'proc' / 'vfx') ──
  if (method === 'PATCH' && pname.startsWith('/api/slot/')) {
    const id = decodeURIComponent(pname.slice('/api/slot/'.length));
    const body = await parseBody(req);
    if (!body.usedInGame || !['asset','proc','vfx','fallback','none'].includes(body.usedInGame)) {
      return json(res, { error: 'usedInGame must be asset, proc, vfx, fallback, or none' }, 400);
    }
    // Update in-memory config
    const slot = (CONFIG.slots || []).find(s => s.id === id);
    if (!slot) return json(res, { error: 'slot not found' }, 404);
    slot.usedInGame = body.usedInGame;
    // Persist back to asset-studio.config.json
    try {
      const existing = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
      if (Array.isArray(existing.slots)) {
        const i = existing.slots.findIndex(s => s.id === id);
        if (i !== -1) {
          existing.slots[i].usedInGame = body.usedInGame;
          fs.writeFileSync(CONFIG_PATH, JSON.stringify(existing, null, 2));
        }
      }
    } catch (e) {
      console.error('[slot] failed to persist update:', e.message);
      return json(res, { error: 'persist failed' }, 500);
    }
    console.log(`[slot] ${id} usedInGame=${body.usedInGame}`);
    sseWrite('slot-updated', { id, usedInGame: body.usedInGame });
    return json(res, slot);
  }

  // ── PUT /api/slot/:id/active (pick which variant from fills[] is live) ────
  // Body: { fill: 'mom_stylized_rigged.glb' } — must be a name in slot.fills[].
  // Persists `activeFill` to asset-studio.config.json. The next slot resolution
  // (immediately, since config is hot-reloaded on mtime change) picks this as
  // the live file. Studio re-renders the card with the new variant.
  if (method === 'PUT' && pname.startsWith('/api/slot/') && pname.endsWith('/active')) {
    const id = decodeURIComponent(pname.slice('/api/slot/'.length, -'/active'.length));
    const body = await parseBody(req);
    const fill = body?.fill;
    const slot = (CONFIG.slots || []).find(s => s.id === id);
    if (!slot) return json(res, { error: 'slot not found' }, 404);
    if (!(slot.fills || []).includes(fill)) {
      return json(res, { error: `fill "${fill}" is not in slot.fills[]` }, 400);
    }
    try {
      const existing = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
      const i = (existing.slots || []).findIndex(s => s.id === id);
      if (i === -1) return json(res, { error: 'slot vanished from config' }, 500);
      existing.slots[i].activeFill = fill;
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(existing, null, 2));
    } catch (e) {
      console.error('[slot] failed to persist activeFill:', e.message);
      return json(res, { error: 'persist failed' }, 500);
    }
    console.log(`[slot] ${id} activeFill=${fill}`);
    sseWrite('slot-updated', { id, activeFill: fill });
    return json(res, { id, activeFill: fill });
  }

  // ── GET /api/history (full log; client filters per asset) ────────────────
  if (method === 'GET' && pname === '/api/history') {
    const asset = url.searchParams.get('asset');
    const h = readHistory();
    return json(res, asset ? h.filter(e => e.assetName === asset) : h);
  }

  // ── DELETE /api/queue/:id ─────────────────────────────────────────────────
  if (method === 'DELETE' && pname.startsWith('/api/queue/')) {
    const id = pname.split('/')[3];
    const q  = readQueue().filter(r => r.id !== id);
    writeQueue(q);
    sseWrite('queue-deleted', { id });
    return json(res, { ok: true });
  }

  // ── GET /api/events (SSE) ─────────────────────────────────────────────────
  if (method === 'GET' && pname === '/api/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    });
    res.write('event: connected\ndata: {}\n\n');
    sseClients.add(res);
    // Send current queue state immediately
    sseWrite('queue-snapshot', readQueue());
    req.on('close', () => sseClients.delete(res));
    return; // keep alive
  }

  if (pname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, () => {
  console.log('');
  console.log('  ┌─────────────────────────────────────────────────┐');
  console.log(`  │  🎮  ${CONFIG.title} — ${CONFIG.subtitle}`.padEnd(51) + '│');
  console.log(`  │  http://localhost:${PORT}`.padEnd(51) + '│');
  console.log(`  │  project:  ${path.basename(PROJECT_ROOT)}`.padEnd(51) + '│');
  console.log(`  │  assets:   ${path.relative(PROJECT_ROOT, ASSETS) || './'}`.padEnd(51) + '│');
  console.log(`  │  config:   ${fs.existsSync(CONFIG_PATH) ? path.relative(PROJECT_ROOT, CONFIG_PATH) : '(defaults)'}`.padEnd(51) + '│');
  console.log('  │                                                 │');
  console.log(`  │  Sections: ${CONFIG.categories.length} GLB · ${CONFIG.procRigs.length} proc · ${CONFIG.vfx.length} VFX`.padEnd(51) + '│');
  console.log('  │                                                 │');
  console.log('  │  Workflow:                                      │');
  console.log('  │  1. Write a prompt in any asset card            │');
  console.log('  │  2. Click ⚙️ Generate                           │');
  console.log('  │  3. Tell Claude "check queue" in chat           │');
  console.log('  │  4. New asset auto-refreshes in the viewer      │');
  console.log('  └─────────────────────────────────────────────────┘');
  console.log('');
  // Drift lint runs once at startup — surfaces config/game mismatches early.
  try { lintSlotDrift(getConfig()); } catch (e) { console.warn('[lint] failed:', e?.message); }

  // Auto-open the browser unless --no-browser was passed (CI / tests)
  if (!process.argv.includes('--no-browser')) {
    const url = `http://localhost:${PORT}`;
    const cmd = process.platform === 'win32' ? `start "" "${url}"`
              : process.platform === 'darwin' ? `open "${url}"`
              : `xdg-open "${url}"`;
    exec(cmd, err => { if (err) console.warn('[browser] could not auto-open:', err.message); });
    console.log(`[browser] opening ${url}`);
    console.log('');
  }
});

// ── Graceful shutdown ─────────────────────────────────────────────────────────
process.on('SIGINT', () => {
  console.log('\n[server] shutting down');
  for (const [, w] of watchers) try { w.close(); } catch {}
  server.close(() => process.exit(0));
});

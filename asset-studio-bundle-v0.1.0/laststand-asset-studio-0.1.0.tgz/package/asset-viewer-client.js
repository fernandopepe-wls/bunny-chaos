// asset-viewer-client.js — Three.js code for the asset viewer page
// Loaded as <script type="module"> by asset-viewer.html
// Asset data (base64 GLBs, images, audio) is read from #asset-data JSON tag.

import * as THREE from 'three';
import { GLTFLoader }    from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ── Data ─────────────────────────────────────────────────────────────────────
const data = JSON.parse(document.getElementById('asset-data').textContent);

// ── Utilities ─────────────────────────────────────────────────────────────────
function b64ToArrayBuffer(b64) {
  const bin = atob(b64);
  const buf = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
  return buf.buffer;
}

function analyzeScene(scene, animations) {
  let tris = 0, meshes = 0, hasSkin = false;
  scene.traverse(o => {
    if (o.isMesh) {
      meshes++;
      const g = o.geometry;
      tris += g.index ? g.index.count / 3 : g.attributes.position.count / 3;
      if (o.isSkinnedMesh) hasSkin = true;
    }
  });
  return { tris: Math.round(tris), meshes, hasSkin, anims: animations?.length || 0 };
}

function makeLights(scene) {
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const sun = new THREE.DirectionalLight(0xfff5e0, 1.6);
  sun.position.set(3, 5, 4); scene.add(sun);
  const fill = new THREE.DirectionalLight(0x6080ff, 0.4);
  fill.position.set(-2, 2, -3); scene.add(fill);
}

function makeRenderer(canvas) {
  const r = new THREE.WebGLRenderer({ canvas, antialias: true });
  r.setSize(canvas.clientWidth || 230, canvas.clientHeight || 200, false);
  r.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  r.outputColorSpace = THREE.SRGBColorSpace;
  return r;
}

function makeBaseScene() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0d1520);
  makeLights(scene);
  scene.add(new THREE.GridHelper(6, 10, 0x1a2a3a, 0x1a2a3a));
  return scene;
}

function fitCamera(camera, controls, box) {
  const size   = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z);
  const dist   = ((maxDim / 2) / Math.tan(camera.fov * Math.PI / 360)) * 1.7;
  camera.position.set(center.x + dist * 0.6, center.y + size.y * 0.3 + dist * 0.4, center.z + dist);
  controls.target.copy(center);
  controls.update();
}

// ── Spinner → canvas swap ────────────────────────────────────────────────────
function swapSpinner(container) {
  const spinner = container.querySelector('.spinner');
  const canvas  = document.createElement('canvas');
  canvas.style.cssText = 'width:100%;height:200px;display:block;cursor:grab;';
  container.replaceChild(canvas, spinner);
  return canvas;
}

// ── GLB Card ──────────────────────────────────────────────────────────────────
async function makeGLBCard(container, asset) {
  const canvas   = swapSpinner(container);
  const renderer = makeRenderer(canvas);
  const scene    = makeBaseScene();
  const camera   = new THREE.PerspectiveCamera(42, (canvas.clientWidth || 230) / 200, 0.01, 200);
  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping  = true;
  controls.autoRotate     = true;
  controls.autoRotateSpeed = 1.8;
  controls.dampingFactor  = 0.08;

  try {
    const buf    = b64ToArrayBuffer(asset.b64);
    const blob   = new Blob([buf], { type: 'model/gltf-binary' });
    const url    = URL.createObjectURL(blob);
    const loader = new GLTFLoader();
    const gltf   = await new Promise((res, rej) => loader.load(url, res, null, rej));
    URL.revokeObjectURL(url);

    // Normalize: center + sit on ground
    const box1   = new THREE.Box3().setFromObject(gltf.scene);
    const center = box1.getCenter(new THREE.Vector3());
    const size   = box1.getSize(new THREE.Vector3());
    const scale  = 2 / Math.max(size.x, size.y, size.z);
    gltf.scene.scale.setScalar(scale);
    gltf.scene.position.copy(center).negate().multiplyScalar(scale);
    const box2   = new THREE.Box3().setFromObject(gltf.scene);
    gltf.scene.position.y -= box2.min.y;
    scene.add(gltf.scene);
    fitCamera(camera, controls, new THREE.Box3().setFromObject(gltf.scene));

    const { tris, meshes, hasSkin, anims } = analyzeScene(gltf.scene, gltf.animations);
    const statsEl = container.querySelector('.stats');
    statsEl.innerHTML =
      `<span>📐 ${tris.toLocaleString()} tri</span>` +
      `<span>🧱 ${meshes} mesh</span>` +
      `<span class="${anims > 0 ? 'has-anim' : 'no-anim'}">${anims > 0 ? '✦ ' + anims + ' anim' : '✗ no anim'}</span>` +
      (hasSkin ? '<span class="has-rig">🦴 rigged</span>' : '');
  } catch (err) {
    canvas.parentNode.innerHTML =
      `<div style="height:200px;display:flex;align-items:center;justify-content:center;color:#f87171;font-size:12px;padding:12px;text-align:center;">Failed to load<br>${asset.name}</div>`;
    return;
  }

  let live = true;
  (function animate() {
    if (!live) return;
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  })();

  new IntersectionObserver(entries => {
    live = entries[0].isIntersecting;
    if (live) (function animate() { if (!live) return; requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); })();
  }, { threshold: 0.1 }).observe(canvas);
}

// ── Procedural Mom ────────────────────────────────────────────────────────────
function makeProcMomCard(container) {
  const canvas   = swapSpinner(container);
  const renderer = makeRenderer(canvas);
  const scene    = makeBaseScene();
  const camera   = new THREE.PerspectiveCamera(42, (canvas.clientWidth || 230) / 200, 0.01, 50);
  camera.position.set(0, 2.2, 5);
  const controls = new OrbitControls(camera, canvas);
  controls.target.set(0, 1, 0);
  controls.enableDamping  = true;
  controls.dampingFactor  = 0.08;
  controls.update();

  const M = {
    skin:   new THREE.MeshLambertMaterial({ color: 0xf0c69a }),
    hair:   new THREE.MeshLambertMaterial({ color: 0x6b4a2e }),
    shirt:  new THREE.MeshLambertMaterial({ color: 0xc94a55 }),
    sleeve: new THREE.MeshLambertMaterial({ color: 0xa83a45 }),
    pants:  new THREE.MeshLambertMaterial({ color: 0x3a4a72 }),
    boot:   new THREE.MeshLambertMaterial({ color: 0x2a1a10 }),
    eye:    new THREE.MeshBasicMaterial ({ color: 0x1a1a1a }),
    pack:   new THREE.MeshLambertMaterial({ color: 0x6b4a2e }),
  };
  const CYL = (rt,rb,h,s) => new THREE.CylinderGeometry(rt,rb,h,s);
  const BOX = (x,y,z)     => new THREE.BoxGeometry(x,y,z);
  const SPH = (r,ws,hs)   => new THREE.SphereGeometry(r,ws,hs);
  const mesh = (geo, mat, px=0, py=0, pz=0) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(px, py, pz); return m;
  };

  const root = new THREE.Group();

  // Legs
  const makeLeg = x => {
    const hip = new THREE.Group(); hip.position.set(x, 0.85, 0);
    hip.add(mesh(CYL(.13,.12,.5,10), M.pants, 0,-.25,0));
    hip.add(mesh(CYL(.10,.10,.45,10), M.pants, 0,-.70,0));
    hip.add(mesh(BOX(.25,.18,.32), M.boot, 0,-.93,.04));
    return hip;
  };
  const leftLeg  = makeLeg(-.13);
  const rightLeg = makeLeg( .13);
  root.add(leftLeg, rightLeg);

  // Torso
  const torso = new THREE.Group(); torso.position.set(0,.85,0);
  torso.add(mesh(CYL(.32,.30,.7,12), M.shirt, 0,.35,0));
  torso.add(mesh(CYL(.31,.31,.06,12), M.boot, 0,.04,0));
  torso.add(mesh(BOX(.46,.42,.18), M.pack, 0,.55,-.32));
  root.add(torso);

  // Head
  const head = new THREE.Group(); head.position.set(0,1.10,0);
  head.add(mesh(SPH(.22,16,14), M.skin));
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(.235,14,10,0,Math.PI*2,0,Math.PI/1.6), M.hair);
  hairCap.position.y = .04; head.add(hairCap);
  const pony = mesh(SPH(.13,10,8), M.hair, 0,-.05,-.22);
  pony.scale.set(1,1.4,.7); head.add(pony);
  head.add(mesh(SPH(.025,6,5), M.eye, -.08,.02,.20));
  head.add(mesh(SPH(.025,6,5), M.eye,  .08,.02,.20));
  torso.add(head);

  // Arms
  const makeArm = (x, right) => {
    const sh = new THREE.Group(); sh.position.set(x,.62,0);
    sh.add(mesh(CYL(.085,.075,.36,10), M.sleeve, 0,-.18,0));
    const elbow = new THREE.Group(); elbow.position.y = -.36;
    elbow.add(mesh(CYL(.07,.06,.32,10), M.skin, 0,-.16,0));
    const hand = new THREE.Group(); hand.position.y = -.32;
    const hm = mesh(SPH(.085,10,8), M.skin); hm.scale.set(1,.7,1); hand.add(hm);
    elbow.add(hand); sh.add(elbow);
    sh.rotation.x = -.05; sh.rotation.z = right ? -.04 : .04;
    return { sh, hand };
  };
  const LA = makeArm(-.34, false);
  const RA = makeArm( .34, true);
  torso.add(LA.sh, RA.sh);
  scene.add(root);

  // Stats
  container.querySelector('.stats').innerHTML =
    '<span>🦴 7 bones</span><span class="has-anim">✦ walk · idle · carry · rifle</span>';

  // Pose label badge
  const badge = document.createElement('div');
  badge.style.cssText = 'position:absolute;top:8px;right:8px;font-size:10px;font-weight:700;' +
    'letter-spacing:1px;color:var(--accent);background:rgba(0,0,0,.55);padding:2px 7px;border-radius:10px;pointer-events:none;';
  container.style.position = 'relative';
  container.insertBefore(badge, container.firstChild);

  const POSES = ['WALK', 'IDLE', 'CARRY', 'RIFLE'];
  let poseIdx = 0, poseTime = 0;
  const PDUR = 4.5;
  const RAD  = d => d * Math.PI / 180;
  const lerp = (a, b, k) => a + (b - a) * k;

  let t = 0;
  function animate() {
    requestAnimationFrame(animate);
    const dt = 1 / 60;
    t += dt; poseTime += dt;
    if (poseTime > PDUR) { poseTime = 0; poseIdx = (poseIdx + 1) % POSES.length; }
    badge.textContent = POSES[poseIdx];
    const pose = POSES[poseIdx];

    if (pose === 'WALK') {
      const p = t * 9;
      leftLeg.rotation.x  =  Math.sin(p) * RAD(36);
      rightLeg.rotation.x = -Math.sin(p) * RAD(36);
      LA.sh.rotation.x    = -Math.sin(p) * RAD(24) - .05;
      RA.sh.rotation.x    =  Math.sin(p) * RAD(24) - .05;
      torso.rotation.z    =  Math.sin(p) * RAD(5);
      torso.rotation.x    = lerp(torso.rotation.x, 0, .15);
      root.position.y     =  Math.abs(Math.sin(p)) * 0.07;
      head.rotation.z     = -Math.sin(p) * RAD(4);
      LA.sh.rotation.z    = lerp(LA.sh.rotation.z, .04, .1);
      RA.sh.rotation.z    = lerp(RA.sh.rotation.z, -.04, .1);
    } else if (pose === 'IDLE') {
      const breath = Math.sin(t * 1.8);
      torso.scale.y        = 1 + breath * 0.02;
      root.position.y      = 0;
      torso.rotation.z     = Math.sin(t * 0.7) * RAD(2);
      head.rotation.z      = Math.sin(t * 0.5) * RAD(3);
      head.rotation.y      = Math.sin(t * 0.4) * RAD(5);
      leftLeg.rotation.x   = lerp(leftLeg.rotation.x,  0, .1);
      rightLeg.rotation.x  = lerp(rightLeg.rotation.x, 0, .1);
      LA.sh.rotation.x     = lerp(LA.sh.rotation.x, -.05, .08);
      RA.sh.rotation.x     = lerp(RA.sh.rotation.x, -.05, .08);
      LA.sh.rotation.z     = lerp(LA.sh.rotation.z,  .04 + breath*.02, .06);
      RA.sh.rotation.z     = lerp(RA.sh.rotation.z, -.04 - breath*.02, .06);
    } else if (pose === 'CARRY') {
      const p = t * 8;
      leftLeg.rotation.x  =  Math.sin(p) * RAD(28);
      rightLeg.rotation.x = -Math.sin(p) * RAD(28);
      root.position.y     =  Math.abs(Math.sin(p)) * 0.06;
      LA.sh.rotation.x    = lerp(LA.sh.rotation.x, RAD(28), .12);
      RA.sh.rotation.x    = lerp(RA.sh.rotation.x, RAD(28), .12);
      LA.sh.rotation.z    = lerp(LA.sh.rotation.z, RAD(18), .1);
      RA.sh.rotation.z    = lerp(RA.sh.rotation.z, RAD(-18), .1);
      torso.rotation.x    = lerp(torso.rotation.x, RAD(9), .1);
      torso.rotation.z    = lerp(torso.rotation.z, 0, .1);
      head.rotation.z     = lerp(head.rotation.z, 0, .1);
    } else if (pose === 'RIFLE') {
      root.position.y      = 0;
      leftLeg.rotation.x   = lerp(leftLeg.rotation.x,  0, .1);
      rightLeg.rotation.x  = lerp(rightLeg.rotation.x, 0, .1);
      RA.sh.rotation.x     = lerp(RA.sh.rotation.x, RAD(-72), .15);
      RA.sh.rotation.z     = lerp(RA.sh.rotation.z, 0, .1);
      LA.sh.rotation.x     = lerp(LA.sh.rotation.x, RAD(-58), .15);
      LA.sh.rotation.z     = lerp(LA.sh.rotation.z, 0, .1);
      torso.rotation.x     = lerp(torso.rotation.x, RAD(-6), .1);
      torso.rotation.z     = lerp(torso.rotation.z, 0, .1);
      // Recoil flash every ~0.9s
      const shootT = (t % 0.9) / 0.9;
      if (shootT < 0.07) {
        RA.sh.rotation.x -= 0.25 * (1 - shootT / 0.07);
      }
    }

    controls.update();
    renderer.render(scene, camera);
  }
  animate();
}

// ── VFX Cards ─────────────────────────────────────────────────────────────────
function makeVFXCard(container, vfxType) {
  const canvas   = swapSpinner(container);
  const renderer = makeRenderer(canvas);
  const scene    = new THREE.Scene();
  scene.background = new THREE.Color(0x0d1520);
  makeLights(scene);

  const camera = new THREE.PerspectiveCamera(50, (canvas.clientWidth || 230) / 200, 0.01, 50);
  camera.position.set(0, 3, 5);
  camera.lookAt(0, 0.5, 0);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(6, 6),
    new THREE.MeshLambertMaterial({ color: 0x0a1525 })
  );
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  let statsText = '';

  if (vfxType === 'chips') {
    const POOL = 14;
    const pool = [];
    const geo  = new THREE.SphereGeometry(0.07, 5, 4);
    const mat  = new THREE.MeshLambertMaterial({ color: 0xc8a47a });
    for (let i = 0; i < POOL; i++) {
      const m = new THREE.Mesh(geo, mat.clone()); m.visible = false; scene.add(m);
      pool.push({ mesh: m, vx:0, vy:0, vz:0, life:0, maxLife:1 });
    }
    let timer = 0;
    scene.userData.update = dt => {
      timer -= dt;
      if (timer <= 0) {
        timer = 1.2;
        for (const p of pool) {
          const a = Math.random() * Math.PI * 2;
          const sp = 2 + Math.random() * 2;
          p.mesh.position.set(0, 0.3, 0); p.mesh.visible = true;
          p.vx = Math.cos(a)*sp*.8; p.vy = 2+Math.random()*2; p.vz = Math.sin(a)*sp*.8;
          p.life = 0; p.maxLife = .4 + Math.random()*.3;
        }
      }
      for (const p of pool) {
        if (!p.mesh.visible) continue;
        p.life += dt; p.vy -= 9.8*dt;
        p.mesh.position.x += p.vx*dt;
        p.mesh.position.y += p.vy*dt;
        p.mesh.position.z += p.vz*dt;
        p.mesh.scale.setScalar(Math.max(.001, 1 - p.life/p.maxLife));
        if (p.life >= p.maxLife) p.mesh.visible = false;
      }
    };
    statsText = `🪵 ${POOL} particles · loop 1.2s`;

  } else if (vfxType === 'blood') {
    const POOL = 18;
    const pool = [];
    const geo  = new THREE.SphereGeometry(.065, 5, 4);
    const mat  = new THREE.MeshLambertMaterial({ color: 0xcc2233 });
    for (let i = 0; i < POOL; i++) {
      const m = new THREE.Mesh(geo, mat.clone()); m.visible = false; scene.add(m);
      pool.push({ mesh: m, vx:0, vy:0, vz:0, life:0, maxLife:1 });
    }
    let timer = 0;
    scene.userData.update = dt => {
      timer -= dt;
      if (timer <= 0) {
        timer = 1.0;
        for (const p of pool) {
          const a = Math.random() * Math.PI * 2;
          const sp = 1.5 + Math.random() * 2.5;
          p.mesh.position.set(0, 0.8, 0); p.mesh.visible = true;
          p.vx = Math.cos(a)*sp*.9; p.vy = 1+Math.random()*3; p.vz = Math.sin(a)*sp*.9;
          p.life = 0; p.maxLife = .35 + Math.random()*.25;
        }
      }
      for (const p of pool) {
        if (!p.mesh.visible) continue;
        p.life += dt; p.vy -= 9.8*dt;
        p.mesh.position.x += p.vx*dt;
        p.mesh.position.y = Math.max(0, p.mesh.position.y + p.vy*dt);
        p.mesh.position.z += p.vz*dt;
        p.mesh.scale.setScalar(Math.max(.001, 1 - p.life/p.maxLife));
        if (p.life >= p.maxLife) p.mesh.visible = false;
      }
    };
    statsText = '🩸 18 particles · loop 1.0s';

  } else if (vfxType === 'sparkle') {
    const POOL = 20;
    const pool = [];
    const geo  = new THREE.SphereGeometry(.06, 5, 4);
    const mat  = new THREE.MeshBasicMaterial({ color: 0xffd700 });
    for (let i = 0; i < POOL; i++) {
      const m = new THREE.Mesh(geo, mat.clone()); m.visible = false; scene.add(m);
      pool.push({ mesh: m, vx:0, vy:0, vz:0, life:0, maxLife:1 });
    }
    let timer = 0;
    scene.userData.update = dt => {
      timer -= dt;
      if (timer <= 0) {
        timer = 0.85;
        for (const p of pool) {
          const a = Math.random() * Math.PI * 2;
          const sp = .8 + Math.random() * 1.5;
          p.mesh.position.set(0, .1, 0); p.mesh.visible = true;
          p.vx = Math.cos(a)*sp*.5; p.vy = 1.5+Math.random()*2; p.vz = Math.sin(a)*sp*.5;
          p.life = 0; p.maxLife = .5 + Math.random()*.35;
        }
      }
      for (const p of pool) {
        if (!p.mesh.visible) continue;
        p.life += dt; p.vy -= 2*dt;
        p.mesh.position.x += p.vx*dt;
        p.mesh.position.y += p.vy*dt;
        p.mesh.position.z += p.vz*dt;
        p.mesh.scale.setScalar(Math.max(.001, 1 - p.life/p.maxLife));
        if (p.life >= p.maxLife) p.mesh.visible = false;
      }
    };
    statsText = '✨ 20 particles · loop 0.85s';

  } else if (vfxType === 'fire') {
    const fireGroup = new THREE.Group();
    scene.add(fireGroup);
    const layers = [
      { r:.38, color:0xff7700, y:0.0, speed:2.3, amp:.08 },
      { r:.28, color:0xff4400, y:0.2, speed:3.1, amp:.06 },
      { r:.18, color:0xffcc00, y:0.4, speed:4.2, amp:.04 },
    ];
    const layerMeshes = layers.map(l => {
      const m = new THREE.Mesh(
        new THREE.SphereGeometry(l.r, 12, 10),
        new THREE.MeshBasicMaterial({ color: l.color, transparent: true, opacity: .85 })
      );
      m.position.y = l.y; m.scale.set(1, 1.4, 1); fireGroup.add(m);
      return Object.assign(m, l);
    });
    // Embers
    const embPool = [];
    const embGeo = new THREE.SphereGeometry(.035, 4, 3);
    for (let i = 0; i < 14; i++) {
      const m = new THREE.Mesh(embGeo, new THREE.MeshBasicMaterial({ color: 0xffaa00 }));
      m.visible = false; scene.add(m);
      embPool.push({ mesh: m, life:0, maxLife:1, vx:0, vy:0, vz:0 });
    }
    let t = 0, eTimer = 0;
    scene.userData.update = dt => {
      t += dt; eTimer -= dt;
      for (const l of layerMeshes) {
        const f = 1 + Math.sin(t * l.speed + l.y * 10) * l.amp;
        l.scale.x = f; l.scale.z = f * .85;
        l.scale.y = 1.4 + Math.sin(t * l.speed * .7) * .12;
        l.material.opacity = .75 + Math.sin(t * l.speed * 1.3) * .12;
      }
      if (eTimer <= 0) {
        eTimer = .08 + Math.random() * .1;
        const e = embPool.find(e => !e.mesh.visible);
        if (e) {
          e.mesh.visible = true;
          e.mesh.position.set((Math.random()-.5)*.3, .3, (Math.random()-.5)*.3);
          e.vx = (Math.random()-.5)*.5; e.vy = 1+Math.random()*1.5; e.vz = (Math.random()-.5)*.5;
          e.life = 0; e.maxLife = .4 + Math.random()*.5;
        }
      }
      for (const e of embPool) {
        if (!e.mesh.visible) continue;
        e.life += dt; e.vx *= .95; e.vz *= .95;
        e.mesh.position.x += e.vx*dt;
        e.mesh.position.y += e.vy*dt;
        e.mesh.position.z += e.vz*dt;
        e.mesh.scale.setScalar(Math.max(.001, 1 - e.life/e.maxLife));
        if (e.life >= e.maxLife) e.mesh.visible = false;
      }
    };
    statsText = '🔥 3 flame layers + 14 embers · live';
  }

  container.querySelector('.stats').textContent = statsText;

  let last = performance.now();
  (function animate(now) {
    requestAnimationFrame(animate);
    const dt = Math.min((now - last) / 1000, .05); last = now;
    if (scene.userData.update) scene.userData.update(dt);
    renderer.render(scene, camera);
  })(performance.now());
}

// ── Image Cards ───────────────────────────────────────────────────────────────
function makeImageCard(parent, asset) {
  const card = document.createElement('div');
  card.className = 'card-img';
  const img = document.createElement('img');
  img.src = `data:${asset.mime};base64,${asset.b64}`;
  img.alt = asset.name;
  const info = document.createElement('div');
  info.className = 'info';
  info.innerHTML = `<div class="cname">${asset.name}</div><div class="stats">${asset.size}</div>`;
  card.appendChild(img); card.appendChild(info);
  parent.appendChild(card);
}

// ── Audio Rows ────────────────────────────────────────────────────────────────
let currentAudio = null;
function makeAudioRow(parent, asset) {
  const row   = document.createElement('div'); row.className = 'audio-row';
  const btn   = document.createElement('button'); btn.className = 'play-btn'; btn.innerHTML = '▶';
  const name  = document.createElement('div'); name.className = 'aname'; name.textContent = asset.name;
  const size  = document.createElement('div'); size.className = 'asize'; size.textContent = asset.size;
  const audio = document.createElement('audio');
  audio.src   = `data:${asset.mime};base64,${asset.b64}`;
  audio.addEventListener('ended', () => { btn.innerHTML = '▶'; btn.classList.remove('playing'); });
  btn.addEventListener('click', () => {
    if (currentAudio && currentAudio !== audio) {
      currentAudio.pause(); currentAudio.currentTime = 0;
      document.querySelectorAll('.play-btn.playing').forEach(b => { b.innerHTML = '▶'; b.classList.remove('playing'); });
    }
    if (audio.paused) { audio.play(); btn.innerHTML = '⏸'; btn.classList.add('playing'); currentAudio = audio; }
    else              { audio.pause(); btn.innerHTML = '▶'; btn.classList.remove('playing'); currentAudio = null; }
  });
  row.append(btn, name, size, audio);
  parent.appendChild(row);
}

// ── Card factory ──────────────────────────────────────────────────────────────
function makeCard3D(parent, name, size, badgeClass, badgeLabel) {
  const card = document.createElement('div');
  card.className = 'card3d';
  card.innerHTML =
    `<div class="spinner"><div><div class="ring"></div>` +
    `<div style="font-size:11px;color:#8899aa;margin-top:4px;">${name}</div></div></div>` +
    `<div class="info">` +
      `<div class="cname" title="${name}">${name}</div>` +
      `<div class="stats"></div>` +
      `<div style="margin-top:4px;display:flex;gap:6px;align-items:center;">` +
        `<span class="badge ${badgeClass}">${badgeLabel}</span>` +
        `<span style="font-size:11px;color:var(--muted);">${size}</span>` +
      `</div>` +
    `</div>`;
  parent.appendChild(card);
  return card;
}

// ── Assemble page ─────────────────────────────────────────────────────────────
const grids = {
  chars: document.getElementById('grid-chars'),
  props: document.getElementById('grid-props'),
  proc:  document.getElementById('grid-proc'),
  vfx:   document.getElementById('grid-vfx'),
  img:   document.getElementById('grid-img'),
  aud:   document.getElementById('audio-list'),
};

for (const a of data.characters) {
  makeGLBCard(makeCard3D(grids.chars, a.name, a.size, 'badge-glb', 'GLB'), a);
}
for (const a of data.props) {
  makeGLBCard(makeCard3D(grids.props, a.name, a.size, 'badge-glb', 'GLB'), a);
}

// Procedural rig
makeProcMomCard(makeCard3D(grids.proc, 'mom_procedural_rig', 'built-in', 'badge-proc', 'PROC'));

// VFX
const VFX_DEFS = [
  { id: 'chips',   label: '🪵 Wood Chip Burst' },
  { id: 'blood',   label: '🩸 Blood Splatter'  },
  { id: 'sparkle', label: '✨ Item Sparkle'     },
  { id: 'fire',    label: '🔥 Fireplace Flame'  },
];
for (const v of VFX_DEFS) {
  makeVFXCard(makeCard3D(grids.vfx, v.label, 'procedural', 'badge-vfx', 'VFX'), v.id);
}

for (const a of data.images) makeImageCard(grids.img, a);
for (const a of data.audios) makeAudioRow(grids.aud, a);

// Summary line
document.getElementById('meta-line').textContent =
  `${data.characters.length + data.props.length} GLB models · 1 procedural rig · 4 VFX · ` +
  `${data.images.length} UI images · ${data.audios.length} audio clips`;

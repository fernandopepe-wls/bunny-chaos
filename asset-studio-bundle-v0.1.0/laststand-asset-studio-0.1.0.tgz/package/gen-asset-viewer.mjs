#!/usr/bin/env node
/**
 * gen-asset-viewer.mjs
 * Generates asset-viewer.html — a self-contained Three.js gallery showing
 * every asset in Last Stand: GLB models, procedural rig, VFX, UI images, audio.
 *
 * Usage:  node tools/gen-asset-viewer.mjs
 * Output: asset-viewer.html  (open directly in browser — no server needed)
 */

import { readFileSync, writeFileSync, readdirSync, statSync } from 'fs';
import { join, extname } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __dir  = dirname(fileURLToPath(import.meta.url));
const ASSETS = join(__dir, '..', 'assets');
const OUT    = join(__dir, '..', 'asset-viewer.html');

const MIME = {
  '.glb': 'model/gltf-binary',
  '.webp':'image/webp', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg',
  '.mp3':'audio/mpeg', '.ogg':'audio/ogg', '.wav':'audio/wav',
};
const fmt = n =>
  n < 1024     ? `${n} B`
  : n < 1048576  ? `${(n/1024).toFixed(1)} KB`
  : `${(n/1048576).toFixed(2)} MB`;

// ── Collect assets ────────────────────────────────────────────────────────────
const all = {};
for (const f of readdirSync(ASSETS).sort()) {
  const ext = extname(f).toLowerCase();
  if (!MIME[ext]) continue;
  const bytes = statSync(join(ASSETS, f)).size;
  const b64   = readFileSync(join(ASSETS, f)).toString('base64');
  all[f] = { name: f, ext, b64, bytes, size: fmt(bytes), mime: MIME[ext] };
}

const pick = names => names.filter(n => all[n]).map(n => all[n]);
const characters = pick(['mom.glb','zombie.glb','daughter_lying.glb','daughter_sitting.glb']);
const props      = pick(['rifle.glb','car.glb','tent.glb']);
const images     = Object.values(all).filter(a => ['.webp','.png','.jpg','.jpeg'].includes(a.ext));
const audios     = Object.values(all).filter(a => ['.mp3','.ogg','.wav'].includes(a.ext));

// ── Embed data ────────────────────────────────────────────────────────────────
const assetData = JSON.stringify({
  characters: characters.map(({ name, b64, size, bytes }) => ({ name, b64, size, bytes })),
  props:      props.map(({ name, b64, size, bytes })      => ({ name, b64, size, bytes })),
  images:     images.map(({ name, b64, size, mime })      => ({ name, b64, size, mime })),
  audios:     audios.map(({ name, b64, size, mime })      => ({ name, b64, size, mime })),
});

// ── Read client JS ─────────────────────────────────────────────────────────────
const clientJS = readFileSync(join(__dir, 'asset-viewer-client.js'), 'utf8');

// ── CSS ───────────────────────────────────────────────────────────────────────
const CSS = `
*{margin:0;padding:0;box-sizing:border-box;}
:root{
  --bg:#080d18;--surface:#111827;--surface2:#1a2436;
  --border:rgba(255,255,255,0.08);--accent:#ffd97a;
  --text:#e8ecf4;--muted:#8899aa;
}
html,body{background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,sans-serif;min-height:100%;}
body{padding:24px 20px 60px;}

header{max-width:1300px;margin:0 auto 32px;border-bottom:1px solid var(--border);padding-bottom:18px;}
header h1{font-size:22px;font-weight:700;letter-spacing:.5px;color:var(--accent);}
header h1 span{color:var(--text);}
header .meta{margin-top:6px;font-size:13px;color:var(--muted);}

.section{max-width:1300px;margin:0 auto 40px;}
.section-title{font-size:13px;font-weight:700;letter-spacing:2px;text-transform:uppercase;
  color:var(--muted);margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.section-title::after{content:"";flex:1;height:1px;background:var(--border);}

.grid3d{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px;}
.card3d{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden;display:flex;flex-direction:column;}
.card3d canvas{width:100%;height:200px;display:block;cursor:grab;}
.card3d canvas:active{cursor:grabbing;}
.card3d .info{padding:10px 12px;display:flex;flex-direction:column;gap:4px;}
.card3d .cname{font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.card3d .stats{font-size:11px;color:var(--muted);display:flex;gap:8px;flex-wrap:wrap;min-height:16px;}
.badge{font-size:9px;font-weight:700;letter-spacing:1px;padding:2px 6px;border-radius:20px;text-transform:uppercase;}
.badge-glb {background:rgba(59,130,246,.18);color:#60a5fa;border:1px solid rgba(59,130,246,.25);}
.badge-proc{background:rgba(168,85,247,.18);color:#c084fc;border:1px solid rgba(168,85,247,.25);}
.badge-vfx {background:rgba(234,179,8,.18);color:#facc15;border:1px solid rgba(234,179,8,.25);}
.card3d .spinner{height:200px;display:flex;align-items:center;justify-content:center;background:var(--surface2);text-align:center;}
.card3d .spinner .ring{width:28px;height:28px;border:3px solid rgba(255,255,255,.1);border-top-color:var(--accent);border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 8px;}
.no-anim{color:#f87171;}.has-anim{color:#4ade80;}.has-rig{color:#818cf8;}
@keyframes spin{to{transform:rotate(360deg);}}

.grid-img{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:14px;}
.card-img{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden;}
.card-img img{width:100%;display:block;object-fit:contain;background:rgba(0,0,0,.35);min-height:120px;max-height:180px;}
.card-img .info{padding:8px 10px;font-size:11px;}
.card-img .cname{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.card-img .stats{color:var(--muted);margin-top:2px;}

.audio-list{display:flex;flex-direction:column;gap:8px;}
.audio-row{background:var(--surface);border:1px solid var(--border);border-radius:10px;padding:10px 14px;display:flex;align-items:center;gap:14px;}
.play-btn{width:32px;height:32px;border-radius:50%;border:none;cursor:pointer;background:var(--accent);color:#1a1000;font-size:14px;display:flex;align-items:center;justify-content:center;flex:0 0 auto;transition:transform .1s;}
.play-btn:hover{transform:scale(1.1);}.play-btn.playing{background:#4ade80;}
.aname{font-size:13px;font-weight:600;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;}
.asize{font-size:11px;color:var(--muted);}

.note{background:rgba(255,217,122,.07);border:1px solid rgba(255,217,122,.18);border-radius:8px;
  padding:10px 14px;font-size:12px;color:#ffd97a;margin-bottom:14px;max-width:800px;line-height:1.5;}
`;

// ── HTML ──────────────────────────────────────────────────────────────────────
const html = [
  '<!DOCTYPE html>',
  '<html lang="en">',
  '<head>',
  '<meta charset="UTF-8">',
  '<meta name="viewport" content="width=device-width,initial-scale=1">',
  '<title>Last Stand — Asset Viewer</title>',
  `<style>${CSS}</style>`,
  '</head>',
  '<body>',

  '<header>',
  '  <h1>🎮 Last Stand — <span>Asset Viewer</span></h1>',
  '  <div class="meta" id="meta-line">Loading…</div>',
  '</header>',

  '<div class="section">',
  '  <div class="section-title">🧑 Characters</div>',
  '  <div class="grid3d" id="grid-chars"></div>',
  '</div>',

  '<div class="section">',
  '  <div class="section-title">🏚 Props &amp; Environment</div>',
  '  <div class="grid3d" id="grid-props"></div>',
  '</div>',

  '<div class="section">',
  '  <div class="section-title">🎭 Procedural Rig</div>',
  '  <div class="note">',
  '    ⚡ A mãe no jogo usa esse rig procedural (não o GLB) — 7 bones independentes já codados.',
  '    Walk cycle ao vivo, alternando entre poses: WALK → IDLE → CARRY → RIFLE a cada ~4.5s.',
  '  </div>',
  '  <div class="grid3d" id="grid-proc"></div>',
  '</div>',

  '<div class="section">',
  '  <div class="section-title">✨ VFX</div>',
  '  <div class="note">',
  '    Partículas recriadas ao vivo — loop contínuo com os mesmos parâmetros do jogo.',
  '  </div>',
  '  <div class="grid3d" id="grid-vfx"></div>',
  '</div>',

  '<div class="section">',
  '  <div class="section-title">🖼 UI Assets</div>',
  '  <div class="grid-img" id="grid-img"></div>',
  '</div>',

  '<div class="section">',
  '  <div class="section-title">🔊 Audio</div>',
  '  <div class="audio-list" id="audio-list"></div>',
  '</div>',

  // Embedded data
  `<script id="asset-data" type="application/json">${assetData}</script>`,

  // Import map for Three.js 0.174 (matches project version)
  '<script type="importmap">',
  JSON.stringify({
    imports: {
      'three': 'https://cdn.jsdelivr.net/npm/three@0.174.0/build/three.module.js',
      'three/addons/': 'https://cdn.jsdelivr.net/npm/three@0.174.0/examples/jsm/',
    }
  }, null, 2),
  '</script>',

  // Client JS embedded inline (already reads asset-data at runtime)
  '<script type="module">',
  clientJS,
  '</script>',

  '</body>',
  '</html>',
].join('\n');

writeFileSync(OUT, html, 'utf8');
console.log(`✓  asset-viewer.html written (${fmt(Buffer.byteLength(html, 'utf8'))})`);
console.log(`   → ${OUT}`);

# Asset Studio

A localhost web tool for iterating on a playable's assets — generate, swap, and
inspect 3D models, images, audio, VFX, and procedural visuals all in one
browser tab. Built to be **per-playable today, monorepo-shared tomorrow**: the
code currently lives in `playables/last-stand/tools/`, but its design is
generic and copies into any other playable in this monorepo with a config swap.

> **Why does this exist?** PMs iterating on a playable need to see "what's
> already in the game vs. what's still missing vs. what's a procedural
> placeholder", regenerate any asset on demand via Layer.ai, and drop final
> hand-made files in directly when designers deliver. The Studio collapses all
> of that into one tab, with Claude as the generation backend and a slot model
> (game requirements list) as the source of truth.

> **For teams testing this on another game:** see [Adopting in another playable](#adopting-in-another-playable)
> below. TL;DR — copy 4 files, write a config, you're live in ~10 minutes. The
> system is designed to make zero assumptions about which game you're running
> it in. Last Stand is the reference implementation; everything game-specific
> lives in **`asset-studio.config.json`** + the procedural/VFX factory
> registries. Open issues / paper-cuts back to the Last Stand maintainer.

## Status snapshot

| Capability | Stable since | Notes |
|---|---|---|
| Slot/status engine | Session 1 | Computed from disk every render; never stale |
| Layer.ai queue + auto-promote | Session 2 | `/api/queue` + SSE; Claude drives the backend |
| Drag-drop file replace | Session 4 | Any card with `data-asset` accepts a drop |
| Refs + Concepts (image-to-3D) | Session 4 | Auto-populates every GLB card's 🎨 dropdown |
| Mixamo character pipeline | Session 5 | GLB → FBX → manual rig → multi-clip merge |
| Shared WebGL renderer | Session 6 | Eliminates browser context limits permanently |
| Cross-browser hardening | Session 6 | Chrome/Edge/Firefox/Safari ≥ 14 verified; iOS hooks added |
| Fullscreen anim-bar with shortcuts | Session 6 | ←/→/Space switch clips while zoomed in |
| Race-safe async loaders | Session 6 | Per-asset load tokens prevent concurrent-load duplicate state |
| Per-clip bone offset overrides | Session 9 | Rig Tuner offsets can override per anim clip (idle, walk, run) on top of a default set |
| `lastAnimQ` compounding guard | Session 9 | Pre-mixer reset + post-mixer capture prevents PropertyMixer skip-write artifacts on paused/flat clips |
| Variant picker chips | Session 10 | One chip per existing variant in `fills[]`; click swaps `activeFill`; auto-update no confirmation |
| Binary version archive | Session 10 | Every replace/promote snapshots prior live to `assets/.history/<name>/<ts>.ext` |
| Krea-style version navigator | Session 10 | `‹ N/M ›` overlay top-left of filled cards; arrows promote adjacent archived versions |
| Config hot-reload (mtime Proxy) | Session 11 | Edits to `asset-studio.config.json` no longer require a server restart |
| `node --watch` for asset-server | Session 11 | Edits to `asset-server.mjs` auto-restart the process |
| Phase 2 slot manifest | Session 11 | Build/dev emit `__SLOT_MANIFEST__`; runtime `fileFor(slotId)` resolves variant — studio IS game truth |
| `.buildignore` exclusion | Session 11 | Studio-only files (concept_*, ref_*) live in `assets/` but skip the build inlining |
| Drift lint at server start | Session 11 | Warns when slot resolves to a file `main.ts` doesn't load — catches config/runtime drift early |
| Phase 3 procedural mom runtime | Session 12 | `makeProcMom()` in `main.ts` + manifest `mode: 'proc'` makes proc choice actually render in-game |
| Wireframe 1/2/3 + click select | Session 12 | Keys 1=solid/2=wireframe/3=overlay; click a mesh to isolate it (shift+click additive) |
| Stats overlay | Session 12 | Bottom-left pill showing tris/verts/meshes + texture MB on the fullscreen Rig Tuner |
| Mirror bone offset button | Session 12 | "→ Mirror to opposite" on Left/Right bones; copies offset with X-axis mirroring |

---

## Quick start

```bash
cd playables/<your-playable>
npm run asset-studio    # spawns server (via `node --watch`) + auto-opens browser at localhost:3010
```

Or double-click `open-asset-studio.bat` (Windows) — same result, no terminal
needed. For the full dev environment (asset studio + game dev server in
parallel), use `start-dev.bat` (opens asset studio on `:3010` and the game
on `:8080` with the `▶ Play` button in the studio header linking to the latter).

Once running, you can:
- **Edit `asset-server.mjs`** → process auto-restarts via `node --watch`.
- **Edit `asset-studio.config.json`** → config hot-reloads in-process via the
  `mtime`-checking Proxy. F5 the browser to see the new state.
- **Edit `asset-viewer-live.js`** → served fresh per request with cache-bust;
  F5 picks it up.

No manual restart needed for any of the above after the initial launch.

The browser opens to a dashboard organized by:

- **🎯 Game Slots overview** at the top — chips for every slot in the config,
  color-coded (green/yellow/red). Click any chip to scroll-and-flash the
  matching gallery card.
- **Per-category galleries** (Characters, Environment, Items, UI, Audio, VFX)
  — full-detail cards with 3D previews, history, fullscreen, and per-card
  Generate UI.
- **🎨 Refs & Concepts** — drop-zone for designer assets + AI concept generator.
- **🗂 All assets gallery** — collapsible flat list at the bottom for any file
  you want to confirm is on disk.
- **🔧 Generation queue** sidebar (button bottom-right) — every queued request
  with status (pending/generating/done) and inline notes from Claude.

---

## Core concepts

### 1. Slots = game requirements

Every distinct "thing the game needs to ship" is a **slot** declared in
`asset-studio.config.json`. A slot is metadata, not a file:

```jsonc
{
  "id": "char_mom",                    // unique
  "label": "Mom (mother)",             // display
  "category": "characters",            // groups in UI: characters | environment | items | ui | audio | vfx
  "kind": "glb",                       // glb | image | audio | vfx | rig-tuner | pose-calibrator | bone-offset-tuner
  "fills": [                           // SET of variants that COULD satisfy this slot (ordered)
    "mom_stylized_rigged.glb",
    "mom_chibi_rigged.glb",
    "mom_chibi.glb"
  ],
  "activeFill": "mom_stylized_rigged.glb",  // OPTIONAL — PM's explicit pick for the live variant
                                            // When absent, first existing entry in `fills[]` wins
  "fallback": {                        // OPTIONAL — proc/vfx factory shown if no fill exists OR usedInGame !== 'asset'
    "kind": "proc",                    // proc (registered procedural factory) or vfx
    "id": "humanoid_walk_idle_carry_rifle"
  },
  "usedInGame": "asset",               // OPTIONAL — which source the GAME uses at runtime: asset | proc | vfx
  "runtimeSupport": "both",            // OPTIONAL — which modes the GAME RUNTIME actually implements:
                                       //   'asset' (only GLB loader exists)
                                       //   'proc' (only procedural factory exists)
                                       //   'both' (default; runtime supports either choice)
                                       // When 'asset', the proc chip renders DISABLED with tooltip explaining
                                       // the runtime can't honor that choice — prevents PM confusion.
  "criticality": "blocker",            // blocker | important | optional — affects badge color
  "note": "Hero. Game uses ..."        // PM-facing context, prefilled into prompts
}
```

**Resolution rules** (server `computeSlotStatus`):
1. If `activeFill` is set, exists on disk, AND is listed in `fills[]` → it wins.
2. Otherwise `fills.find(f => existsOnDisk(f))` — first existing entry by priority order.
3. `status`: 🟢 polished if a fill resolved AND `usedInGame === 'asset'`, 🟡 placeholder if `usedInGame !== 'asset'` AND a fallback exists, 🔴 empty otherwise.

### 2. Status is computed, not stored

Three statuses per slot, derived from data on every page render:

| Status | Computation |
|---|---|
| 🟢 **polished** | `fills[0]` exists on disk AND `usedInGame === "asset"` (or default) |
| 🟡 **placeholder** | `usedInGame !== "asset"` AND a fallback (proc/vfx) is defined |
| 🔴 **empty** | No `fills` on disk AND no fallback |

This means the Studio **never lies**. If a file disappears, the slot turns
empty automatically next render. If you generate a new asset, status updates
without manual config edits.

### 3. The "Game uses:" chips — one per variant + proc fallback

When a slot has multiple existing variants in `fills[]`, each renders as a
separate clickable chip. The chip matching `activeFill` (or `fills[0]` when
unset) is highlighted as active. A proc/vfx fallback chip (if defined) sits
at the end.

```
GAME USES:  📦 mom_stylized_rigged.glb  📦 mom_chibi_rigged.glb  📦 mom_chibi.glb  🎲 proc:humanoid_walk_idle_carry_rifle
            ──────── ACTIVE ────────    (click to swap)            (click to swap)    (disabled when runtimeSupport='asset')
```

Click semantics:
- **Click a different variant chip** → server writes `activeFill: <name>` to
  the config via `PUT /api/slot/:id/active`. Studio reloads, new variant is
  live. If `usedInGame` was on the fallback, it auto-flips back to `'asset'`.
- **Click the proc/vfx chip** → PATCH `/api/slot/:id { usedInGame: 'proc' }`.
  Studio re-renders the slot as a placeholder card (procedural preview).
- **Proc/vfx chip when `runtimeSupport: 'asset'`** → disabled with tooltip:
  "Game runtime has no procedural fallback for this slot — preview-only in
  studio. Pick a GLB variant for the game." Prevents the PM from making a
  choice the game runtime can't honor.

### 3b. Version archive (Krea-style ‹ N/M ›)

Every time a fill is overwritten (via replace, slot assign, or archive promote),
the prior live binary is copied to `assets/.history/<name>/<ISO-timestamp><ext>`
BEFORE the new content lands. This binary archive is invisible to the regular
studio readdir filters (dot-prefix) but exposed via:

```
GET  /api/archive/:name            → list past versions {file, size, mtime}
GET  /api/archive/:name/:file      → download a specific archived binary
POST /api/archive/:name/promote    → restore: copy archive → live; delete source
                                      so total count stays constant; archive prior live
```

Each filled GLB/image slot card gets a small overlay pill at the top-left of
its preview: `‹ N/M ›`. M = total versions (live + archived). Arrows promote
the adjacent older/newer archive automatically (no confirmation — matches the
PM's mental model "the card IS what ships"). Arrows are disabled when only
the live version exists (M=1). SSE refresh after each swap updates the card
thumbnail.

The history drawer (📜) is paralleled but distinct: it shows METADATA from
`.history.json` (prompts, models, completion times — including pre-archive
runs with no binary saved) plus the binary versions list with "Use this"
buttons. Two views of "history" because they answer different questions.

### 4. Auto-promote on Generate done

When Claude marks a queue item `done` and the asset matches a slot's `fills[0]`,
the server automatically sets `usedInGame: "asset"`. So:

```
PM clicks Generate on env_house placeholder card
→ Claude generates house.glb via Layer
→ Saves to assets/house.glb
→ PATCH queue/:id status=done
→ Server detects fill match + auto-sets usedInGame=asset
→ Slot is now polished
→ Next page render shows green chip + the new GLB instead of proc cabin
```

No manual UI clicks needed for the common "generate to fill" flow.

### 5. Slot manifest — studio IS game truth (Phase 2)

The build pipeline reads `asset-studio.config.json` and emits a runtime
manifest into the inlined HTML:

```html
<script>window.__SLOT_MANIFEST__ = {
  "char_mom":   { "file": "mom_stylized_rigged.glb", "mode": "asset" },
  "env_house":  { "file": "house.glb",                "mode": "proc"  },
  ...
};</script>
```

`main.ts` exposes:
- `fileFor(slotId, fallback)` — returns the manifest's `.file` or `fallback`.
  Use INSTEAD of hardcoded filenames in `loadGLB*("...")` calls. The fallback
  string keeps the migration zero-downtime (playables without a manifest still
  load via the legacy literal).
- `slotMode(slotId)` — returns `'asset' | 'proc' | 'vfx'`. The runtime branches:
  asset → load GLB; proc → instantiate procedural factory (e.g. `makeProcMom()`).

When PM swaps a variant in the studio, the next build (or dev rebuild) picks
up the new pick automatically. **Drift is impossible for wired slots.** The
dev server includes an `fs.watch` on the config that re-prepares the bundle
within 200ms of a save.

Three exclusion rules compose in the build pipeline's `isIgnored()`:
1. `.buildignore` (gitignore-style, manual) — for non-slot files (concept_*, ref_*).
2. `nonActiveSlotFiles` (auto-derived) — every variant in `fills[]` that isn't
   the active one for its slot.
3. **Active-files override** — any file that IS the active variant for some
   slot ALWAYS gets included, even if listed in `.buildignore`. Without this,
   stale `.buildignore` entries can hide the PM's pick from the build.

### 6. Per-clip bone offset overrides (Rig Tuner)

The `.tune.json` file for each character schema:

```jsonc
{
  "boneOffsets": {
    "default":   { "mixamorigHips": { "rotation": [...], "position": [...] } },
    "overrides": {
      "walk":  { "mixamorigRightArm": { "rotation": [...] } },
      "idle":  { "mixamorigLeftShoulder": { "rotation": [...] } }
    }
  },
  "props": { "rifle.glb": { "bone": "...", "position": [...], "rotation": [...], "scale": ... } }
}
```

Effective offset at apply time: clip-override → default fallback. The rig
tuner Bone Offsets tab has a Scope bar at the top with "Default" + one pill
per existing override + "+ <activeClip>" create button + 🗑 delete. Editing
the bone in a given scope only mutates that scope's Map.

A **mirror button** (`→ Mirror to mixamorigRightArm`) appears when the
selected bone has a Left/Right pattern in its name. Click copies the current
offset to the opposite bone with X-axis mirroring (negate Y/Z rotation,
negate X position, preserve X rotation + Y/Z position — math chosen for
Mixamo characters facing -Z with mirror plane at YZ at x=0).

### 6b. `lastAnimQ` snapshot — compounding guard

Three.js `PropertyMixer.apply()` skips writing bone properties when its
accumulator buffer didn't change (paused mixer, flat clip sections). Without
a guard, `applyBoneOffsets` would multiply offsets onto bone.q every frame
without reset → exponential rotation. Architecture in both studio + game:
1. **Pre-mixer reset**: copy `lastAnimQ` → bone.q BEFORE `mixer.update`.
2. **Mixer.update** (overwrites with fresh values if changed; leaves at
   `lastAnimQ` otherwise — either way, clean).
3. **`captureLastAnim()`** copies bone.q → `lastAnimQ`, gated on `timeScale > 0`
   so paused frames don't snapshot offset-polluted values.
4. **`applyAll` / `applyBoneOffsets`** multiplies offsets on top of clean state.

### 7. Operations — `node --watch` + config hot-reload + drift lint

| Watcher | Triggers on | Effect |
|---|---|---|
| `node --watch` (via `npm run asset-studio`) | Any `tools/asset-server.mjs` edit | Restarts the process. Studio rerenders on next browser request. |
| `getConfig()` Proxy in asset-server | `asset-studio.config.json` mtime change | Re-reads the JSON in-place. Subsequent requests see fresh state. |
| `fs.watch(config)` in dev-server | Same file, debounced 200ms | Re-runs `prepareDevDir` so the next F5 in the dev game tab loads the new manifest. |

At startup, `lintSlotDrift(cfg)` parses `src/main.ts` for `load(GLB|GLBWithAnims|Audio|Texture)("...")` literals and warns when any slot's resolved fillName differs from what the runtime actually loads. Catches:
- `fills[]` ordering errors
- `activeFill` pointing at a variant the game can't load yet
- New slots added to config but not wired in `main.ts`

### 8. Refs vs Concepts (both are images for image-to-3D)

| Type | Source | Filename prefix | Where they show |
|---|---|---|---|
| 📎 **Ref** | Uploaded by PM (Figma export, photo, sketch) | `ref_<name>.<ext>` | Refs & Concepts gallery |
| 🎨 **Concept** | Generated by AI (concept creator form) | `concept_<name>.webp` | Refs & Concepts gallery |

Both auto-populate the **🎨 Ref dropdown** on every GLB/image card. When you
click Generate with a ref selected, Claude passes it as `editing_reference`
(images) or `init` (3D image-to-3D) to Layer.ai.

### 9. Generation queue

Every "Generate" click in any card POSTs `/api/queue` with the slot context.
Claude reads `tools/.queue.json` when you say "check queue" in chat, processes
each item via the Layer.ai MCP, writes the result to `assets/`, and PATCHes
the queue item to `done` (which triggers history append + auto-promote +
SSE refresh). Lineage tracking persists every completed run in
`tools/.history.json` for the per-card 📜 history drawer.

---

## Config schema (`asset-studio.config.json`)

Lives at the playable root. **Hot-reloaded on file mtime change** via the
asset-server's Proxy-backed `getConfig()` — no restart needed for edits.

```jsonc
{
  "title": "Last Stand",                // displayed in the header
  "subtitle": "Asset Studio",

  "slots": [...],                        // see slot schema above
                                         // → primary categorization

  "categories": [...],                   // LEGACY — only used if slots[] is empty

  "procRigs": [                          // procedural factory definitions
    {
      "id": "humanoid_walk_idle_carry_rifle",   // referenced from slot.fallback.id
      "label": "🎭 Procedural humanoid",
      "factory": "humanoid_walk_idle_carry_rifle",  // must match a key in BUILTIN_PROC_RIGS
      "note": "..."
    }
  ],

  "vfx": [                               // VFX factory definitions
    {
      "id": "chips",                     // referenced from slot.fallback.id
      "label": "🪵 Wood Chip Burst",
      "factory": "chips"                 // must match a key in BUILTIN_VFX_FACTORIES
    }
  ]
}
```

The studio reads **slots** + **factory definitions** to render. If `slots[]` is
empty, falls back to `categories[]` (legacy mode used by very early playables).

---

## Common workflows

### Generate or regenerate an asset

1. On any card, type a prompt in **"Redesign this asset"**
2. Pick a model (or leave on `⚡ Auto Fast` / `💎 Auto Quality`) — ETA + CU
   shown live below the dropdown
3. (Optional, GLB cards) pick a 🎨 Ref to use as image-to-3D init or
   editing_reference for image edits
4. Click **⚙️ Generate** → request lands in queue
5. Tell Claude **"check queue"** in chat
6. Claude resolves the model (auto preset → specific Layer model), runs
   generation, post-processes (e.g. sharp resize/webp), saves to disk, marks
   queue done with timeline note
7. SSE pushes `asset-updated` → card flashes green + new content loads + last-gen
   line appears in iter-panel

### Drop a designer's final file (no generation, no CU)

For images and GLBs only. Drag the file from File Explorer onto the card →
`📥 Drop to replace` overlay appears → release → POST `/api/replace/:assetName`
writes the bytes to disk preserving the slot's filename. SSE refreshes the card.

### Swap which variant the game uses

Two paths:
1. **Click a different variant chip** in the "Game uses:" row. Each existing
   variant in `fills[]` renders as its own chip; clicking sets `activeFill`
   via `PUT /api/slot/:id/active`. The next build (or dev rebuild via
   `fs.watch`) bakes the new pick into the runtime manifest — game loads the
   picked variant on next F5.
2. **Click the proc/vfx fallback chip** to swap `usedInGame`. Studio
   re-renders the slot as a placeholder. If `runtimeSupport: 'asset'` is set,
   the proc chip is disabled with a tooltip explaining the runtime gap.

### Roll back to a prior version

Filled GLB/image cards have a `‹ N/M ›` overlay at the top-left of the
preview. Click `‹` to promote the immediately-older archived version to
live (the prior live becomes a new archive at the top of the list).
Click `›` to roll forward. Total count stays constant — promote both
copies AND deletes the source archive to avoid duplicates.

For arbitrary-version restore, open the 📜 history drawer — the "💾 Stored
versions" section lists every archived binary with a green "Use this"
button per entry. The "📝 Generations log" section below shows metadata
entries from `.history.json` (prompts, models, completion times — includes
pre-archive runs with no binary).

### Pick an existing file for an empty slot

When a slot is in 🔴 empty status AND has files on disk matching its kind
(GLB / image / audio), the red ghost card shows a blue "or pick existing"
dropdown below the iter-panel. Pick any same-kind file → POST `/api/slot/:id/assign`
copies that file into the slot's canonical `fills[0]` name. Source file
stays intact for reuse.

### Add a new asset to an existing slot

Two paths:
- **Generate it through the slot's iter-panel** — Claude saves under the slot's
  `fills[0]` filename automatically
- **Drop a file via Explorer** into `assets/`. If its filename matches an
  existing slot's `fills[]`, it appears as that slot's polished card. If not,
  it shows in the **🔔 Orphan banner** as "unclaimed" — you can either edit
  the config to claim it, or delete

### Generate a concept image to drive image-to-3D

1. In the **🎨 Refs & Concepts** section, type a name + prompt in the
   **✨ Create new concept** form
2. Pick a model (`💎 Auto Quality` defaults here — concepts are upstream of
   3D and benefit from premium)
3. Click **⚙️ Generate concept**
4. Claude generates → saves as `concept_<name>.webp`
5. The new concept auto-populates in every GLB card's 🎨 Ref dropdown
6. On the GLB card you want to redesign, pick the concept in 🎨 Ref + write
   your 3D prompt + Generate → Claude calls Layer's image-to-3D with the
   concept as init image

---

## Architecture

```
playables/<your-game>/
├── asset-studio.config.json      ← slot definitions, factory defs (you edit this; hot-reloaded)
├── .buildignore                  ← gitignore-style; files in assets/ NOT to inline into the build
├── assets/                       ← all game assets (.glb, .webp, .mp3, .tune.json, etc.)
│   └── .history/                 ← binary version archive — auto-managed (do not edit)
│       └── <assetName>/
│           └── <ISO-timestamp>.<ext>
├── tools/
│   ├── asset-server.mjs          ← localhost:3010 HTTP server; runs under `node --watch`
│   ├── asset-viewer-live.js      ← client-side JS served by asset-server (cache-busted per request)
│   ├── CLAUDE_PROCESSING_GUIDE.md ← how Claude resolves auto-pick + polls Layer
│   ├── README.md                 ← this file
│   ├── .queue.json               ← runtime — generation queue (gitignored)
│   └── .history.json             ← runtime — METADATA log of completed gens (prompt/model/time)
├── start-dev.bat                 ← one-click launcher for asset-studio (3010) + dev game (8080)
├── stop-dev.bat                  ← kills both
└── open-asset-studio.bat         ← Windows desktop launcher (asset-studio only)
```

Note: `.history/` (binary archive, in `assets/`) and `.history.json`
(metadata log, in `tools/`) are SEPARATE. The binary archive stores actual
GLB/webp/mp3 bytes per version. The metadata log records generation events.
Some metadata entries pre-date the archive system and have no binary saved.

### Server endpoints

```
GET  /                       → HTML shell + initData JSON
GET  /api/client.js          → asset-viewer-live.js (no caching)
GET  /assets/:name           → file from assets/ folder (CORS *, no caching)

GET  /api/queue              → list pending/done generation requests
POST /api/queue              → enqueue a request (assetName, prompt, type, model, refConcept)
PATCH /api/queue/:id         → update status (pending → generating → done)
                                On `done`: auto-append to history + auto-promote slot
DELETE /api/queue/:id        → remove request

GET  /api/history?asset=...  → completed generations (filterable by asset name)
PATCH /api/slot/:id          → update slot.usedInGame ('asset' | 'proc' | 'vfx')
PUT  /api/slot/:id/active    → set slot.activeFill (body: { fill: 'foo.glb' }); must be in fills[]
POST /api/slot/:id/assign    → copy an existing asset into the slot's canonical fillName
                                 (body: { source: 'existing.glb' }); empty-slot dropdown uses this

GET  /api/tune/:character    → read <character>.tune.json (bone offsets + prop poses)
PUT  /api/tune/:character    → write the same file; supports per-clip overrides schema

GET  /api/archive/:name              → list past versions of an asset {file, size, mtime}
GET  /api/archive/:name/:file        → download a specific archived binary
POST /api/archive/:name/promote      → restore archive as live (body: { file }); auto-archives prior live
                                        and DELETES the promoted source so total count stays constant

POST /api/upload             → upload an external ref (saved as ref_<name>.<ext>)
POST /api/replace/:assetName → drag-drop direct file replace (no Layer call); auto-archives prior

GET  /api/events             → Server-Sent Events stream — asset-updated, queue-updated,
                                history-appended, slot-updated
```

The asset-server runs under `node --watch` (per `package.json`) so any edit
to `asset-server.mjs` auto-restarts the process. The CONFIG is hot-reloaded
on file mtime change via a Proxy backing `getConfig()` — no restart needed
for `asset-studio.config.json` edits.

### Client architecture

The client is a single `asset-viewer-live.js` module. Key concerns:

| Concern | Where |
|---|---|
| Card factories | `makeGLBCard`, `makeImageCard`, `makeProcMomCard`, `makeVFXCard`, `spawnProcGalleryCard` |
| Shared WebGL renderer | One `THREE.WebGLRenderer` for the whole gallery (see Shared-renderer pattern below) |
| Card rendering | Master rAF loop iterates `_cards` Set, sets viewport+scissor per visible card |
| Race-safe GLB loading | `loadGLBIntoScene` uses per-card load tokens to ignore stale concurrent calls |
| Slot rendering | `applySlotDecoration` + `attachSourceIndicator` + slots overview chips |
| Drag-drop replace | `attachDragReplaceTarget` (any card with `data-asset`) |
| Animation chip bar (card) | Auto-built when GLB has `gltf.animations.length > 0` |
| Animation chip bar (fullscreen) | `#fs-anim-bar` overlay inside the modal — chips + ←/→ /Space shortcuts |
| Fullscreen modal | One global modal shared by all cards (image zoom or GLB orbit) |
| History tracking | `HISTORY_BY_ASSET` Map populated on boot via `fetchHistory()` |
| Procedural factories | `BUILTIN_PROC_RIGS` (id → builder fn), `BUILTIN_VFX_FACTORIES` (allowlist) |

### Shared-renderer pattern

> **TL;DR** — every browser caps simultaneous WebGL contexts (Chrome ~16,
> Firefox ~16, Safari ~8). With 20-50 3D cards in the gallery, fast scrolling
> evicts older contexts and you see "white cards". The Studio side-steps this
> entirely by using **one** `WebGLRenderer` for the whole page and rendering
> each card's scene into a viewport rectangle of that single canvas.

```
                  ┌──────────────────────────────────────┐
window viewport   │                                      │
                  │   ┌─────────┐    ┌─────────┐         │   <canvas id="_glCanvas"
                  │   │ card A  │    │ card B  │         │     position:fixed; inset:0
                  │   │ scene a │    │ scene b │         │     pointer-events:none
                  │   └─────────┘    └─────────┘         │     alpha:true
                  │                                      │     z-index:2
                  │   ┌─────────┐    ┌─────────┐         │
                  │   │ card C  │    │ card D  │         │   master rAF iterates _cards:
                  │   │ scene c │    │ scene d │         │     for each visible card,
                  │   └─────────┘    └─────────┘         │     setViewport+setScissor
                  │                                      │     to its placeholder rect,
                  └──────────────────────────────────────┘     render its scene there.
```

Pattern from the official Three.js manual ("Multiple Canvases, One Renderer"
chapter). Trade-offs:

- ✅ **One WebGL context** — never hits browser limits, never gets evicted
- ✅ **Scenes stay loaded** — no thrash on scroll, instant swap-in
- ✅ **Update callbacks only run when visible** — `_renderAll` skips off-screen
  cards; particle/animation simulations naturally pause when scrolled away
- ⚠️ **Memory grows with #cards** — every scene + camera + texture stays in
  RAM permanently. With 30-50 cards (most of them tiny procedural geometry +
  a handful of GLBs) heap usage stays under 200 MB. Fine for a desktop dev tool;
  not appropriate for production gameplay
- ⚠️ **Pointer events** — `<canvas>` has `pointer-events:none` so clicks pass
  through. OrbitControls binds to each card's `<div>` placeholder directly, NOT
  to the shared canvas. Three.js OrbitControls accepts any DOM element

Each card factory (`makeGLBCard`, `makeProcMomCard`, etc.) creates a `<div>`
placeholder + scene + camera + (optional) controls + (optional) update callback,
and registers the bundle:

```js
registerCard({
  placeholder,            // <div> in the gallery; sets render rect via getBoundingClientRect
  scene, camera,
  controls,               // optional — OrbitControls bound to placeholder
  bgColor:  0x0d1520,     // optional — solid background drawn before scene
  update:   (dt) => { mixer?.update(dt); particleSystem?.tick(dt); },
});
```

Master loop (`_renderAll`) computes:

1. Card off-screen? Skip.
2. Card visible?
   - Update camera aspect to current placeholder rect
   - Call `card.update(dt)` and `card.controls.update()`
   - **Viewport** = full card rect (preserves camera→pixel mapping when
     partially scrolled off)
   - **Scissor** = visible intersection of card rect with canvas (only
     in-bounds pixels are written)
   - Clear with `card.bgColor` if set
   - `renderer.render(scene, camera)`

### Cross-browser support matrix

| Browser | Status | Notes |
|---|---|---|
| Chrome / Edge / Brave (Chromium ≥ 87) | ✅ Full support | |
| Firefox ≥ 78 | ✅ Full support | `alpha:true + antialias:true` may slightly desaturate; visually fine |
| Safari ≥ 14 (macOS / iPadOS / iOS) | ✅ Full support | Explicit `top/right/bottom/left` (`inset` shorthand requires 14.1+) |
| Safari (Metal backend, M1/M2) | ✅ With `Math.round()` | Subpixel viewport coords cause 1px gaps along scissor edges; rounded coords avoid this |
| WebGL2 unavailable | ✅ Auto-fallback | Three.js falls back to WebGL1 silently |
| Hardware acceleration off | ⚠️ Slow but works | `failIfMajorPerformanceCaveat:false` allows SwiftShader / llvmpipe software rendering |
| WebGL fully unavailable | ❌ Banner shown | Try/catch around constructor → red banner with "enable WebGL" instructions |
| IE11 / Safari ≤ 9 | ❌ Not supported | Three.js v0.150+ requires ES2020 |

Hardenings already baked into the SHARED_RENDERER block:

- `top:0;right:0;bottom:0;left:0` instead of `inset:0` (Safari ≤ 14)
- `Math.round()` on every viewport/scissor coord
- Separate viewport (full rect) vs scissor (clamped) so partially-scrolled
  cards don't distort
- `failIfMajorPerformanceCaveat:false` + `stencil:false` (less iOS memory)
- `orientationchange` listener for iOS URL-bar collapse (no `resize` fired)
- `webglcontextrestored` handler + `sessionStorage` reload-loop guard (max 1
  reload per 30s if the GPU keeps crashing)
- `element.isConnected` polyfill via `document.contains()` for very old WebKit
- WebGLRenderer constructor wrapped in try/catch with user-facing banner

### `fs.watch` debounce

`fs.watch` on Windows fires duplicate events for a single write. The asset-server
debounces by 250ms before pushing the SSE `asset-updated`, so a rapid
generate-then-rewrite (e.g. Claude finishes save → another tool re-saves with
different EXIF) only triggers ONE client refresh.

### Race-safe async loading

Concurrent calls to `loadGLBIntoScene(name)` (e.g. card creation + an SSE-
triggered refresh that fires while the first load is still awaiting GLTF
parse) used to leave **duplicate animation bars** and **ghost models** in the
scene. Pattern to copy if you add async loaders:

```js
async function loadAsset(name, /* refs */) {
  const ctx = registry.get(name);
  const myToken = (ctx?.loadToken || 0) + 1;
  if (ctx) ctx.loadToken = myToken;

  let data;
  try { data = await fetch(...); }
  catch (e) { console.error(e); return; }

  // Stale-load guard: a newer call has started; bail before mutating.
  if (ctx && ctx.loadToken !== myToken) return;

  // ── All DOM/scene mutation happens AFTER the await ─────────────────────
  container.querySelectorAll('.anim-bar').forEach(b => b.remove());
  // ... apply data ...
}
```

The two key rules: (1) bump a per-asset counter at entry; (2) bail if the
counter changed during the await. (3) NEVER mutate state before the await
returns successfully.

---

## Adopting in another playable — plug-and-play with Claude

The adoption has THREE tiers, in order of completeness:

| Tier | What you get | Effort |
|---|---|---|
| **A. Studio shell** | Browse + generate + drag-drop assets via the studio UI; nothing reflects in-game | Copy 4 files + write config (~15 min) |
| **B. Studio → game truth (Phase 2)** | PM picks a variant chip → next build / dev reload uses that variant in the game | 15 lines in `main.ts` (~30 min) |
| **C. Procedural fallbacks reflect in game (Phase 3)** | PM picks the proc chip → game renders the procedural runtime, not the GLB | Per-slot proc factory in `main.ts` (varies by slot) |

You can ship A alone (studio is purely editorial). B closes the asset-loop. C
closes the proc-loop. Most games will want A+B; C is per-slot opt-in.

### Tier A — Studio shell (the minimum)

Copy these into your playable directory (`playables/<your-game>/`):

```
asset-studio.config.json     ← write your own slots — see Config schema
tools/asset-server.mjs       ← copy as-is (no game-specific code)
tools/asset-viewer-live.js   ← copy as-is (no game-specific code)
tools/README.md              ← copy as-is or trim
tools/CLAUDE_PROCESSING_GUIDE.md ← copy as-is
.buildignore                 ← copy as-is; lists studio-only file patterns (concept_*, ref_*)
open-asset-studio.bat        ← copy as-is (uses %~dp0 for relative paths)
start-dev.bat / stop-dev.bat ← optional one-click launchers; edit the ports if you don't use 3010/8080
```

Add to `package.json`:

```jsonc
"scripts": {
  "asset-studio": "node --watch tools/asset-server.mjs",
  "dev":          "dev-playable .",          // standard monorepo dev server
  "build":        "build-playable ."          // standard monorepo build
}
```

The `--watch` flag is REQUIRED for asset-server.mjs edits to auto-reload (it
removes a major source of "I edited the server but the studio still shows
the old state" confusion). Without it, the PM needs to restart Node manually
on each edit.

Then write your `asset-studio.config.json` with your game's slots. See
**[Config schema](#config-schema-asset-studioconfigjson)** above. Minimum
viable: one slot per shippable asset, with `kind`, `fills[]` (filenames),
optional `criticality` and `note`.

At this point: `npm run asset-studio` opens the dashboard, you can generate
and drag-drop assets, but **nothing reflects in your game's runtime**. The
build pipeline (shared in `packages/build-pipeline`) already emits the
`__SLOT_MANIFEST__` script tag, but your game's `main.ts` ignores it.

### Tier B — Wire the manifest into your game runtime

The build pipeline emits a runtime manifest from your config. To consume it,
add this near the top of your game's `main.ts`:

```typescript
// 1. Read the manifest injected by the build / dev pipeline.
type SlotEntry = { file: string | null; mode: "asset" | "proc" | "vfx" };
const _rawManifest = ((window as unknown) as { __SLOT_MANIFEST__?: Record<string, SlotEntry | string> })
  .__SLOT_MANIFEST__ || {};
const slotManifest: Record<string, SlotEntry> = {};
for (const [k, v] of Object.entries(_rawManifest)) {
  slotManifest[k] = (typeof v === "string") ? { file: v, mode: "asset" } : v;
}

// 2. Two helpers: filename lookup + mode lookup.
function fileFor(slotId: string, fallback: string): string {
  return slotManifest[slotId]?.file || fallback;
}
function slotMode(slotId: string): "asset" | "proc" | "vfx" {
  return slotManifest[slotId]?.mode || "asset";
}
```

Now REPLACE every hardcoded `loadGLB("foo.glb")` / `loadAudio("bar.mp3")`
literal with `fileFor("slot_id", "foo.glb")` / `fileFor("slot_id", "bar.mp3")`.
The fallback string keeps you zero-downtime — if the manifest is empty
(no `asset-studio.config.json` yet, or new slot not wired), the literal
still works as before.

Verify with the **drift lint** that prints at server startup: it parses
`src/main.ts` for `loadGLB*("...")` calls and warns when any slot resolves
to a file your game doesn't load. Zero warnings = you're wired.

After this, **PM picks a chip in the studio → next build (or dev F5) loads
that exact variant in the game**.

### Tier C — Per-slot procedural runtime

To make the proc chip ACTUALLY render procedural in your game (not just in
the studio preview), add the corresponding runtime factory to `main.ts`.
Example pattern (see `makeProcMom` in Last Stand):

```typescript
function makeProcCabin(): { scene: Group; animations: AnimationClip[] } {
  const root = new Group();
  // ... build geometry from primitives ...
  return { scene: root, animations: [] };
}

// In your asset loader:
const cabinMode = slotMode("env_cabin");
const cabinLoad = cabinMode === "proc"
  ? Promise.resolve(makeProcCabin())
  : loadGLB(fileFor("env_cabin", "cabin.glb"));
```

Per slot, declare `runtimeSupport` in the config to advertise what your
runtime can do:
- `"asset"` — runtime only loads the GLB (proc chip renders disabled with tooltip)
- `"proc"` — runtime only renders procedural (asset chips are disabled)
- `"both"` — runtime handles either (default)

This makes the studio honest: chips render disabled when the runtime can't
honor the choice. PM never expects a proc-mode swap to work when there's
no proc factory wired.

### Letting Claude do the adaptation work

For a new game, the fastest path is: drop this README + your game's
`src/main.ts` in front of Claude with this prompt:

> "Adapt the Asset Studio from `playables/last-stand/tools/` for the playable
> at `playables/<my-game>/`. The README in that folder documents the full
> system. My game's runtime is at `src/main.ts`. Do:
> 1. Tier A: copy the 4 unmodified files + write `asset-studio.config.json`
>    with slots derived from the `loadGLB*("...")` literals already in main.ts.
>    Skip Mixamo / Last-Stand-specific stuff.
> 2. Tier B: add the manifest reader + `fileFor`/`slotMode` helpers; migrate
>    every hardcoded asset literal to `fileFor("slot_id", "literal")`.
> 3. For any procedural object my main.ts builds (anything I'm constructing
>    via Three.js primitives rather than loading), suggest a `runtimeSupport`
>    value on the corresponding slot. Don't write the factory — flag it as a
>    next-step decision for me."

Claude has the full context of the architecture in this README and can do
Tiers A+B end-to-end in ~30 minutes for a typical playable. Tier C is
per-slot and design-dependent — generally a PM-driven decision per asset.

### What stays generic (no per-game customization needed)

Everything inside `tools/asset-server.mjs` and `tools/asset-viewer-live.js`
is game-agnostic. The shared `packages/build-pipeline` already emits the
manifest from any playable's `asset-studio.config.json`. The slot/status
engine, queue + history, SSE, version archive, drag-drop, Krea-style
navigator, wireframe modes, stats overlay, mirror button, drift lint, and
`node --watch` workflow ALL work without modification.

### What you customize per game

1. **`asset-studio.config.json`** — your slot manifest. The single most
   important file. Drives every studio decision.
2. **Procedural factories** in `asset-viewer-live.js` — for studio preview
   only. Add new functions following `makeProcTree` / `spawnProcGalleryCard`
   patterns, register in `BUILTIN_PROC_RIGS` / `BUILTIN_VFX_FACTORIES`.
3. **`runtimeSupport` per slot** — declare what your runtime actually
   implements. Defaults to `'both'` for backward compat.
4. **Procedural runtime factories** in `main.ts` — only needed if you want
   `usedInGame: 'proc'` slots to render procedurally in-game. Each is a
   self-contained function returning `{scene, animations: []}` plus optional
   per-frame `tick(dt, animName)` for animated cases (see `makeProcMom`).
5. **Layer model defaults** in `CLAUDE_PROCESSING_GUIDE.md` — what
   `auto:fast` / `auto:quality` resolve to per asset type.

---

## Extension points

### Add a new procedural factory

1. Implement a `makeMyThingCard(container)` function in `asset-viewer-live.js`
   following the pattern of `makeProcTree` (or `spawnProcGalleryCard` for the
   short version)
2. Register it in `BUILTIN_PROC_RIGS`:
   ```js
   const BUILTIN_PROC_RIGS = {
     ...
     my_thing: makeMyThingCard,
   };
   ```
3. Reference it from a slot's fallback in `asset-studio.config.json`:
   ```json
   { "id": "env_my_thing", "kind": "glb", "fills": [...],
     "fallback": { "kind": "proc", "id": "my_thing" } }
   ```

### Add a new VFX factory

1. Add a new `else if (vfxType === 'my_vfx') {...}` branch in `makeVFXCard`'s
   builder switch
2. Add `'my_vfx'` to `BUILTIN_VFX_FACTORIES` array
3. Add a corresponding entry to `vfx[]` in the config + reference from a slot's
   fallback

### Add a new Layer model to dropdowns

Edit `MODELS_3D` or `MODELS_IMG` arrays in `asset-viewer-live.js`. Each entry:

```js
{
  value: 'base-model-id-from-Layer-MCP',
  label: 'Display name (provider · timing)',
  eta: '~30s',                          // shown live next to dropdown
  cost: '2 CU/gen',
  tip: 'Short rationale (e.g. "fastest, no transparency")'
}
```

Then update `CLAUDE_PROCESSING_GUIDE.md` so Claude knows when to pick it.

---

## Mixamo character animation pipeline

Specialized companion workflow for adding skeletal animation to characters.
Uses Blender headless (4.4+) for GLB↔FBX conversion + a manual Mixamo step.

```
mom.glb (static)
    ↓ scripts/glb-to-fbx.py (Blender headless)
mom-tpose.fbx
    ↓ MANUAL: Mixamo upload + auto-rig + select 4 anims + download
4 × .fbx (1 with skin, 3 animation-only)
    ↓ scripts/merge-mixamo-to-glb.py (Blender headless)
mom_rigged.glb (skin + AnimationClips with clean names)
    ↓ Drop into assets/
Studio auto-detects → animation chip bar appears
    ↓ Wire into game src/main.ts (load + AnimationMixer + state-driven action selection)
Game character animates via Mixamo skeleton
```

### Mixamo manual step in detail

1. Run `scripts/glb-to-fbx.py` to convert your character GLB → Mixamo-friendly FBX
2. Upload the FBX to mixamo.com (Adobe login required — Mixamo has no API)
3. Auto-rigger asks you to place 5 anatomy markers (chin, wrists, elbows, knees, groin)
4. Browse animation library → select 3-5 clips for your character
5. For each clip download as **FBX Binary, 30fps, no keyframe reduction**:
   - First clip: **With Skin** (this carries the rigged mesh)
   - Subsequent clips: **Without Skin** (animation-only, smaller)
   - Toggle **In Place** ON for walking/running animations (so movement is driven
     by game velocity, not the animation root motion)
6. Rename downloaded files following the convention `<asset>_<clip>.fbx`
   (e.g. `mom_skin.fbx`, `mom_walk.fbx`, `mom_idle.fbx`, `mom_aim_rifle.fbx`)
7. Run merge script:
   ```bash
   "C:/Program Files/Blender Foundation/Blender 4.4/blender.exe" -b \
     -P scripts/merge-mixamo-to-glb.py -- \
     <output>.glb <skin>.fbx <anim1>.fbx <anim2>.fbx ...
   ```
8. Resulting GLB has skin + named AnimationClips ready for Three.js AnimationMixer

### Wiring into the game — basic pattern

```typescript
import { AnimationMixer, AnimationAction, AnimationClip, LoopRepeat } from "three";

async function loadGLBWithAnims(name: string): Promise<{scene: Group, animations: AnimationClip[]}> {
  // ... GLTFLoader.parse → resolve({scene: gltf.scene, animations: gltf.animations})
}

class MyGame extends PlayableBase {
  private mixer: AnimationMixer | null = null;
  private actions: Map<string, AnimationAction> = new Map();
  private currentAction: AnimationAction | null = null;

  async loadAssets() {
    const data = await loadGLBWithAnims("char_rigged.glb");
    this.character = data.scene;

    this.mixer = new AnimationMixer(data.scene);
    for (const clip of data.animations) {
      const action = this.mixer.clipAction(clip);
      action.setLoop(LoopRepeat, Infinity);
      // Strip the "mixamorig|Idle" prefix to a flat slot key
      const shortName = clip.name.replace(/^.*[|:.]/, "").toLowerCase();
      this.actions.set(shortName, action);
    }
    this.actions.get("idle")?.play();
  }

  setAction(name: string, fadeDuration = 0.25) {
    const next = this.actions.get(name);
    if (!next || next === this.currentAction) return;
    if (this.currentAction) {
      next.reset().play();
      this.currentAction.crossFadeTo(next, fadeDuration, false);
    } else {
      next.reset().play();
    }
    this.currentAction = next;
  }

  update(dt: number) {
    this.mixer?.update(dt);
    if (this.isFighting) this.setAction("aim_rifle");
    else if (this.isMoving) this.setAction("walk");
    else this.setAction("idle");
  }
}
```

### Wiring into the game — 6-slot animation state machine

For any character that has BOTH unarmed/armed states AND an action overlay
(harvesting, casting, aiming, blocking — anything that's a transient pose),
the canonical 6-slot model produces cleaner-looking gameplay than the simple
3-state version above.

| Slot | When | Mixamo clip suggestions |
|---|---|---|
| `idle_unarmed` | unarmed + standing still | `Idle`, `Standing Idle 01`, `Breathing Idle` |
| `run_unarmed` | unarmed + moving | `Slow Run` or `Walking` (toggle "In Place") |
| `harvest` | unarmed + interacting with a source | `Hammering`, `Standing Reach High`, `Searching Pockets`, `Push Object` |
| `idle_armed` | armed + standing still | `Rifle Idle`, `Pistol Idle`, `Sword Idle` |
| `run_armed` | armed + moving | `Run Forward` (rifle), `Strafe Walk` |
| `shoot` | transient overlay right after firing/casting | `Firing Rifle`, `Firing Pistol Whilst Standing` |

Resolution function with priority chain + graceful fallbacks:

```typescript
private resolveAnimSlot(): string {
  const has = (n: string) => this.actions.has(n);

  // 1. Shoot (transient — typically ~150-200ms after fire event)
  if (this.hasWeapon && this.shootTimer > 0) {
    if (has("shoot")) return "shoot";
    // No dedicated clip yet — fall through to armed stance
  }
  // 2/3. Armed stance (whenever weapon is out)
  if (this.hasWeapon) {
    if (this.isMoving) {
      if (has("run_armed"))  return "run_armed";
      if (has("aim_rifle"))  return "aim_rifle";   // legacy clip name
      if (has("walk"))       return "walk";
    } else {
      if (has("idle_armed"))  return "idle_armed";
      if (has("reload_idle")) return "reload_idle"; // Mixamo "Rifle Idle"
      if (has("aim_rifle"))   return "aim_rifle";
      if (has("idle"))        return "idle";
    }
  }
  // 4. Harvest (interaction with a source)
  if (this.isHarvesting) {
    if (has("harvest"))  return "harvest";
    // Falls through to unarmed idle below — character is stationary while
    // harvesting, so an idle clip + a procedural tool wiggle reads correctly
    // until the proper harvest clip ships
  }
  // 5/6. Unarmed locomotion (default)
  return this.isMoving
    ? (has("walk") ? "walk" : "idle")
    : "idle";
}

update(dt: number) {
  this.mixer?.update(dt);
  this.shootTimer = Math.max(0, this.shootTimer - dt);
  this.setAction(this.resolveAnimSlot());

  // Procedural tool overlay (placeholder until real harvest clip):
  if (this.tool?.visible && this.isHarvesting) {
    this.tool.rotation.x = Math.sin(this.gameTime * 14) * 0.55;
  }
}

// Set externally:
//   this.shootTimer = 0.18;        // when fire event lands
//   this.isHarvesting = true;      // when char is within harvest radius
//   this.isMoving, this.hasWeapon  // routine state
```

Why this pattern:

- **Graceful degradation** — incomplete GLBs (missing `harvest` or `shoot`)
  still play SOMETHING reasonable. You can ship the game with 4/6 clips and
  add the others later
- **Single source of truth** — `resolveAnimSlot` is the only place clip
  selection logic lives. Adding a 7th slot is a 5-line change
- **Test-friendly** — call `resolveAnimSlot()` with mocked state to verify
  fallback chains in unit tests
- **PM-discoverable** — the priority chain reads top-to-bottom in declaration
  order, matching how PMs think about character behavior

### Mixamo caveats

- **Auto-rigger struggles with chibi proportions.** The 5 anatomy markers
  expect human-like proportions; very stylized chibis end up with rough rigs
  (face-mesh weight bleed into spine/neck bones, deformation during head-
  bobbing animations). **Mitigation:** generate your character mesh in T-pose
  with normal-ish proportions specifically for rigging using a 2D→3D pipeline
  (e.g. Layer's GPT Image 2 → Hunyuan 3D v3.1 Pro), then replace with your
  stylized version after rigging if needed
- **Layer Hunyuan 3D v3.1 Pro parameter compat:** the Pro variant **only**
  accepts `guidance_files` (type `init`), `include_textures`, `pbr_materials`,
  `text_prompt`, `batch_size`, `session_id`. It does NOT accept `low_poly`,
  `face_limit`, `quad_mesh`, or `use_ta_pose` (passing any of these returns
  `no provider available with given parameters`). Documented in
  CLAUDE_PROCESSING_GUIDE.md
- **Mixamo prefix on bone names** — every bone name comes back as
  `mixamorig:Hips`, `mixamorig:Spine`, etc. Three.js handles this fine; any
  code that hardcodes bone names needs to include the prefix or strip it
- **Mixamo doesn't accept GLB upload directly.** Always convert to FBX first
  via `scripts/glb-to-fbx.py`
- **Materials may simplify** through the FBX↔GLB roundtrip. Test in your
  game's lighting before declaring done
- **Pick `In Place` for locomotion clips** — `Walking`, `Slow Run`, `Run
  Forward` all default to having ROOT MOTION (the character translates
  forward as part of the animation). For game characters whose movement is
  driven by velocity/joystick, this looks like sliding when stationary and
  drift when moving. Toggle "In Place" ON in the Mixamo download dialog
- **Avoid `Run Forward` as your "armed idle"** — its head-bobbing applied
  to a stationary character produces face deformation. Use a true static
  clip like `Rifle Idle` for the idle_armed slot
- **Mixamo has no API and CSP-blocks external assets.** Full automation
  attempted via Claude_in_Chrome MCP failed (file_upload denied + CSP blocks
  fetch+script-src). The Mixamo upload + auto-rig + download steps are
  manual; the Studio handles everything else around them

---

## Fullscreen modal — animation switcher + keyboard

Click the 🔍 button on any GLB card to open the fullscreen modal. If the GLB
ships with `gltf.animations`, an overlay chip-bar appears at the top of the
stage:

```
┌──────────────────────────────────────────────────────────┐
│  ✕ Close (Esc)                                           │
│ ┌──────────────────────────────────────────────┐         │
│ │ 🎬 Animation [walk] [idle] [aim_rifle]       │         │
│ │              [reload] [reload_idle] [⏸ pause]│         │
│ └──────────────────────────────────────────────┘         │
│                                                          │
│            [3D character zoomed in]                      │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

- **Click any chip** → 0.25s crossFade to that clip
- **`←` / `→`** → switch to previous/next clip
- **Space** → toggle pause
- **Selection mirrors back to the source card** — closing the modal preserves
  whatever clip you were watching
- **Backdrop blur** + horizontal scroll for many-clip GLBs (max-width: 92vw)

Implemented via `#fs-anim-bar` overlay built dynamically inside `openFsGLB`
and torn down inside `closeFs`.

---

## Fullscreen Rig Tuner — calibration features

The Rig Tuner (🎛 card → 🔍 fullscreen) is the workhorse for calibrating
character + prop alignment. Recent additions:

### Bone Offsets tab — scope selector + mirror button

The Scope bar at the top of the Bone Offsets tab toggles WHICH set of offsets
you're editing:
- **Default** pill — the universal offsets, applied to every clip.
- **One pill per existing override** (e.g. `walk`, `idle`).
- **+ <activeClip>** create button — appears when the currently-playing clip
  has no override yet. Click to start editing a new clip-specific override.
- **🗑** delete — confirms before removing the current scope's override entirely.

When the selected bone has a Left/Right pattern (e.g. `mixamorigLeftShoulder`),
a purple **→ Mirror to <opposite>** button appears below the reset row. Click:
- Reads the current offset for the selected bone.
- Negates Y/Z rotation; negates X position; preserves X rotation + Y/Z position.
- Saves the mirrored values to the opposite bone in the SAME scope (default
  or active override).
- Auto-selects the opposite bone so you can visually verify.

Math is for Mixamo characters facing -Z with mirror plane at YZ at x=0. The
button doesn't render for center bones (Hips/Spine/Neck) — no obvious target.

### Wireframe modes (keys 1 / 2 / 3) + click-to-isolate

Standard Blender convention applied across char + prop meshes:

| Key | Mode | Effect |
|---|---|---|
| `1` | Solid (default) | All meshes opaque. Clears any per-mesh selection. |
| `2` | Wireframe | All meshes render `material.wireframe = true`. |
| `3` | Overlay | Solid + `EdgesGeometry` line segments in green @ 0.85 alpha layered on top. Good for sharp-edge inspection while keeping color context. |

**Click any mesh in the 3D viewport** (when in mode 1) to isolate its
wireframe. Plain click clears any prior selection then wireframes the hit
mesh. **Shift+click** adds/removes additively without resetting. Pressing
`1` clears all selections and returns to fully solid.

Skip conditions for the click raycaster (so it doesn't fight other UI):
- Active gizmo drag (`boneGizmoActive || propGizmoActive`).
- Click target inside the side panel (`#fs-pose-panel`).

### Stats overlay

Bottom-left of the fullscreen canvas — semi-transparent pill showing the
combined char + prop stats:

```
📐 1.6k tris · 4.2k verts · 12 meshes
🖼 0.42 MB tex (3 unique)
Press 1/2/3 for solid/wireframe/overlay · click mesh to isolate
```

Texture MB is an RGBA estimate (`width × height × 4` per unique texture).
Updates via `refreshStatsOverlay()` at the end of each `reload()` (so it
follows character/prop swaps). The hint line updates live when you toggle
per-mesh wireframe selection.

### Version navigator (Krea-style overlay)

See section **3b. Version archive** in Core Concepts for the binary archive
that backs this. Top-left of every filled GLB/image card:

```
‹ 4/4 ›   ← M/M = live. Arrows are enabled when M > 1.
```

Click `‹` to promote the immediately-older archive to live (auto-archives
the prior live; total count stays constant). Click `›` to roll forward.
Disabled state (M=1) shows tooltip "Only one version — generate or replace
this asset to see history."

---

## Known limitations

| | |
|---|---|
| **Mixamo has no API** | Auto-rigger and animation download are manual; everything else around it (FBX conversion, multi-clip merge, rig validation) is automated |
| **Memory grows with #cards** | Shared-renderer keeps all scenes loaded permanently. With 30-50 cards this is < 200 MB heap; for an order-of-magnitude larger gallery, consider falling back to lazy init + dispose for non-critical cards |
| **GLBs over ~40 MB** | Three.js renders them fine for studio access, but the AppLovin 5 MB ceiling kills base64 inlining. The build pipeline auto-excludes non-active variants per slot (via the manifest) so only the active variant counts toward the budget. For the active variant itself, run `gltf-transform` with a rig-safe pipeline (resize textures, weld, prune, dedup, meshopt) — **avoid `flatten`, `join`, or the `optimize` shortcut on Skin-node GLBs** (they break the rig silently). Required: `loader.setMeshoptDecoder(MeshoptDecoder)` on every `GLTFLoader` instance in the game when the build inlines meshopt-compressed GLBs. |
| **Phase 3 proc fallback not implemented for every slot** | `main.ts` has procedural runtime for env_* / item_* slots (`makeProcCabin`, `makeProcBed`, `makeProcTree`, `makeProcFireplace`, etc.) AND `makeProcMom` for `char_mom`. Other character slots (zombie, daughters, rifle) have no proc runtime yet — pick `runtimeSupport: 'asset'` on those slots so the proc chip renders disabled with the explanatory tooltip. |
| **Layer file_upload extension permission** | Some MCPs (`file_upload` tool in Claude in Chrome) deny direct file system access for security; workaround: use `request_file_upload_url` + signed-URL upload (already used in CLAUDE_PROCESSING_GUIDE) |
| **`fs.watch` Windows duplicates** | 250ms debounce server-side — non-issue in normal use |
| **GCS resumable upload header** | Use `x-goog-content-length-range: 0,<file_size>` not `<size>,<size>` (well-documented landmine in CLAUDE_PROCESSING_GUIDE). The initial POST to start the upload session must also include `Content-Length: 0` explicitly or GCS returns 411 |

---

## Looking forward — packages/asset-studio

Eventually this should live in `packages/asset-studio/` for monorepo reuse:

```
packages/asset-studio/
├── package.json                 ← bin: { asset-studio: ... }
├── server/asset-server.mjs
├── client/asset-viewer-live.js
├── docs/README.md               ← this file
├── docs/CLAUDE_PROCESSING_GUIDE.md
└── examples/                    ← reference configs from each game
    ├── last-stand.json
    └── ...
```

Then any playable adds it as a workspace dep + writes its config:

```jsonc
// playables/<game>/package.json
{
  "scripts": {
    "asset-studio": "asset-studio --config asset-studio.config.json"
  },
  "devDependencies": {
    "@playables/asset-studio": "*"
  }
}
```

Until that extraction happens, copy-and-customize per playable as documented above.

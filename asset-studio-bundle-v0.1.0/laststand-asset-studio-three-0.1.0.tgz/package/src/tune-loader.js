// tune-loader.js — Asset Studio integration for the Capacitor game flavor.
//
// Reads <character>.tune.json (bone offsets + prop attachment poses) written by
// the Asset Studio's Rig Tuner. In dev, also subscribes to the studio's SSE
// stream so a Ctrl+S in the Tuner hot-reloads the live game state.
//
// Port of the playable's loadCharacterTune/applyBoneOffsets/equipRifle logic
// from src/main.ts:3208-3356 + 3998-4071.

import * as THREE from 'three';

const STUDIO_ORIGIN = 'http://localhost:3010';

export function createTuneLoader({
  characterAsset,          // e.g. 'mom_stylized_rigged.glb'
  isDev = false,
  onReload = null,         // optional callback fired after a successful (re)load
} = {}) {
  const stem = characterAsset.replace(/\.glb$/i, '');
  const prodUrl = `/assets/${stem}.tune.json`;
  const devUrl = `${STUDIO_ORIGIN}/api/tune/${encodeURIComponent(characterAsset)}`;

  // boneName → { qOffset: Quaternion, posOffset: Vector3 }
  let defaultOffsets = new Map();
  // clipName → Map<boneName, offset>
  const clipOverrides = new Map();
  // propName → { bone, position, rotation, scale }
  const propPoses = new Map();
  // union of all bone names referenced anywhere (for the per-frame loop)
  const referencedBones = new Set();

  let eventSource = null;
  let disposed = false;

  async function load() {
    // In dev, prefer the studio's endpoint (source of truth in /assets/).
    // Fallback to the Vite-served copy in game/public/assets/.
    const urls = isDev ? [devUrl, prodUrl] : [prodUrl];
    for (const url of urls) {
      try {
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) continue;
        const data = await res.json();
        applyJson(data);
        onReload?.();
        return true;
      } catch {
        // Try the next URL.
      }
    }
    return false;
  }

  function applyJson(data) {
    defaultOffsets = new Map();
    clipOverrides.clear();
    propPoses.clear();
    referencedBones.clear();

    const raw = data?.boneOffsets || {};
    if (raw.default !== undefined || raw.overrides !== undefined) {
      defaultOffsets = parseFlatOffsets(raw.default || {});
      for (const [clip, m] of Object.entries(raw.overrides || {})) {
        clipOverrides.set(clip, parseFlatOffsets(m));
      }
    } else {
      // Legacy flat schema — treat the whole dict as default.
      defaultOffsets = parseFlatOffsets(raw);
    }
    for (const k of defaultOffsets.keys()) referencedBones.add(k);
    for (const m of clipOverrides.values()) {
      for (const k of m.keys()) referencedBones.add(k);
    }

    for (const [name, p] of Object.entries(data?.props || {})) {
      propPoses.set(name, {
        bone: p.bone || 'mixamorigRightHand',
        position: p.position || [0, 0, 0],
        rotation: p.rotation || [0, 0, 0],
        scale: p.scale ?? 1.0,
      });
    }
  }

  function parseFlatOffsets(flat) {
    const m = new Map();
    for (const [boneName, off] of Object.entries(flat || {})) {
      const r = off.rotation || [0, 0, 0];
      const p = off.position || [0, 0, 0];
      m.set(boneName, {
        qOffset: new THREE.Quaternion().setFromEuler(new THREE.Euler(r[0], r[1], r[2])),
        posOffset: new THREE.Vector3(p[0], p[1], p[2]),
      });
    }
    return m;
  }

  // Per-frame: post-multiply the bone quaternion with the offset, and add the
  // world-equivalent position offset (compensated for bone world scale).
  // Must run AFTER the AnimationMixer.update for the current frame.
  const _ws = new THREE.Vector3();
  const _local = new THREE.Vector3();
  function applyBoneOffsets(armatureRoot, activeClipName = '') {
    if (!armatureRoot || referencedBones.size === 0) return;
    const override = clipOverrides.get(activeClipName);
    for (const boneName of referencedBones) {
      const off = override?.get(boneName) ?? defaultOffsets.get(boneName);
      if (!off) continue;
      const bone = armatureRoot.getObjectByName(boneName);
      if (!bone) continue;
      bone.quaternion.multiply(off.qOffset);
      bone.getWorldScale(_ws);
      const inv = _ws.x > 0.0001 ? 1 / _ws.x : 1;
      _local.copy(off.posOffset).multiplyScalar(inv);
      bone.position.add(_local);
    }
  }

  // Reparent and pose `prop` according to props[propName] in tune.json.
  // Returns true if a tuned pose was applied; false if no tune entry exists
  // (caller can fall back to its own hardcoded pose).
  function applyPropPose(prop, propName, armatureRoot, fallbackBone = null) {
    if (!prop) return false;
    const tuned = propPoses.get(propName);
    if (!tuned) return false;
    const target =
      (armatureRoot && armatureRoot.getObjectByName(tuned.bone)) || fallbackBone;
    if (!target) return false;
    if (prop.parent !== target) {
      prop.parent?.remove(prop);
      target.add(prop);
    }
    target.getWorldScale(_ws);
    const inv = _ws.x > 0.0001 ? 1 / _ws.x : 1;
    const [px, py, pz] = tuned.position;
    const [rx, ry, rz] = tuned.rotation;
    prop.position.set(px * inv, py * inv, pz * inv);
    prop.rotation.set(rx, ry, rz);
    prop.scale.setScalar(tuned.scale * inv);
    return true;
  }

  // Open the studio SSE stream and reload when the relevant file changes.
  function subscribe() {
    if (!isDev || eventSource || disposed) return;
    try {
      eventSource = new EventSource(`${STUDIO_ORIGIN}/api/events`);
      eventSource.addEventListener('asset-updated', (ev) => {
        if (disposed) return;
        let payload = null;
        try { payload = JSON.parse(ev.data); } catch { return; }
        const name = payload?.name || '';
        // Reload on changes to this character's tune.json OR its source GLB
        // (the studio may also refresh adjacent files).
        if (name === `${stem}.tune.json` || name === characterAsset) {
          load();
        }
      });
      eventSource.onerror = () => {
        // Asset Studio probably not running — silently disable.
        eventSource?.close();
        eventSource = null;
      };
    } catch {
      eventSource = null;
    }
  }

  function dispose() {
    disposed = true;
    eventSource?.close();
    eventSource = null;
  }

  return {
    load,
    subscribe,
    applyBoneOffsets,
    applyPropPose,
    dispose,
    get hasOffsets() { return referencedBones.size > 0; },
    get hasProp() { return (name) => propPoses.has(name); },
  };
}

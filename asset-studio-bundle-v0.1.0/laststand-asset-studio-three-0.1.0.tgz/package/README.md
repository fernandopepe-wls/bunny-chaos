# @laststand/asset-studio-three

Three.js runtime adapter for [`@laststand/asset-studio`](../asset-studio). Loads `<character>.tune.json` at boot and applies bone offsets + prop attachment poses per frame.

## Install

```bash
npm install @laststand/asset-studio-three
# peer: requires `three` in your project
```

## Usage

```js
import { createTuneLoader } from '@laststand/asset-studio-three';

const tune = createTuneLoader({
  characterAsset: 'hero.glb',        // matches the GLB filename
  isDev: import.meta.env?.DEV,        // enables SSE hot-reload from studio
  onReload: () => {
    // re-apply prop pose, e.g. after the studio saves a new tune.json
    tune.applyPropPose(weaponProp, 'weapon.glb', armatureRoot, rightHandBone);
  },
});

// 1. Load tune.json once the character GLB is in the scene
await tune.load();
tune.subscribe();   // open EventSource to studio (dev only)

// 2. Each frame, AFTER mixer.update(dt):
tune.applyBoneOffsets(armatureRoot, currentClipName);

// 3. Optional: pose a prop on the rig (e.g. a weapon in the right hand)
tune.applyPropPose(weaponProp, 'weapon.glb', armatureRoot, rightHandBone);

// On scene teardown:
tune.dispose();
```

## What it does

- **Bone offsets** — post-multiplies the bone quaternion with `tune.boneOffsets[boneName].rotation` and adds a world-equivalent position offset (compensated for the bone's accumulated world scale). Supports per-clip overrides via `tune.boneOffsets.overrides[clipName]`.
- **Prop poses** — reparents a prop (e.g. a rifle) under the bone named in `tune.props[propName].bone`, applies position / rotation / scale.
- **Hot reload (dev)** — opens `EventSource('http://localhost:3010/api/events')`; on the studio's `asset-updated` event for the relevant file, refetches and re-applies in-place.

## The tune.json format

Written by the studio's Rig Tuner. Schema:

```json
{
  "boneOffsets": {
    "default": { "mixamorigHips": { "rotation": [0, 0, 0], "position": [0, 0, 0] } },
    "overrides": {
      "walk": { "mixamorigRightArm": { "rotation": [0, 0.17, 0], "position": [0, 0, 0] } }
    }
  },
  "props": {
    "weapon.glb": {
      "bone": "mixamorigRightHand",
      "position": [-0.012, 0.208, 0.111],
      "rotation": [-2.77, -0.05, -2.08],
      "scale": 0.9
    }
  }
}
```

Rotation values are Euler XYZ in radians. Position values are world-unit-equivalent (the loader converts to bone-local units using `1 / boneWorldScale`).
